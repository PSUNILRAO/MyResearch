"""
Layer 3 — Constraint Engine
Enforces all four core constraints + extended rules.
Returns a ConstraintReport with violations, severities, and OCS contribution.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph, find_cycles, find_duplicate_queues
from src.utils.config import load_constraints_config
from src.utils.logger import get_logger

log = get_logger(__name__)

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


@dataclass
class Violation:
    rule_id: str
    severity: str
    description: str
    evidence: str
    affected_objects: list[str]
    score_contribution: int
    fix_recommendation: str


@dataclass
class ConstraintReport:
    violations: list[Violation] = field(default_factory=list)
    passed_rules: list[str] = field(default_factory=list)
    total_violation_score: int = 0
    has_hard_blocks: bool = False

    def add(self, v: Violation):
        self.violations.append(v)
        self.total_violation_score += v.score_contribution

    @property
    def critical_violations(self):
        return [v for v in self.violations if v.severity == "CRITICAL"]

    def summary(self) -> str:
        lines = [f"Constraint Report: {len(self.violations)} violations"]
        for v in sorted(self.violations, key=lambda x: SEVERITY_ORDER.get(x.severity, 9)):
            lines.append(f"  [{v.severity}] {v.rule_id}: {v.description}")
        return "\n".join(lines)


def run_constraints(ds: TopologyDataset, tg: TopologyGraph) -> ConstraintReport:
    cfg    = load_constraints_config()
    report = ConstraintReport()
    w      = cfg["ocs_weights"]

    # ── C1: Exactly 1 QM per AppID ───────────────────────────────────────
    for app, qms in tg.app_to_qms.items():
        if len(qms) > 1:
            report.add(Violation(
                rule_id="C1_ONE_QM_PER_APP",
                severity="CRITICAL",
                description=f"App '{app}' distributed across {len(qms)} queue managers",
                evidence=f"QMs: {sorted(qms)}",
                affected_objects=[app] + sorted(qms),
                score_contribution=w["app_qm_violation"] * (len(qms) - 1),
                fix_recommendation=(
                    f"Consolidate app '{app}' to single dedicated QM.{app}. "
                    f"Decommission: {sorted(qms - {'QM.' + app})}"
                ),
            ))
        else:
            report.passed_rules.append(f"C1::{app}")

    # ── C2: Producers write to Remote Q with XMIT routing ─────────────────
    for _, row in ds.producer_rows.iterrows():
        q_type = row.get("q_type", "")
        q_name = row["Discrete Queue Name"]
        app    = row["app_id"]
        if "Local" in q_type and "Remote" not in q_type:
            remote_qm = row.get("remote_q_mgr_name", "").strip()
            if not remote_qm:
                # Only flag if there IS a consumer on a different QM
                flow_match = [
                    f for f in tg.comm_flows
                    if f["queue"] == q_name and f["from_app"] == app
                       and f["from_qm"] != f["to_qm"]
                ]
                if flow_match:
                    report.add(Violation(
                        rule_id="C2_PRODUCER_REMOTE_QUEUE",
                        severity="HIGH",
                        description=f"Producer app '{app}' writes Local queue for cross-QM flow",
                        evidence=f"Queue: {q_name}, type: {q_type}",
                        affected_objects=[app, q_name],
                        score_contribution=w["app_qm_violation"],
                        fix_recommendation=(
                            f"Define a Remote queue on QM.{app} pointing to consumer QM. "
                            f"Add XMIT queue XMIT.QM.<consumer_app> on QM.{app}."
                        ),
                    ))

    # ── C3: Consumers read from Local queues only ─────────────────────────
    for _, row in ds.consumer_rows.iterrows():
        q_type = row.get("q_type", "")
        q_name = row["Discrete Queue Name"]
        app    = row["app_id"]
        if "Remote" in q_type and "Local" not in q_type:
            report.add(Violation(
                rule_id="C3_CONSUMER_LOCAL_QUEUE",
                severity="CRITICAL",
                description=f"Consumer app '{app}' reads from Remote queue (should be Local)",
                evidence=f"Queue: {q_name}, type: {q_type}",
                affected_objects=[app, q_name],
                score_contribution=w["app_qm_violation"],
                fix_recommendation=(
                    f"Create Local queue on QM.{app}. "
                    f"Configure sender channel to deliver messages to this Local queue."
                ),
            ))

    # ── C4: Deterministic channel naming ─────────────────────────────────
    pattern = re.compile(r"^QM\.[A-Z0-9]+\.QM\.[A-Z0-9]+$")
    for flow in tg.comm_flows:
        if flow["from_qm"] != flow["to_qm"]:
            expected = f"QM.{flow['from_app']}.QM.{flow['to_app']}"
            if not pattern.match(expected):
                report.add(Violation(
                    rule_id="C4_CHANNEL_NAMING",
                    severity="HIGH",
                    description="Non-deterministic channel naming detected in flow",
                    evidence=f"Flow: {flow['from_app']} → {flow['to_app']}",
                    affected_objects=[flow["from_qm"], flow["to_qm"]],
                    score_contribution=w.get("alias_queue", 3),
                    fix_recommendation=(
                        f"Use: SENDER={flow['from_qm']}.{flow['to_qm']}, "
                        f"RECEIVER={flow['to_qm']}.{flow['from_qm']}"
                    ),
                ))

    # ── Extended: Alias queues ────────────────────────────────────────────
    for q in tg.alias_queues:
        report.add(Violation(
            rule_id="EXT_NO_ALIAS_QUEUES",
            severity="HIGH",
            description=f"Alias queue adds indirection: {q}",
            evidence=f"Queue type contains 'Alias'",
            affected_objects=[q],
            score_contribution=w["alias_queue"],
            fix_recommendation="Replace alias with direct Remote or Local queue definition.",
        ))

    # ── Extended: Hybrid queue types ─────────────────────────────────────
    for q in tg.hybrid_queues:
        if q not in tg.alias_queues:  # already reported
            report.add(Violation(
                rule_id="EXT_NO_HYBRID_TYPES",
                severity="HIGH",
                description=f"Hybrid queue type (e.g. Remote;Local): {q}",
                evidence=f"q_type: {tg.queue_types.get(q, '?')}",
                affected_objects=[q],
                score_contribution=w["alias_queue"],
                fix_recommendation="Assign single unambiguous type: Local, Remote, or XMIT.",
            ))

    # ── Extended: MQ Clusters ─────────────────────────────────────────────
    for cluster in tg.clusters:
        report.add(Violation(
            rule_id="EXT_NO_MQ_CLUSTERS",
            severity="MEDIUM",
            description=f"MQ Cluster bypasses explicit topology: {cluster}",
            evidence=f"cluster_name={cluster}",
            affected_objects=[cluster],
            score_contribution=w["cluster"],
            fix_recommendation="Replace cluster routing with explicit sender/receiver channels.",
        ))

    # ── Extended: Multi-hop routing ───────────────────────────────────────
    for flow in tg.multi_hop_flows:
        report.add(Violation(
            rule_id="EXT_MAX_ROUTING_HOPS",
            severity="HIGH",
            description=(
                f"Multi-hop routing: {flow['from_app']}→{flow['intermediate_qm']}→{flow['to_app']} "
                f"({flow['hops']} hops)"
            ),
            evidence=f"Queue: {flow['queue']}",
            affected_objects=[flow["from_qm"], flow.get("intermediate_qm",""), flow["to_qm"]],
            score_contribution=w["multi_hop_violation"],
            fix_recommendation="Establish direct channel between source and destination QM.",
        ))

    # ── Extended: Duplicate .IO queues ───────────────────────────────────
    dups = find_duplicate_queues(ds)
    for q in dups:
        report.add(Violation(
            rule_id="EXT_DUPLICATE_QUEUES",
            severity="MEDIUM",
            description=f"Duplicate .IO variant queue: {q}",
            evidence=f"Both {q} and {q[:-3]} exist",
            affected_objects=[q, q[:-3]],
            score_contribution=w["duplicate_queue"],
            fix_recommendation="Retire .IO variant unless a distinct consumer pattern exists.",
        ))

    # ── Cycles ────────────────────────────────────────────────────────────
    cycles = find_cycles(tg)
    for cycle in cycles:
        report.add(Violation(
            rule_id="EXT_NO_CYCLES",
            severity="HIGH",
            description=f"Routing cycle detected: {' → '.join(cycle + [cycle[0]])}",
            evidence=f"Cycle length: {len(cycle)}",
            affected_objects=cycle,
            score_contribution=w["multi_hop_violation"] * 2,
            fix_recommendation="Break cycle by removing one flow direction or introducing async reply pattern.",
        ))

    report.has_hard_blocks = len(report.critical_violations) > 0
    log.info(f"Constraint check: {len(report.violations)} violations, "
             f"score={report.total_violation_score}, hard_blocks={report.has_hard_blocks}")
    return report
