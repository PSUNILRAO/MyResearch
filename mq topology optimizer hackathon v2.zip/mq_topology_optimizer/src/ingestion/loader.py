"""
Layer 1 — CSV Ingestion & Validation
Loads and validates the MQ topology CSV input.
"""
from __future__ import annotations
import pandas as pd
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
from src.utils.logger import get_logger

log = get_logger(__name__)

REQUIRED_COLUMNS = {
    "Discrete Queue Name", "PrimaryAppRole", "queue_manager_name",
    "app_id", "q_type",
}

OPTIONAL_COLUMNS = {
    "ProducerName", "ConsumerName", "Primary App_Full_Name", "PrimaryAppDisp",
    "line_of_business", "Primary Neighborhood", "Primary Hosting Type",
    "Primary Data classification", "def_persistence", "def_put_response",
    "inhibit_get", "inhibit_put", "remote_q_mgr_name", "remote_q_name",
    "usage", "xmit_q_name", "Neighborhood", "cluster_name",
}


@dataclass
class TopologyDataset:
    """Validated in-memory representation of the input CSV."""
    raw_df: pd.DataFrame
    queue_managers: list[str] = field(default_factory=list)
    app_ids: list[str] = field(default_factory=list)
    queues: list[dict] = field(default_factory=list)
    producer_rows: pd.DataFrame = field(default_factory=pd.DataFrame)
    consumer_rows: pd.DataFrame = field(default_factory=pd.DataFrame)
    validation_errors: list[str] = field(default_factory=list)
    source_path: Optional[str] = None

    @property
    def is_valid(self) -> bool:
        return len(self.validation_errors) == 0


def load_topology(csv_path: str | Path) -> TopologyDataset:
    """Load and validate a topology CSV file."""
    path = Path(csv_path)
    log.info(f"Loading topology from: {path}")

    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = df.columns.str.strip()
    df = df.map(lambda x: x.strip() if isinstance(x, str) else x)

    errors = []
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        errors.append(f"Missing required columns: {missing}")

    if df.empty:
        errors.append("Input CSV is empty")

    if errors:
        return TopologyDataset(raw_df=df, validation_errors=errors, source_path=str(path))

    # Normalise
    df["q_type_clean"] = df["q_type"].str.split(";").str[0].str.strip()

    ds = TopologyDataset(
        raw_df=df,
        queue_managers=sorted(df["queue_manager_name"].unique().tolist()),
        app_ids=sorted(df["app_id"].unique().tolist()),
        producer_rows=df[df["PrimaryAppRole"].str.upper() == "PRODUCER"].copy(),
        consumer_rows=df[df["PrimaryAppRole"].str.upper() == "CONSUMER"].copy(),
        source_path=str(path),
    )

    ds.queues = df["Discrete Queue Name"].unique().tolist()

    log.info(
        f"Loaded: {len(df)} rows | {len(ds.queue_managers)} QMs | "
        f"{len(ds.app_ids)} apps | {len(ds.queues)} unique queues"
    )
    return ds
