"""
Layer 6 — Operational Complexity Score (OCS)
OCS = C_base + C_violations + C_redundancy + C_coupling
"""
from __future__ import annotations
from dataclasses import dataclass, field
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph, find_duplicate_queues
from src.constraints.engine import ConstraintReport
from src.utils.config import load_constraints_config
from src.utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class OCSResult:
    c_base: int = 0
    c_violations: int = 0
    c_redundancy: int = 0
    c_coupling: int = 0
    total: int = 0
    breakdown: dict = field(default_factory=dict)
    label: str = "as-is"

    def __post_init__(self):
        self.total = self.c_base + self.c_violations + self.c_redundancy + self.c_coupling

    def summary(self) -> str:
        return (
            f"OCS [{self.label}] = {self.total} "
            f"(base={self.c_base}, violations={self.c_violations}, "
            f"redundancy={self.c_redundancy}, coupling={self.c_coupling})"
        )


def compute_ocs(
    ds: TopologyDataset,
    tg: TopologyGraph,
    report: ConstraintReport,
    label: str = "as-is",
) -> OCSResult:
    cfg = load_constraints_config()
    w   = cfg["ocs_weights"]

    # C_base
    qm_count      = len(ds.queue_managers)
    channel_count = len(set(
        (f["from_qm"], f["to_qm"]) for f in tg.comm_flows if f["from_qm"] != f["to_qm"]
    ))
    remote_q_count = sum(
        1 for qt in tg.queue_types.values() if "Remote" in qt and "Local" not in qt
    )
    c_base = (qm_count * w["qm_base"] +
              channel_count * w["channel_base"] +
              remote_q_count * w["remote_q_base"])

    # C_violations — from constraint report
    c_violations = report.total_violation_score

    # C_redundancy
    dups = find_duplicate_queues(ds)
    c_redundancy = len(dups) * w["duplicate_queue"]

    # C_coupling
    cluster_count  = len(tg.clusters)
    shared_qm_apps = sum(
        max(0, len(apps) - 1) for apps in tg.qm_to_apps.values()
    )
    c_coupling = (cluster_count * w["cluster"] +
                  shared_qm_apps * w["shared_qm_app"])

    result = OCSResult(
        c_base=c_base,
        c_violations=c_violations,
        c_redundancy=c_redundancy,
        c_coupling=c_coupling,
        label=label,
        breakdown={
            "qm_count": qm_count,
            "channel_pairs": channel_count,
            "remote_queues": remote_q_count,
            "alias_queues": len(tg.alias_queues),
            "hybrid_queues": len(tg.hybrid_queues),
            "clusters": cluster_count,
            "shared_qm_apps": shared_qm_apps,
            "duplicate_queues": len(dups),
            "multi_hop_flows": len(tg.multi_hop_flows),
            "app_qm_violations": sum(
                max(0, len(qms) - 1) for qms in tg.app_to_qms.values()
            ),
        },
    )
    result.total = result.c_base + result.c_violations + result.c_redundancy + result.c_coupling
    log.info(result.summary())
    return result
