"""
Metrics & Dashboard Data Module
Produces structured metrics for Streamlit dashboard and JSON export.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph, compute_fan_out
from src.constraints.engine import ConstraintReport
from src.observability.ocs_scorer import OCSResult
from src.generator.target_state import TargetStateArtifacts
from src.utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class DashboardMetrics:
    # KPI row
    asis_qm_count: int = 0
    asis_app_count: int = 0
    asis_queue_count: int = 0
    asis_flow_count: int = 0
    asis_violation_count: int = 0
    asis_ocs: int = 0

    target_qm_count: int = 0
    target_channel_pairs: int = 0
    target_ocs: int = 0
    ocs_reduction_pct: float = 0.0

    # Severity breakdown
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0

    # App analysis
    apps_with_multi_qm: list[dict] = field(default_factory=list)
    fan_out_ranking: list[dict] = field(default_factory=list)

    # OCS dimensional data (for charts)
    asis_dimensions: dict = field(default_factory=dict)
    target_dimensions: dict = field(default_factory=dict)

    # Flow data
    flow_table: list[dict] = field(default_factory=list)
    channel_table: list[dict] = field(default_factory=list)

    # Violation data
    violation_table: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "kpis": {
                "asis_qms":          self.asis_qm_count,
                "asis_apps":         self.asis_app_count,
                "asis_queues":       self.asis_queue_count,
                "asis_flows":        self.asis_flow_count,
                "asis_violations":   self.asis_violation_count,
                "asis_ocs":          self.asis_ocs,
                "target_qms":        self.target_qm_count,
                "target_channels":   self.target_channel_pairs,
                "target_ocs":        self.target_ocs,
                "ocs_reduction_pct": self.ocs_reduction_pct,
            },
            "severity_counts": {
                "CRITICAL": self.critical_count,
                "HIGH":     self.high_count,
                "MEDIUM":   self.medium_count,
                "LOW":      self.low_count,
            },
            "ocs_dimensions": {
                "as_is":  self.asis_dimensions,
                "target": self.target_dimensions,
            },
        }


def build_metrics(
    ds: TopologyDataset,
    tg: TopologyGraph,
    report: ConstraintReport,
    ocs: OCSResult,
    arts: TargetStateArtifacts,
    ocs_target: OCSResult,
) -> DashboardMetrics:

    m = DashboardMetrics()

    # ── KPIs ──────────────────────────────────────────────────────────────
    m.asis_qm_count       = len(ds.queue_managers)
    m.asis_app_count      = len(ds.app_ids)
    m.asis_queue_count    = len(ds.queues)
    m.asis_flow_count     = len(tg.comm_flows)
    m.asis_violation_count = len(report.violations)
    m.asis_ocs            = ocs.total

    m.target_qm_count     = len(arts.target_qms)
    m.target_channel_pairs = len(arts.channel_pairs)
    m.target_ocs          = ocs_target.total
    m.ocs_reduction_pct   = round((1 - ocs_target.total / max(ocs.total, 1)) * 100, 1)

    # ── Severity counts ───────────────────────────────────────────────────
    for v in report.violations:
        if v.severity == "CRITICAL": m.critical_count += 1
        elif v.severity == "HIGH":   m.high_count += 1
        elif v.severity == "MEDIUM": m.medium_count += 1
        else:                        m.low_count += 1

    # ── Apps with multi-QM ────────────────────────────────────────────────
    for app, qms in sorted(tg.app_to_qms.items()):
        if len(qms) > 1:
            m.apps_with_multi_qm.append({
                "app": app, "qm_count": len(qms),
                "qms": sorted(qms),
                "ocs_contribution": (len(qms) - 1) * 10,
            })

    # ── Fan-out ranking ───────────────────────────────────────────────────
    fan = compute_fan_out(tg)
    m.fan_out_ranking = sorted(
        [{"app": a, "fan_out": c} for a, c in fan.items()],
        key=lambda x: -x["fan_out"],
    )

    # ── OCS dimensions ─────────────────────────────────────────────────────
    m.asis_dimensions = {
        "C_base":        ocs.c_base,
        "C_violations":  ocs.c_violations,
        "C_redundancy":  ocs.c_redundancy,
        "C_coupling":    ocs.c_coupling,
    }
    m.target_dimensions = {
        "C_base":        ocs_target.c_base,
        "C_violations":  0,
        "C_redundancy":  0,
        "C_coupling":    0,
    }

    # ── Flow table ─────────────────────────────────────────────────────────
    m.flow_table = [
        {
            "from_app": f["from_app"], "to_app": f["to_app"],
            "queue": f["queue"], "from_qm": f["from_qm"],
            "to_qm": f["to_qm"], "hops": f["hops"],
            "status": "⚠️ Multi-hop" if f["hops"] > 1 else "✅ Direct",
        }
        for f in sorted(tg.comm_flows, key=lambda x: (-x["hops"], x["from_app"]))
    ]

    # ── Channel table ──────────────────────────────────────────────────────
    m.channel_table = [
        {
            "from_app": cp["from_app"], "to_app": cp["to_app"],
            "sender":   cp["sender_channel"],
            "receiver": cp["receiver_channel"],
            "xmit_q":   cp["xmit_queue"],
            "queue_count": len(cp["queues"]),
        }
        for cp in sorted(arts.channel_pairs, key=lambda x: x["sender_channel"])
    ]

    # ── Violation table ────────────────────────────────────────────────────
    sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    m.violation_table = [
        {
            "rule_id":    v.rule_id,
            "severity":   v.severity,
            "description": v.description,
            "score":      v.score_contribution,
            "affected":   ", ".join(str(o) for o in v.affected_objects[:3]),
            "fix":        v.fix_recommendation[:80],
        }
        for v in sorted(report.violations, key=lambda v: sev_order.get(v.severity, 9))
    ]

    log.info(
        f"Metrics built: OCS {ocs.total}→{ocs_target.total} "
        f"({m.ocs_reduction_pct}% reduction), "
        f"{m.asis_violation_count} violations"
    )
    return m
