"""
Topology visualizer — produces interactive HTML graphs using pyvis.
Falls back to matplotlib if pyvis unavailable.
"""
from __future__ import annotations
from pathlib import Path
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph
from src.generator.target_state import TargetStateArtifacts
from src.utils.config import OUTPUT_DIR
from src.utils.logger import get_logger

log = get_logger(__name__)


def visualize_asis(tg: TopologyGraph, output_dir: Path | None = None) -> str | None:
    out = Path(output_dir or OUTPUT_DIR)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "topology_asis.html"
    try:
        from pyvis.network import Network
        net = Network(height="700px", width="100%", bgcolor="#0a0e17",
                      font_color="#e2e8f0", directed=True)
        net.set_options("""{"physics": {"stabilization": {"iterations": 100}}}""")

        added = set()
        for flow in tg.comm_flows:
            for node, color, size in [
                (flow["from_app"], "#ffb300", 20),
                (flow["to_app"],   "#00e5ff", 20),
                (flow["from_qm"],  "#f06292", 14),
                (flow["to_qm"],    "#f06292", 14),
            ]:
                if node and node not in added:
                    added.add(node)
                    net.add_node(node, label=node, color=color, size=size)

            if flow["from_app"] not in added:
                net.add_node(flow["from_app"], color="#ffb300", size=20)
                added.add(flow["from_app"])

            label = f"hops={flow['hops']}"
            color = "#ef4444" if flow["hops"] > 1 else "#4dd0e1"
            net.add_edge(flow["from_app"], flow["to_app"],
                         title=flow["queue"], color=color, label=label)

        net.save_graph(str(path))
        log.info(f"As-is visualization saved: {path}")
        return str(path)
    except ImportError:
        log.warning("pyvis not installed — skipping interactive visualization")
        return _matplotlib_fallback_asis(tg, path)
    except Exception as e:
        log.warning(f"Visualization error: {e}")
        return None


def visualize_target(arts: TargetStateArtifacts, output_dir: Path | None = None) -> str | None:
    out = Path(output_dir or OUTPUT_DIR)
    path = out / "topology_target.html"
    try:
        from pyvis.network import Network
        net = Network(height="700px", width="100%", bgcolor="#0a0e17",
                      font_color="#e2e8f0", directed=True)

        added = set()
        for cp in arts.channel_pairs:
            for node, color, size in [
                (cp["from_qm"], "#00e676", 22),
                (cp["to_qm"],   "#00e676", 22),
            ]:
                if node not in added:
                    added.add(node)
                    net.add_node(node, label=node, color=color, size=size)

            net.add_edge(cp["from_qm"], cp["to_qm"],
                         title=cp["sender_channel"],
                         color="#00e5ff", label=f"{len(cp['queues'])}Q")

        net.save_graph(str(path))
        log.info(f"Target visualization saved: {path}")
        return str(path)
    except ImportError:
        log.warning("pyvis not installed — skipping target visualization")
        return None
    except Exception as e:
        log.warning(f"Target visualization error: {e}")
        return None


def _matplotlib_fallback_asis(tg: TopologyGraph, path: Path) -> str | None:
    try:
        import networkx as nx
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        G = nx.DiGraph()
        for flow in tg.comm_flows:
            G.add_edge(flow["from_app"], flow["to_app"], label=flow["queue"][:20])

        fig, ax = plt.subplots(figsize=(14, 9), facecolor="#0a0e17")
        ax.set_facecolor("#0a0e17")
        pos = nx.spring_layout(G, seed=42)
        nx.draw_networkx(G, pos, ax=ax, node_color="#ffb300",
                         font_color="white", edge_color="#00e5ff",
                         arrows=True, node_size=1500, font_size=9)
        plt.tight_layout()
        png_path = path.with_suffix(".png")
        plt.savefig(str(png_path), dpi=120, bbox_inches="tight",
                    facecolor="#0a0e17")
        plt.close()
        log.info(f"Matplotlib fallback saved: {png_path}")
        return str(png_path)
    except Exception as e:
        log.warning(f"Matplotlib fallback error: {e}")
        return None
