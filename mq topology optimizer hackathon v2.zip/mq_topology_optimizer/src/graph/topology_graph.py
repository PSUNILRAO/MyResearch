"""
Layer 2 — Topology Graph Engine
Builds a NetworkX directed graph from the topology dataset.
Supports: cycle detection, fan-out analysis, path finding, hop counting.
"""
from __future__ import annotations
import networkx as nx
from dataclasses import dataclass, field
from collections import defaultdict
from src.ingestion.loader import TopologyDataset
from src.utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class TopologyGraph:
    G: nx.DiGraph = field(default_factory=nx.DiGraph)
    app_to_qms: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    qm_to_apps: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    queue_types: dict[str, str] = field(default_factory=dict)
    comm_flows: list[dict] = field(default_factory=list)   # [{from_app, to_app, queues}]
    clusters: set[str] = field(default_factory=set)
    alias_queues: list[str] = field(default_factory=list)
    hybrid_queues: list[str] = field(default_factory=list)
    multi_hop_flows: list[dict] = field(default_factory=list)


def build_graph(ds: TopologyDataset) -> TopologyGraph:
    tg = TopologyGraph()
    df = ds.raw_df

    # ── Node: Queue Managers
    for qm in ds.queue_managers:
        tg.G.add_node(qm, node_type="QM", color="#00e5ff")

    # ── Node: Apps
    for app in ds.app_ids:
        tg.G.add_node(app, node_type="APP", color="#ffb300")

    # ── App ↔ QM bindings
    for _, row in df.iterrows():
        app = row["app_id"]
        qm  = row["queue_manager_name"]
        tg.app_to_qms[app].add(qm)
        tg.qm_to_apps[qm].add(app)
        tg.G.add_edge(app, qm, edge_type="HOSTED_ON")

    # ── Queue type catalog
    for _, row in df.iterrows():
        q    = row["Discrete Queue Name"]
        qt   = row.get("q_type", "").strip()
        tg.queue_types[q] = qt
        if "Alias" in qt:
            tg.alias_queues.append(q)
        if ";" in qt:
            tg.hybrid_queues.append(q)

    # ── Cluster catalog
    for _, row in df.iterrows():
        cn = row.get("cluster_name", "").strip()
        if cn:
            tg.clusters.add(cn)

    # ── Communication flows (producer → consumer app pairs)
    flows_seen = set()
    for queue in ds.queues:
        q_rows = df[df["Discrete Queue Name"] == queue]
        prod_rows = q_rows[q_rows["PrimaryAppRole"].str.upper() == "PRODUCER"]
        cons_rows = q_rows[q_rows["PrimaryAppRole"].str.upper() == "CONSUMER"]

        for _, pr in prod_rows.iterrows():
            for _, cr in cons_rows.iterrows():
                from_app = pr["app_id"]
                to_app   = cr["app_id"]
                if from_app == to_app:
                    continue
                key = (from_app, to_app, queue)
                if key not in flows_seen:
                    flows_seen.add(key)

                    from_qm = pr["queue_manager_name"]
                    to_qm   = cr["queue_manager_name"]
                    remote_qm = pr.get("remote_q_mgr_name", "").strip()

                    # Detect multi-hop: intermediate QM in remote_q_mgr
                    hops = 1
                    intermediate = None
                    if remote_qm and remote_qm != to_qm and remote_qm != from_qm and remote_qm in ds.queue_managers:
                        hops = 2
                        intermediate = remote_qm

                    flow = {
                        "from_app": from_app, "to_app": to_app,
                        "queue": queue,
                        "from_qm": from_qm, "to_qm": to_qm,
                        "hops": hops, "intermediate_qm": intermediate,
                        "q_type": pr.get("q_type", ""),
                    }
                    tg.comm_flows.append(flow)
                    tg.G.add_edge(from_app, to_app, edge_type="COMM_FLOW",
                                  queue=queue, hops=hops)

                    if hops > 1:
                        tg.multi_hop_flows.append(flow)

    # Deduplicate lists
    tg.alias_queues  = list(dict.fromkeys(tg.alias_queues))
    tg.hybrid_queues = list(dict.fromkeys(tg.hybrid_queues))

    log.info(
        f"Graph: {tg.G.number_of_nodes()} nodes, {tg.G.number_of_edges()} edges | "
        f"{len(tg.comm_flows)} flows | {len(tg.multi_hop_flows)} multi-hop | "
        f"{len(tg.alias_queues)} alias Qs | {len(tg.clusters)} clusters"
    )
    return tg


def find_cycles(tg: TopologyGraph) -> list[list]:
    """Return all cycles in the app communication graph."""
    app_graph = nx.DiGraph()
    for flow in tg.comm_flows:
        app_graph.add_edge(flow["from_app"], flow["to_app"])
    try:
        return list(nx.simple_cycles(app_graph))
    except Exception:
        return []


def compute_fan_out(tg: TopologyGraph) -> dict[str, int]:
    """Return outgoing flow count per app."""
    fan = defaultdict(int)
    for flow in tg.comm_flows:
        fan[flow["from_app"]] += 1
    return dict(fan)


def find_duplicate_queues(ds: TopologyDataset) -> list[str]:
    """Queues with .IO variants (candidate duplicates)."""
    queues = ds.queues
    dups = []
    for q in queues:
        if q.endswith(".IO") and q[:-3] in queues:
            dups.append(q)
    return dups
