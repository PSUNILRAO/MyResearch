"""
Layer 5 — Target State Generator
Produces: target topology CSV, MQSC scripts, Terraform config, decision log.
Applies 1-QM-per-app rule and deterministic naming to all artifacts.
"""
from __future__ import annotations
import json
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
import pandas as pd
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph
from src.constraints.engine import ConstraintReport
from src.utils.config import load_constraints_config, OUTPUT_DIR
from src.utils.logger import get_logger

log = get_logger(__name__)

CSV_COLUMNS = [
    "Discrete Queue Name", "queue_manager_name", "app_id", "q_type",
    "PrimaryAppRole", "remote_q_mgr_name", "remote_q_name",
    "xmit_q_name", "usage", "channel_sender", "channel_receiver",
    "Primary Neighborhood", "line_of_business", "Neighborhood",
]


@dataclass
class TargetStateArtifacts:
    target_df: pd.DataFrame = field(default_factory=pd.DataFrame)
    mqsc_commands: list[str] = field(default_factory=list)
    terraform_hcl: str = ""
    decision_log: list[dict] = field(default_factory=list)
    target_qms: list[str] = field(default_factory=list)
    channel_pairs: list[dict] = field(default_factory=list)
    ocs_target_breakdown: dict = field(default_factory=dict)


def _qm_name(app_id: str) -> str:
    return f"QM.{app_id}"


def _xmit_name(dst_app: str) -> str:
    return f"XMIT.QM.{dst_app}"


def _sender_channel(src_app: str, dst_app: str) -> str:
    return f"QM.{src_app}.QM.{dst_app}"


def _receiver_channel(dst_app: str, src_app: str) -> str:
    return f"QM.{dst_app}.QM.{src_app}"


def generate_target_state(
    ds: TopologyDataset,
    tg: TopologyGraph,
    report: ConstraintReport,
) -> TargetStateArtifacts:
    cfg      = load_constraints_config()
    arts     = TargetStateArtifacts()
    rows     = []
    mqsc     = []
    decisions = []

    # ── 1. Derive unique communication flows (dedup by from_app / to_app) ──
    flow_map: dict[tuple, dict] = {}
    for flow in tg.comm_flows:
        fa, ta = flow["from_app"], flow["to_app"]
        if fa == ta:
            continue
        key = (fa, ta)
        if key not in flow_map:
            flow_map[key] = {"from_app": fa, "to_app": ta, "queues": []}
        flow_map[key]["queues"].append(flow["queue"])

    # ── 2. Build per-app metadata lookup ──────────────────────────────────
    app_meta = {}
    for app in ds.app_ids:
        app_rows = ds.raw_df[ds.raw_df["app_id"] == app]
        app_meta[app] = {
            "lob":  app_rows["line_of_business"].iloc[0] if "line_of_business" in app_rows.columns and len(app_rows) else "",
            "nbhd": app_rows["Neighborhood"].iloc[0] if "Neighborhood" in app_rows.columns and len(app_rows) else "",
        }

    # ── 3. Decision: 1 QM per app ─────────────────────────────────────────
    target_qms = [_qm_name(app) for app in sorted(ds.app_ids)]
    arts.target_qms = target_qms

    for app in sorted(ds.app_ids):
        old_qms = sorted(tg.app_to_qms.get(app, set()))
        decisions.append({
            "decision_id": f"D-QM-{app}",
            "type": "QM_CONSOLIDATION",
            "app_id": app,
            "old_qms": old_qms,
            "new_qm": _qm_name(app),
            "constraint": "C1 — 1 QM per AppID",
            "evidence": f"App '{app}' found on {len(old_qms)} QMs: {old_qms}",
            "confidence": 0.99,
            "rationale": (
                f"Consolidating app '{app}' from {len(old_qms)} QMs to single "
                f"QM.{app} eliminates split ownership and enables predictable routing."
            ),
        })

    # ── 4. Generate queue + channel rows per flow ──────────────────────────
    seen_channels = set()

    for (fa, ta), flow_info in sorted(flow_map.items()):
        src_qm   = _qm_name(fa)
        dst_qm   = _qm_name(ta)
        xmit_q   = _xmit_name(ta)
        sdr_chl  = _sender_channel(fa, ta)
        rcv_chl  = _receiver_channel(ta, fa)
        meta_src = app_meta.get(fa, {})
        meta_dst = app_meta.get(ta, {})

        # ── Remote queue row (on producer QM) ────────────────────────────
        for queue in sorted(set(flow_info["queues"])):
            rows.append({
                "Discrete Queue Name":  queue,
                "queue_manager_name":   src_qm,
                "app_id":              fa,
                "q_type":              "Remote",
                "PrimaryAppRole":      "Producer",
                "remote_q_mgr_name":   dst_qm,
                "remote_q_name":       queue,
                "xmit_q_name":        xmit_q,
                "usage":              "Normal",
                "channel_sender":     sdr_chl,
                "channel_receiver":   rcv_chl,
                "Primary Neighborhood": meta_src.get("nbhd", ""),
                "line_of_business":   meta_src.get("lob", ""),
                "Neighborhood":       meta_src.get("nbhd", ""),
            })

            # ── Local queue row (on consumer QM) ─────────────────────────
            rows.append({
                "Discrete Queue Name":  queue,
                "queue_manager_name":   dst_qm,
                "app_id":              ta,
                "q_type":              "Local",
                "PrimaryAppRole":      "Consumer",
                "remote_q_mgr_name":   "",
                "remote_q_name":       "",
                "xmit_q_name":        "",
                "usage":              "Normal",
                "channel_sender":     sdr_chl,
                "channel_receiver":   rcv_chl,
                "Primary Neighborhood": meta_dst.get("nbhd", ""),
                "line_of_business":   meta_dst.get("lob", ""),
                "Neighborhood":       meta_dst.get("nbhd", ""),
            })

        # ── XMIT queue row ────────────────────────────────────────────────
        rows.append({
            "Discrete Queue Name":  xmit_q,
            "queue_manager_name":   src_qm,
            "app_id":              fa,
            "q_type":              "Local",
            "PrimaryAppRole":      "XMIT",
            "remote_q_mgr_name":   "",
            "remote_q_name":       "",
            "xmit_q_name":        "",
            "usage":              "XMITQ",
            "channel_sender":     sdr_chl,
            "channel_receiver":   rcv_chl,
            "Primary Neighborhood": meta_src.get("nbhd", ""),
            "line_of_business":   meta_src.get("lob", ""),
            "Neighborhood":       meta_src.get("nbhd", ""),
        })

        # ── Channel pair record ───────────────────────────────────────────
        if (fa, ta) not in seen_channels:
            seen_channels.add((fa, ta))
            arts.channel_pairs.append({
                "from_app": fa, "to_app": ta,
                "from_qm": src_qm, "to_qm": dst_qm,
                "sender_channel": sdr_chl,
                "receiver_channel": rcv_chl,
                "xmit_queue": xmit_q,
                "queues": sorted(set(flow_info["queues"])),
            })

        decisions.append({
            "decision_id": f"D-FLOW-{fa}-{ta}",
            "type": "CHANNEL_PAIR",
            "from_app": fa, "to_app": ta,
            "sender": sdr_chl, "receiver": rcv_chl,
            "xmit_queue": xmit_q,
            "constraint": "C4 — Deterministic channel naming",
            "evidence": f"{len(flow_info['queues'])} queues in flow",
            "confidence": 0.99,
            "rationale": (
                f"Direct channel pair replaces any multi-hop or cluster routing. "
                f"1 XMIT queue on {src_qm} for all traffic to {dst_qm}. "
                f"Shared sender channel reduces channel sprawl."
            ),
        })

    arts.target_df    = pd.DataFrame(rows, columns=CSV_COLUMNS)
    arts.decision_log = decisions

    # ── 5. MQSC generation ────────────────────────────────────────────────
    mqsc.append("* ============================================================")
    mqsc.append("* TARGET STATE MQSC — Generated by MQ Topology Optimizer")
    mqsc.append("* Apply to each QM in sequence. Idempotent (safe to re-run).")
    mqsc.append("* ============================================================")
    mqsc.append("")

    # Define QMs
    mqsc.append("* ── STEP 1: Define Queue Managers ──────────────────────────")
    for qm in sorted(target_qms):
        mqsc.append(f"DEFINE QMGR('{qm}') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE")
    mqsc.append("")

    # Define XMIT queues
    mqsc.append("* ── STEP 2: Define Transmission Queues ─────────────────────")
    for cp in sorted(arts.channel_pairs, key=lambda x: x["xmit_queue"]):
        mqsc.append(
            f"DEFINE QLOCAL('{cp['xmit_queue']}') "
            f"USAGE(XMITQ) DEFPSIST(YES) REPLACE"
        )
    mqsc.append("")

    # Define Remote queues
    mqsc.append("* ── STEP 3: Define Remote Queues (on producer QMs) ─────────")
    for cp in sorted(arts.channel_pairs, key=lambda x: (x["from_qm"], x["to_qm"])):
        for q in cp["queues"]:
            mqsc.append(
                f"DEFINE QREMOTE('{q}') "
                f"RNAME('{q}') RQMNAME('{cp['to_qm']}') "
                f"XMITQ('{cp['xmit_queue']}') REPLACE"
            )
    mqsc.append("")

    # Define Local queues
    mqsc.append("* ── STEP 4: Define Local Queues (on consumer QMs) ──────────")
    for cp in sorted(arts.channel_pairs, key=lambda x: (x["to_qm"], x["from_qm"])):
        for q in cp["queues"]:
            mqsc.append(
                f"DEFINE QLOCAL('{q}') "
                f"DEFPSIST(YES) DEFPRESP(SYNC) REPLACE"
            )
    mqsc.append("")

    # Define Channels
    mqsc.append("* ── STEP 5: Define Sender/Receiver Channels ────────────────")
    for cp in sorted(arts.channel_pairs, key=lambda x: x["sender_channel"]):
        mqsc.append(
            f"DEFINE CHANNEL('{cp['sender_channel']}') "
            f"CHLTYPE(SDR) CONNAME('{cp['to_qm']}(1414)') "
            f"XMITQ('{cp['xmit_queue']}') SSLCIPH(TLS_RSA_WITH_AES_256_CBC_SHA256) REPLACE"
        )
        mqsc.append(
            f"DEFINE CHANNEL('{cp['receiver_channel']}') "
            f"CHLTYPE(RCVR) SSLCIPH(TLS_RSA_WITH_AES_256_CBC_SHA256) REPLACE"
        )
    mqsc.append("")

    # Start channels
    mqsc.append("* ── STEP 6: Start Sender Channels ─────────────────────────")
    for cp in sorted(arts.channel_pairs, key=lambda x: x["sender_channel"]):
        mqsc.append(f"START CHANNEL('{cp['sender_channel']}')")
    mqsc.append("")
    mqsc.append("* ── END OF MQSC ─────────────────────────────────────────────")

    arts.mqsc_commands = mqsc

    # ── 6. Terraform HCL ──────────────────────────────────────────────────
    tf_lines = [
        '# ================================================================',
        '# TARGET STATE — Terraform IBM MQ Resources',
        '# Generated by MQ Topology Optimizer',
        '# ================================================================',
        '',
        'terraform {',
        '  required_providers {',
        '    ibm = { source = "IBM-Cloud/ibm" version = "~> 1.0" }',
        '  }',
        '}',
        '',
        '# ── Queue Managers ───────────────────────────────────────────────',
    ]
    for qm in sorted(target_qms):
        safe = qm.replace(".", "_").replace("-", "_").lower()
        tf_lines += [
            f'resource "ibm_mq_queue_manager" "{safe}" {{',
            f'  name         = "{qm}"',
            f'  chl_auth     = "ENABLED"',
            f'  conn_auth    = "REQUIRED"',
            f'}}',
            '',
        ]

    tf_lines.append('# ── Channels ──────────────────────────────────────────────────')
    for cp in sorted(arts.channel_pairs, key=lambda x: x["sender_channel"]):
        safe_sdr = cp["sender_channel"].replace(".", "_").lower()
        tf_lines += [
            f'resource "ibm_mq_channel" "{safe_sdr}" {{',
            f'  name          = "{cp["sender_channel"]}"',
            f'  type          = "SDR"',
            f'  queue_manager = "{cp["from_qm"]}"',
            f'  xmit_queue    = "{cp["xmit_queue"]}"',
            f'  ssl_cipher    = "TLS_RSA_WITH_AES_256_CBC_SHA256"',
            f'}}',
            '',
        ]

    arts.terraform_hcl = "\n".join(tf_lines)

    log.info(
        f"Target state: {len(target_qms)} QMs, {len(arts.channel_pairs)} channel pairs, "
        f"{len(rows)} queue rows, {len(mqsc)} MQSC lines"
    )
    return arts
