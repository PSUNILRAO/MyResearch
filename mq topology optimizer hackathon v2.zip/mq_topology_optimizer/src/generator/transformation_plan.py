"""
Transformation Plan Generator
Produces a 5-phase, ordered migration plan from as-is to target state.
Each step is actionable, sequenced, and tied to specific objects.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph
from src.constraints.engine import ConstraintReport
from src.generator.target_state import TargetStateArtifacts
from src.utils.logger import get_logger

log = get_logger(__name__)


@dataclass
class TransformStep:
    step_id: str
    phase: int
    phase_name: str
    action: str
    description: str
    objects_affected: list[str]
    mqsc_hint: str
    risk: str          # LOW / MEDIUM / HIGH
    rollback: str
    duration_estimate: str


@dataclass
class TransformationPlan:
    phases: dict[int, list[TransformStep]] = field(default_factory=dict)
    total_steps: int = 0
    estimated_duration: str = ""
    decommission_list: list[str] = field(default_factory=list)
    provision_list: list[str] = field(default_factory=list)

    def all_steps(self) -> list[TransformStep]:
        steps = []
        for phase_steps in self.phases.values():
            steps.extend(phase_steps)
        return sorted(steps, key=lambda s: s.step_id)

    def steps_for_phase(self, phase: int) -> list[TransformStep]:
        return self.phases.get(phase, [])

    def to_markdown(self) -> str:
        lines = [
            "# MQ Topology Transformation Plan",
            "",
            f"**Total Steps:** {self.total_steps}  ",
            f"**Estimated Duration:** {self.estimated_duration}  ",
            f"**New QMs to Provision:** {len(self.provision_list)}  ",
            f"**Legacy QMs to Decommission:** {len(self.decommission_list)}  ",
            "",
        ]
        phase_names = {
            1: "Audit & Freeze",
            2: "Provision Target QMs",
            3: "Migrate Flows (per app pair)",
            4: "Decommission Legacy Objects",
            5: "Validate & Automate",
        }
        phase_durations = {1: "Week 1-2", 2: "Week 2-3",
                           3: "Week 3-5", 4: "Week 5-6", 5: "Week 6-7"}
        for phase_num in sorted(self.phases.keys()):
            phase_steps = self.phases[phase_num]
            lines += [
                f"---",
                f"## Phase {phase_num}: {phase_names.get(phase_num,'')} "
                f"({phase_durations.get(phase_num,'')})",
                "",
            ]
            for s in phase_steps:
                lines += [
                    f"### {s.step_id} — {s.action}",
                    f"**Risk:** {s.risk}  ",
                    f"**Duration:** {s.duration_estimate}  ",
                    f"**Objects:** `{', '.join(s.objects_affected[:5])}`",
                    "",
                    s.description,
                    "",
                    f"```mqsc",
                    f"{s.mqsc_hint}",
                    f"```",
                    "",
                    f"**Rollback:** {s.rollback}",
                    "",
                ]
        return "\n".join(lines)


def generate_transformation_plan(
    ds: TopologyDataset,
    tg: TopologyGraph,
    report: ConstraintReport,
    arts: TargetStateArtifacts,
) -> TransformationPlan:

    plan = TransformationPlan()
    plan.provision_list = list(arts.target_qms)
    plan.decommission_list = [
        qm for qm in ds.queue_managers
        if qm not in arts.target_qms
    ]

    step_counter = [0]

    def next_id(phase: int) -> str:
        step_counter[0] += 1
        return f"P{phase}-S{step_counter[0]:02d}"

    # ── Phase 1: Audit & Freeze ─────────────────────────────────────────
    p1 = []
    p1.append(TransformStep(
        step_id=next_id(1), phase=1, phase_name="Audit & Freeze",
        action="Export full MQ object inventory",
        description=(
            f"Run DISPLAY commands across all {len(ds.queue_managers)} queue managers "
            f"to export complete object catalog: queue managers, queues, channels, "
            f"authority records. Store as baseline snapshot."
        ),
        objects_affected=list(ds.queue_managers),
        mqsc_hint=(
            "DISPLAY QMGR ALL\n"
            "DISPLAY Q(*) ALL\n"
            "DISPLAY CHANNEL(*) ALL\n"
            "DISPLAY AUTHINFO(*) ALL"
        ),
        risk="LOW",
        rollback="No changes made — read-only operation",
        duration_estimate="1-2 days",
    ))
    p1.append(TransformStep(
        step_id=next_id(1), phase=1, phase_name="Audit & Freeze",
        action="Document all active application connections",
        description=(
            f"Map every AppID to its current QM(s). "
            f"Identify {sum(1 for v in report.violations if v.rule_id=='C1_ONE_QM_PER_APP')} "
            f"apps violating the 1-QM constraint. "
            f"Verify {len(tg.alias_queues)} alias queues have no exclusive consumers."
        ),
        objects_affected=list(ds.app_ids),
        mqsc_hint=(
            "DISPLAY CONN(*) ALL\n"
            "DISPLAY QSTATUS(*) TYPE(HANDLE)"
        ),
        risk="LOW",
        rollback="N/A — documentation only",
        duration_estimate="1 day",
    ))
    p1.append(TransformStep(
        step_id=next_id(1), phase=1, phase_name="Audit & Freeze",
        action="Freeze topology — no new MQ objects permitted",
        description=(
            "Issue change freeze covering all MQ environments. "
            "All new topology requests queued to target-state design. "
            "Communicate freeze timeline to application teams."
        ),
        objects_affected=["ALL ENVIRONMENTS"],
        mqsc_hint="* Change freeze — no MQSC changes without approval",
        risk="LOW",
        rollback="Lift freeze if timeline slips",
        duration_estimate="0.5 days (process)",
    ))
    p1.append(TransformStep(
        step_id=next_id(1), phase=1, phase_name="Audit & Freeze",
        action="Drain and verify dead-letter queues",
        description=(
            "Ensure all DLQ depths are zero before migration begins. "
            "Unresolvable DLQ messages indicate existing routing problems "
            "that must be resolved before migration."
        ),
        objects_affected=["SYSTEM.DEAD.LETTER.QUEUE on all QMs"],
        mqsc_hint="DISPLAY QLOCAL(SYSTEM.DEAD.LETTER.QUEUE) CURDEPTH",
        risk="MEDIUM",
        rollback="Fix DLQ root cause before proceeding",
        duration_estimate="1-2 days",
    ))
    plan.phases[1] = p1

    # ── Phase 2: Provision Target QMs ───────────────────────────────────
    p2 = []
    p2.append(TransformStep(
        step_id=next_id(2), phase=2, phase_name="Provision Target QMs",
        action=f"Provision {len(arts.target_qms)} new Queue Managers",
        description=(
            f"Create all target QMs following naming convention QM.<AppID>. "
            f"Apply secure-by-default config: CHLAUTH(ENABLED), CONNAUTH(REQUIRED), "
            f"TLS cipher suites enforced. "
            f"Target QMs: {', '.join(sorted(arts.target_qms)[:8])}..."
        ),
        objects_affected=arts.target_qms,
        mqsc_hint="\n".join(
            f"DEFINE QMGR('{qm}') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE"
            for qm in sorted(arts.target_qms)[:5]
        ) + "\n* ... (see target_state.mqsc for full list)",
        risk="LOW",
        rollback="DELETE QMGR for each provisioned QM",
        duration_estimate="2-3 days",
    ))
    p2.append(TransformStep(
        step_id=next_id(2), phase=2, phase_name="Provision Target QMs",
        action=f"Create {len(arts.channel_pairs)} XMIT queue pairs",
        description=(
            f"Define one XMIT queue per outbound destination on each producer QM. "
            f"XMIT queues isolate per-destination traffic and enable independent "
            f"channel control."
        ),
        objects_affected=[cp["xmit_queue"] for cp in arts.channel_pairs],
        mqsc_hint="\n".join(
            f"DEFINE QLOCAL('{cp['xmit_queue']}') USAGE(XMITQ) DEFPSIST(YES) REPLACE"
            for cp in sorted(arts.channel_pairs, key=lambda x: x["xmit_queue"])[:5]
        ),
        risk="LOW",
        rollback="DELETE QLOCAL for each XMIT queue",
        duration_estimate="1 day",
    ))
    p2.append(TransformStep(
        step_id=next_id(2), phase=2, phase_name="Provision Target QMs",
        action="Define all Sender/Receiver channel pairs",
        description=(
            f"Create {len(arts.channel_pairs)} sender + {len(arts.channel_pairs)} receiver "
            f"channels using deterministic naming QM.SRC.QM.DST / QM.DST.QM.SRC. "
            f"All channels configured with TLS."
        ),
        objects_affected=[cp["sender_channel"] for cp in arts.channel_pairs] +
                         [cp["receiver_channel"] for cp in arts.channel_pairs],
        mqsc_hint=(
            f"DEFINE CHANNEL('{arts.channel_pairs[0]['sender_channel'] if arts.channel_pairs else 'QM.A.QM.B'}') "
            f"CHLTYPE(SDR) CONNAME('target-host(1414)') "
            f"XMITQ('{arts.channel_pairs[0]['xmit_queue'] if arts.channel_pairs else 'XMIT.QM.B'}') "
            f"SSLCIPH(TLS_RSA_WITH_AES_256_CBC_SHA256) REPLACE"
        ),
        risk="MEDIUM",
        rollback="STOP CHANNEL then DELETE CHANNEL",
        duration_estimate="2 days",
    ))
    plan.phases[2] = p2

    # ── Phase 3: Migrate Flows ────────────────────────────────────────────
    p3 = []
    for cp in sorted(arts.channel_pairs, key=lambda x: (x["from_app"], x["to_app"])):
        p3.append(TransformStep(
            step_id=next_id(3), phase=3,
            phase_name="Migrate Flows",
            action=f"Migrate flow: {cp['from_app']} → {cp['to_app']}",
            description=(
                f"Define Remote queue on {cp['from_qm']} → {cp['to_qm']}. "
                f"Define Local queue(s) on {cp['to_qm']}. "
                f"Queues: {', '.join(cp['queues'][:3])}. "
                f"Update CCDT for app {cp['from_app']}. "
                f"Run parallel (old + new QM) until message parity confirmed. "
                f"Cutover: drain old queue to depth 0 then switch."
            ),
            objects_affected=cp["queues"] + [cp["from_qm"], cp["to_qm"]],
            mqsc_hint=(
                f"* On {cp['from_qm']}:\n"
                f"DEFINE QREMOTE('{cp['queues'][0] if cp['queues'] else 'QUEUE'}') "
                f"RNAME('{cp['queues'][0] if cp['queues'] else 'QUEUE'}') "
                f"RQMNAME('{cp['to_qm']}') XMITQ('{cp['xmit_queue']}') REPLACE\n"
                f"* On {cp['to_qm']}:\n"
                f"DEFINE QLOCAL('{cp['queues'][0] if cp['queues'] else 'QUEUE'}') "
                f"DEFPSIST(YES) REPLACE\n"
                f"START CHANNEL('{cp['sender_channel']}')"
            ),
            risk="HIGH",
            rollback=(
                f"Stop {cp['sender_channel']}. Repoint app {cp['from_app']} "
                f"CCDT back to legacy QM. Drain new queue → old queue via temporary bridge."
            ),
            duration_estimate="1-2 days per flow",
        ))
    plan.phases[3] = p3

    # ── Phase 4: Decommission Legacy Objects ─────────────────────────────
    p4 = []
    if tg.alias_queues:
        p4.append(TransformStep(
            step_id=next_id(4), phase=4, phase_name="Decommission Legacy Objects",
            action=f"Delete {len(tg.alias_queues)} Alias queue definitions",
            description=(
                f"Remove all Alias queue definitions. "
                f"Verify zero consumers on each before deletion. "
                f"Alias queues: {', '.join(tg.alias_queues[:5])}"
            ),
            objects_affected=tg.alias_queues,
            mqsc_hint="\n".join(
                f"DISPLAY QSTATUS('{q}') TYPE(HANDLE) + DELETE QALIAS('{q}')"
                for q in tg.alias_queues[:3]
            ),
            risk="MEDIUM",
            rollback="Recreate DEFINE QALIAS if consumers still reference it",
            duration_estimate="0.5 days",
        ))
    if tg.hybrid_queues:
        p4.append(TransformStep(
            step_id=next_id(4), phase=4, phase_name="Decommission Legacy Objects",
            action=f"Remove {len(tg.hybrid_queues)} hybrid queue type definitions",
            description=(
                "Delete queues with ambiguous types (Remote;Local, Local;Remote, etc). "
                "These have been replaced by unambiguous definitions in Phase 3."
            ),
            objects_affected=tg.hybrid_queues[:10],
            mqsc_hint="DELETE QLOCAL('<hybrid_queue_name>')",
            risk="MEDIUM",
            rollback="Recreate from original MQSC backup",
            duration_estimate="0.5 days",
        ))
    if tg.clusters:
        p4.append(TransformStep(
            step_id=next_id(4), phase=4, phase_name="Decommission Legacy Objects",
            action=f"Decommission {len(tg.clusters)} MQ Clusters",
            description=(
                f"Remove cluster definitions: {', '.join(sorted(tg.clusters))}. "
                f"Verify no active cluster receivers or cluster-queues before removal. "
                f"Replace any remaining cluster channels with explicit sender/receiver pairs."
            ),
            objects_affected=list(tg.clusters),
            mqsc_hint=(
                "DISPLAY CHANNEL(*) WHERE(CHLTYPE EQ CLUSSDR)\n"
                "DISPLAY QCLUSTER(*)\n"
                "* After verifying empty:\n"
                "ALTER QMGR REPOS(' ')"
            ),
            risk="HIGH",
            rollback="Restore REPOS attribute and cluster channel definitions",
            duration_estimate="1-2 days",
        ))
    if plan.decommission_list:
        p4.append(TransformStep(
            step_id=next_id(4), phase=4, phase_name="Decommission Legacy Objects",
            action=f"Decommission {len(plan.decommission_list)} legacy Queue Managers",
            description=(
                f"Stop and decommission original QMs after confirming all apps "
                f"have been migrated to target QMs and all queues are at depth 0. "
                f"QMs to decommission: {', '.join(plan.decommission_list[:6])}"
            ),
            objects_affected=plan.decommission_list,
            mqsc_hint=(
                "* Verify zero depth on all queues:\n"
                "DISPLAY QLOCAL(*) CURDEPTH\n"
                "* Then end QM:\n"
                "ENDMQM -i <QMGR_NAME>"
            ),
            risk="HIGH",
            rollback="Restart legacy QM: strmqm <QMGR_NAME>",
            duration_estimate="1 day",
        ))
    plan.phases[4] = p4

    # ── Phase 5: Validate & Automate ─────────────────────────────────────
    p5 = []
    p5.append(TransformStep(
        step_id=next_id(5), phase=5, phase_name="Validate & Automate",
        action="Run OCS validation on live target topology",
        description=(
            f"Re-run complexity scoring against live environment. "
            f"Verify OCS has dropped from as-is value. "
            f"Confirm 0 constraint violations in target environment."
        ),
        objects_affected=arts.target_qms,
        mqsc_hint="python scripts/validate_target.py --env production",
        risk="LOW",
        rollback="N/A — validation only",
        duration_estimate="0.5 days",
    ))
    p5.append(TransformStep(
        step_id=next_id(5), phase=5, phase_name="Validate & Automate",
        action="Activate channel health monitoring",
        description=(
            "Enable monitoring on all new sender channels. "
            "Configure alerts: channel INACTIVE > 5min, "
            "XMIT queue depth > 500, DLQ depth > 0."
        ),
        objects_affected=[cp["sender_channel"] for cp in arts.channel_pairs],
        mqsc_hint=(
            "DISPLAY CHSTATUS(*) ALL\n"
            "* Configure alerts in IBM MQ Console or Instana"
        ),
        risk="LOW",
        rollback="N/A",
        duration_estimate="1 day",
    ))
    p5.append(TransformStep(
        step_id=next_id(5), phase=5, phase_name="Validate & Automate",
        action="Commit target topology to GitOps repository",
        description=(
            "Push target_state.mqsc and main.tf to Git repository. "
            "Tag release with version and OCS score. "
            "Enable drift detection: schedule daily comparison of "
            "live config vs IaC state."
        ),
        objects_affected=["Git repository", "CI/CD pipeline"],
        mqsc_hint=(
            "git add outputs/target_state.mqsc outputs/main.tf\n"
            "git commit -m 'feat: apply target topology (OCS reduced)'\n"
            "git tag v1.0-target-state"
        ),
        risk="LOW",
        rollback="git revert",
        duration_estimate="0.5 days",
    ))
    p5.append(TransformStep(
        step_id=next_id(5), phase=5, phase_name="Validate & Automate",
        action="Conduct post-migration application smoke tests",
        description=(
            "For each migrated flow, verify end-to-end message delivery: "
            "producer sends test message → verify consumer receives it on new QM. "
            "Check message persistence, TRTC compliance, and data classification."
        ),
        objects_affected=list(ds.app_ids),
        mqsc_hint=(
            "* Put test message:\n"
            "amqsput <QNAME> <QMGR>\n"
            "* Get from consumer QM:\n"
            "amqsget <QNAME> <QMGR>"
        ),
        risk="LOW",
        rollback="Escalate to Phase 3 rollback if message loss detected",
        duration_estimate="2-3 days",
    ))
    plan.phases[5] = p5

    plan.total_steps = sum(len(v) for v in plan.phases.values())
    plan.estimated_duration = "6-7 weeks"

    log.info(
        f"Transformation plan: {plan.total_steps} steps across 5 phases | "
        f"{len(plan.provision_list)} QMs to provision | "
        f"{len(plan.decommission_list)} QMs to decommission"
    )
    return plan
