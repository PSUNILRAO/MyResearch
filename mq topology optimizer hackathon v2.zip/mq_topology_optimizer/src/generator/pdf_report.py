"""
PDF Report Generator
Produces a professional hackathon submission report using ReportLab.
Falls back to plain-text if ReportLab not installed.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
from src.ingestion.loader import TopologyDataset
from src.graph.topology_graph import TopologyGraph
from src.constraints.engine import ConstraintReport
from src.observability.ocs_scorer import OCSResult
from src.generator.target_state import TargetStateArtifacts
from src.agent.analysis_agent import AgentReport
from src.utils.config import OUTPUT_DIR
from src.utils.logger import get_logger

log = get_logger(__name__)


def generate_pdf_report(
    ds: TopologyDataset,
    tg: TopologyGraph,
    report: ConstraintReport,
    ocs_asis: OCSResult,
    ocs_target: OCSResult,
    arts: TargetStateArtifacts,
    agent: AgentReport,
    output_dir: Path | None = None,
) -> str:
    out = Path(output_dir or OUTPUT_DIR)
    out.mkdir(parents=True, exist_ok=True)
    pdf_path = out / "hackathon_report.pdf"

    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
            HRFlowable, PageBreak,
        )
        from reportlab.lib.enums import TA_CENTER, TA_LEFT

        doc = SimpleDocTemplate(
            str(pdf_path), pagesize=A4,
            rightMargin=2*cm, leftMargin=2*cm,
            topMargin=2.5*cm, bottomMargin=2*cm,
        )

        styles = getSampleStyleSheet()
        NAVY  = colors.HexColor("#05080f")
        CYAN  = colors.HexColor("#00b4cc")
        AMBER = colors.HexColor("#e6a800")
        GREEN = colors.HexColor("#00c46b")
        RED   = colors.HexColor("#d93030")
        LGREY = colors.HexColor("#f0f4f8")

        title_style = ParagraphStyle("Title", parent=styles["Title"],
            fontSize=22, textColor=NAVY, spaceAfter=6, alignment=TA_CENTER)
        subtitle_style = ParagraphStyle("Sub", parent=styles["Normal"],
            fontSize=12, textColor=CYAN, alignment=TA_CENTER, spaceAfter=14)
        h1_style = ParagraphStyle("H1", parent=styles["Heading1"],
            fontSize=14, textColor=NAVY, spaceBefore=16, spaceAfter=6,
            borderPad=4, backColor=LGREY)
        h2_style = ParagraphStyle("H2", parent=styles["Heading2"],
            fontSize=12, textColor=CYAN, spaceBefore=10, spaceAfter=4)
        body_style = ParagraphStyle("Body", parent=styles["Normal"],
            fontSize=10, leading=14, spaceAfter=6)
        code_style = ParagraphStyle("Code", parent=styles["Code"],
            fontSize=8, leading=11, backColor=colors.HexColor("#1e2d45"),
            textColor=colors.HexColor("#e2e8f0"))

        def hr(): return HRFlowable(width="100%", thickness=1,
                                     color=CYAN, spaceAfter=8, spaceBefore=4)
        def sp(n=6): return Spacer(1, n)

        reduction = round((1 - ocs_target.total / max(ocs_asis.total, 1)) * 100, 1)
        story = []

        # ── Cover ────────────────────────────────────────────────────────
        story += [
            sp(40),
            Paragraph("IBM MQ HACKATHON SUBMISSION", subtitle_style),
            Paragraph("Intelligent MQ Topology<br/>Simplification &amp; Automation", title_style),
            hr(),
            sp(10),
        ]

        kpi_data = [
            ["Metric", "As-Is", "Target", "Change"],
            ["Queue Managers",   str(len(ds.queue_managers)), str(len(arts.target_qms)), "Isolated 1/app"],
            ["Constraint Violations", str(len(report.violations)), "0", "–100%"],
            ["OCS Score",        str(ocs_asis.total), str(ocs_target.total), f"–{reduction}%"],
            ["Channel Pairs",    "~multi-hop", str(len(arts.channel_pairs)), "Direct only"],
            ["Alias Queues",     str(len(tg.alias_queues)), "0", "Eliminated"],
            ["MQ Clusters",      str(len(tg.clusters)), "0", "Eliminated"],
        ]
        kpi_table = Table(kpi_data, colWidths=[5.5*cm, 3*cm, 3*cm, 4*cm])
        kpi_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
            ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",   (0,0), (-1,-1), 9),
            ("BACKGROUND", (0,1), (-1,-1), LGREY),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LGREY]),
            ("GRID",       (0,0), (-1,-1), 0.5, colors.HexColor("#cccccc")),
            ("ALIGN",      (1,0), (-1,-1), "CENTER"),
            ("FONTNAME",   (3,1), (3,-1), "Helvetica-Bold"),
            ("TEXTCOLOR",  (3,1), (3,-1), GREEN),
        ]))
        story += [kpi_table, sp(20)]
        story.append(Paragraph(
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}  |  "
            f"Agent Confidence: {agent.overall_confidence:.0%}  |  "
            f"Human Review: {'Required' if agent.human_review_required else 'Not Required'}",
            subtitle_style,
        ))
        story.append(PageBreak())

        # ── Section 1: Problem Statement ─────────────────────────────────
        story += [Paragraph("1. Problem Statement", h1_style), hr()]
        story.append(Paragraph(
            f"The input MQ topology contains <b>{len(ds.queue_managers)} queue managers</b> "
            f"serving <b>{len(ds.app_ids)} applications</b> with <b>{len(ds.queues)} queues</b> "
            f"and <b>{len(tg.comm_flows)} communication flows</b>. "
            f"Analysis identified <b>{len(report.violations)} constraint violations</b> "
            f"including <b>{len(report.critical_violations)} CRITICAL</b> violations. "
            f"The dominant issue is application sprawl across multiple queue managers, "
            f"directly violating the enterprise constraint of 1 QM per AppID.",
            body_style,
        ))

        # Anti-pattern table
        story.append(Paragraph("Detected Anti-Patterns", h2_style))
        sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        sorted_v = sorted(report.violations, key=lambda v: sev_order.get(v.severity, 9))[:8]
        ap_data = [["Severity", "Rule", "Description", "OCS Impact"]]
        sev_colors_map = {
            "CRITICAL": RED, "HIGH": AMBER, "MEDIUM": colors.purple, "LOW": colors.grey
        }
        for v in sorted_v:
            ap_data.append([v.severity, v.rule_id.replace("_"," ")[:20],
                            v.description[:60], f"+{v.score_contribution}"])
        ap_table = Table(ap_data, colWidths=[2.5*cm, 4.5*cm, 7.5*cm, 2*cm])
        ap_style = [
            ("BACKGROUND", (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
            ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",   (0,0), (-1,-1), 8),
            ("GRID",       (0,0), (-1,-1), 0.3, colors.lightgrey),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LGREY]),
        ]
        for i, v in enumerate(sorted_v, 1):
            c = sev_colors_map.get(v.severity, colors.grey)
            ap_style.append(("TEXTCOLOR", (0,i), (0,i), c))
            ap_style.append(("FONTNAME",  (0,i), (0,i), "Helvetica-Bold"))
        ap_table.setStyle(TableStyle(ap_style))
        story += [ap_table, sp()]

        story.append(PageBreak())

        # ── Section 2: OCS ────────────────────────────────────────────────
        story += [Paragraph("2. Operational Complexity Score (OCS)", h1_style), hr()]
        story.append(Paragraph(
            "The OCS formula quantifies topology complexity across four dimensions. "
            "It provides a single comparable metric for before/after measurement.",
            body_style,
        ))
        story.append(Paragraph(
            "OCS = C_base + C_violations + C_redundancy + C_coupling", code_style,
        ))
        story += [sp()]

        ocs_comp = [
            ["Component", "As-Is", "Target", "Formula"],
            ["C_base (QMs+Channels+RemoteQs)", str(ocs_asis.c_base), str(ocs_target.c_base), "count × 1"],
            ["C_violations (AppQM+MultiHop+Alias)", str(ocs_asis.c_violations), "0", "violations × weight"],
            ["C_redundancy (Duplicates+Unused)", str(ocs_asis.c_redundancy), "0", "objects × 5"],
            ["C_coupling (Clusters+SharedQM)", str(ocs_asis.c_coupling), "0", "elements × weight"],
            ["TOTAL OCS", str(ocs_asis.total), str(ocs_target.total), f"–{reduction}% reduction"],
        ]
        ocs_table = Table(ocs_comp, colWidths=[7*cm, 2.5*cm, 2.5*cm, 4.5*cm])
        ocs_table.setStyle(TableStyle([
            ("BACKGROUND",  (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
            ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",    (0,0), (-1,-1), 9),
            ("GRID",        (0,0), (-1,-1), 0.3, colors.lightgrey),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LGREY]),
            ("FONTNAME",    (0,-1), (-1,-1), "Helvetica-Bold"),
            ("BACKGROUND",  (0,-1), (-1,-1), colors.HexColor("#e8f8ee")),
            ("TEXTCOLOR",   (2,-1), (2,-1), GREEN),
        ]))
        story += [ocs_table, sp(), PageBreak()]

        # ── Section 3: Target State ───────────────────────────────────────
        story += [Paragraph("3. Target State Architecture", h1_style), hr()]
        story.append(Paragraph(
            f"The target topology applies <b>1 Queue Manager per Application</b> strictly. "
            f"{len(arts.target_qms)} isolated QMs replace {len(ds.queue_managers)} shared QMs. "
            f"{len(arts.channel_pairs)} direct channel pairs replace all multi-hop routing. "
            f"Zero aliases, zero clusters, zero hybrid queue types.",
            body_style,
        ))

        story.append(Paragraph("Target Queue Manager Assignments", h2_style))
        qm_data = [["Target QM", "App ID", "Role", "Channel Pairs"]]
        app_roles = {}
        for cp in arts.channel_pairs:
            app_roles.setdefault(cp["from_app"], set()).add("Producer")
            app_roles.setdefault(cp["to_app"],   set()).add("Consumer")
        for qm in sorted(arts.target_qms)[:15]:
            app = qm.replace("QM.", "")
            roles = ", ".join(sorted(app_roles.get(app, {"Consumer"})))
            out_ch = sum(1 for cp in arts.channel_pairs if cp["from_app"] == app)
            in_ch  = sum(1 for cp in arts.channel_pairs if cp["to_app"]   == app)
            qm_data.append([qm, app, roles, f"Out:{out_ch} In:{in_ch}"])
        qm_table = Table(qm_data, colWidths=[5*cm, 3*cm, 4.5*cm, 4*cm])
        qm_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
            ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",   (0,0), (-1,-1), 8),
            ("GRID",       (0,0), (-1,-1), 0.3, colors.lightgrey),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LGREY]),
            ("TEXTCOLOR",  (0,1), (0,-1), GREEN),
        ]))
        story += [qm_table, sp()]

        story.append(Paragraph("Channel Pair Catalog (Deterministic Naming)", h2_style))
        ch_data = [["Sender Channel", "Receiver Channel", "XMIT Queue", "Queues"]]
        for cp in sorted(arts.channel_pairs, key=lambda x: x["sender_channel"]):
            ch_data.append([
                cp["sender_channel"][:30],
                cp["receiver_channel"][:30],
                cp["xmit_queue"][:25],
                str(len(cp["queues"])),
            ])
        ch_table = Table(ch_data, colWidths=[5.5*cm, 5.5*cm, 4*cm, 1.5*cm])
        ch_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
            ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",   (0,0), (-1,-1), 8),
            ("GRID",       (0,0), (-1,-1), 0.3, colors.lightgrey),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LGREY]),
            ("TEXTCOLOR",  (0,1), (1,-1), CYAN),
        ]))
        story += [ch_table, PageBreak()]

        # ── Section 4: Agent Summary ──────────────────────────────────────
        story += [Paragraph("4. AI Agent Analysis (6-Pass Pipeline)", h1_style), hr()]
        story.append(Paragraph(
            f"Overall confidence: <b>{agent.overall_confidence:.0%}</b>  |  "
            f"Human review: <b>{'Required' if agent.human_review_required else 'Not required'}</b>",
            body_style,
        ))
        pass_data = [["Pass", "Name", "Status", "Confidence"]]
        for p in agent.passes:
            pass_data.append([
                str(p.pass_number), p.pass_name, p.status, f"{p.confidence:.0%}"
            ])
        pass_table = Table(pass_data, colWidths=[1.5*cm, 6*cm, 3*cm, 3*cm])
        pass_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), NAVY),
            ("TEXTCOLOR",  (0,0), (-1,0), colors.white),
            ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",   (0,0), (-1,-1), 9),
            ("GRID",       (0,0), (-1,-1), 0.3, colors.lightgrey),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LGREY]),
        ]))
        story += [pass_table, sp(10)]

        story.append(Paragraph("Executive Summary", h2_style))
        story.append(Paragraph(agent.executive_summary[:800], body_style))
        story += [sp(), Paragraph("Key Recommendations", h2_style)]
        for i, rec in enumerate(agent.recommendations, 1):
            story.append(Paragraph(f"<b>{i}.</b> {rec}", body_style))

        # ── Footer ─────────────────────────────────────────────────────────
        story += [
            PageBreak(),
            hr(),
            Paragraph(
                "IBM MQ Hackathon — Intelligent Topology Simplification &amp; Automation  |  "
                f"Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}  |  "
                "All outputs are automation-ready (MQSC + Terraform + CSV)",
                ParagraphStyle("Footer", parent=styles["Normal"],
                               fontSize=8, textColor=colors.grey, alignment=TA_CENTER),
            ),
        ]

        doc.build(story)
        log.info(f"PDF report saved: {pdf_path}")
        return str(pdf_path)

    except ImportError:
        log.warning("reportlab not installed — generating plain-text report")
        return _text_fallback(
            ds, tg, report, ocs_asis, ocs_target, arts, agent, pdf_path
        )
    except Exception as e:
        log.error(f"PDF generation error: {e}")
        return _text_fallback(
            ds, tg, report, ocs_asis, ocs_target, arts, agent, pdf_path
        )


def _text_fallback(
    ds, tg, report, ocs_asis, ocs_target, arts, agent, base_path: Path
) -> str:
    txt_path = base_path.with_suffix(".txt")
    reduction = round((1 - ocs_target.total / max(ocs_asis.total, 1)) * 100, 1)
    lines = [
        "=" * 70,
        "IBM MQ HACKATHON — INTELLIGENT TOPOLOGY SIMPLIFICATION & AUTOMATION",
        "=" * 70,
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "── KPI SUMMARY ──────────────────────────────────────────────────",
        f"  As-Is QMs:        {len(ds.queue_managers)}",
        f"  Applications:     {len(ds.app_ids)}",
        f"  Violations:       {len(report.violations)} ({len(report.critical_violations)} CRITICAL)",
        f"  As-Is OCS:        {ocs_asis.total}",
        f"  Target OCS:       {ocs_target.total}",
        f"  Reduction:        {reduction}%",
        f"  Target QMs:       {len(arts.target_qms)}",
        f"  Channel Pairs:    {len(arts.channel_pairs)}",
        "",
        "── VIOLATIONS ────────────────────────────────────────────────────",
    ]
    for v in report.violations:
        lines.append(f"  [{v.severity}] {v.rule_id}: {v.description}")
    lines += [
        "",
        "── TARGET QMS ────────────────────────────────────────────────────",
    ]
    for qm in sorted(arts.target_qms):
        lines.append(f"  {qm}")
    lines += [
        "",
        "── AGENT SUMMARY ─────────────────────────────────────────────────",
        f"  Confidence: {agent.overall_confidence:.0%}",
        agent.executive_summary[:500],
        "",
        "=" * 70,
    ]
    txt_path.write_text("\n".join(lines), encoding="utf-8")
    log.info(f"Text report saved: {txt_path}")
    return str(txt_path)
