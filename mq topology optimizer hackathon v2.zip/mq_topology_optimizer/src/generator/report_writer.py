"""
Output writer — saves all artifacts to disk.
"""
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime
from src.generator.target_state import TargetStateArtifacts
from src.observability.ocs_scorer import OCSResult
from src.constraints.engine import ConstraintReport
from src.agent.analysis_agent import AgentReport
from src.utils.config import OUTPUT_DIR
from src.utils.logger import get_logger

log = get_logger(__name__)

def save_all(
    arts: TargetStateArtifacts,
    ocs_asis: OCSResult,
    ocs_target: OCSResult,
    report: ConstraintReport,
    agent_report: AgentReport,
    output_dir: Path | None = None,
) -> dict[str, str]:
    out = Path(output_dir or OUTPUT_DIR)
    out.mkdir(parents=True, exist_ok=True)
    ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
    saved = {}

    # 1. Target topology CSV
    csv_path = out / "target_topology.csv"
    arts.target_df.to_csv(csv_path, index=False)
    saved["target_csv"] = str(csv_path)
    log.info(f"  Saved: {csv_path}")

    # 2. MQSC
    mqsc_path = out / "target_state.mqsc"
    mqsc_path.write_text("\n".join(arts.mqsc_commands), encoding="utf-8")
    saved["mqsc"] = str(mqsc_path)
    log.info(f"  Saved: {mqsc_path}")

    # 3. Terraform
    tf_path = out / "main.tf"
    tf_path.write_text(arts.terraform_hcl, encoding="utf-8")
    saved["terraform"] = str(tf_path)
    log.info(f"  Saved: {tf_path}")

    # 4. Complexity report JSON
    target_breakdown = {
        "qm_count": len(arts.target_qms),
        "channel_pairs": len(arts.channel_pairs),
        "remote_queues": len(arts.channel_pairs),
        "violations": 0,
        "clusters": 0,
        "alias_queues": 0,
    }
    complexity = {
        "as_is": {
            "total": ocs_asis.total,
            "c_base": ocs_asis.c_base,
            "c_violations": ocs_asis.c_violations,
            "c_redundancy": ocs_asis.c_redundancy,
            "c_coupling": ocs_asis.c_coupling,
            "breakdown": ocs_asis.breakdown,
        },
        "target": {
            "total": ocs_target.total,
            "c_base": ocs_target.c_base,
            "c_violations": 0,
            "c_redundancy": 0,
            "c_coupling": 0,
            "breakdown": target_breakdown,
        },
        "reduction_pct": round(
            (1 - ocs_target.total / max(ocs_asis.total, 1)) * 100, 1
        ),
        "violations_eliminated": len(report.violations),
    }
    cx_path = out / "complexity_report.json"
    cx_path.write_text(json.dumps(complexity, indent=2), encoding="utf-8")
    saved["complexity_report"] = str(cx_path)
    log.info(f"  Saved: {cx_path}")

    # 5. Decision log
    dl_path = out / "decision_log.json"
    dl_path.write_text(json.dumps(arts.decision_log, indent=2), encoding="utf-8")
    saved["decision_log"] = str(dl_path)
    log.info(f"  Saved: {dl_path}")

    # 6. Agent report
    ar_path = out / "agent_report.json"
    ar_path.write_text(json.dumps(agent_report.to_dict(), indent=2), encoding="utf-8")
    saved["agent_report"] = str(ar_path)
    log.info(f"  Saved: {ar_path}")

    # 7. Violations report
    vr_path = out / "violations.json"
    vr_data = [
        {
            "rule_id": v.rule_id,
            "severity": v.severity,
            "description": v.description,
            "evidence": v.evidence,
            "affected": v.affected_objects,
            "score": v.score_contribution,
            "fix": v.fix_recommendation,
        }
        for v in report.violations
    ]
    vr_path.write_text(json.dumps(vr_data, indent=2), encoding="utf-8")
    saved["violations"] = str(vr_path)
    log.info(f"  Saved: {vr_path}")

    return saved
