"""Configuration loader."""
import os
import yaml
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_DIR = Path(__file__).parent.parent.parent
CONFIG_DIR = BASE_DIR / "config"
OUTPUT_DIR = BASE_DIR / os.getenv("OUTPUT_DIR", "outputs")
DATA_DIR   = BASE_DIR / os.getenv("DATA_DIR", "data")

def load_constraints_config() -> dict:
    with open(CONFIG_DIR / "constraints.yaml") as f:
        return yaml.safe_load(f)

def get_anthropic_key() -> str | None:
    return os.getenv("ANTHROPIC_API_KEY")

def get_openai_key() -> str | None:
    return os.getenv("OPENAI_API_KEY")

def ai_enabled() -> bool:
    return bool(get_anthropic_key() or get_openai_key())

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
