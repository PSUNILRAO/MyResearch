"""Page 6 — Agent Deep Dive"""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import streamlit as st
import pandas as pd

st.set_page_config(page_title="Agent Deep Dive", page_icon="🤖", layout="wide")
st.markdown("<style>.stApp{background:#05080f;} h1,h2,h3{color:#e2e8f0!important;}</style>",
            unsafe_allow_html=True)
st.title("🤖 Agent Deep Dive")

agent = st.session_state.get("agent")
arts  = st.session_state.get("arts")
tg    = st.session_state.get("tg")
ocs   = st.session_state.get("ocs")

if agent is None:
    st.warning("Run pipeline from Home first.")
    st.stop()

# ── Overall confidence gauge ───────────────────────────────────────────────
c1, c2, c3 = st.columns(3)
c1.metric("Overall Confidence",    f"{agent.overall_confidence:.1%}")
c2.metric("Human Review",          "Required" if agent.human_review_required else "Not Required")
c3.metric("Passes Completed",      f"{len(agent.passes)}/6")

if agent.human_review_required:
    st.warning("⚠️ Human review recommended — confidence below 85% threshold")
else:
    st.success("✅ All 6 passes completed with high confidence — no human review required")

st.divider()

# ── Pass-by-pass detail ────────────────────────────────────────────────────
st.subheader("Pass-by-Pass Analysis")

PASS_ICONS = {1:"🔍", 2:"⚠️", 3:"📊", 4:"🏗️", 5:"✅", 6:"💬"}
STATUS_COLORS = {"PASS":"#00e676", "FAIL":"#ff5252", "SKIPPED":"#64748b"}

for p in agent.passes:
    icon = PASS_ICONS.get(p.pass_number, "◆")
    sc = STATUS_COLORS.get(p.status, "#64748b")
    llm_badge = " 🤖 LLM-enhanced" if p.used_llm else ""

    with st.expander(
        f"{icon} Pass {p.pass_number}: {p.pass_name}  "
        f"[{p.status}] conf={p.confidence:.0%}{llm_badge}",
        expanded=(p.pass_number <= 2),
    ):
        st.markdown(f"**Summary:** {p.summary}")
        st.markdown(f"**Status:** :{('green' if p.status=='PASS' else 'red')}[**{p.status}**]")

        if p.findings:
            st.markdown(f"**Findings ({len(p.findings)}):**")

            # Pass 1: Discovery table
            if p.pass_number == 1:
                apps = [f for f in p.findings if f.get("object_type") == "APP"]
                qms  = [f for f in p.findings if f.get("object_type") == "QM"]
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("*Apps*")
                    if apps:
                        st.dataframe(pd.DataFrame(apps), use_container_width=True, hide_index=True)
                with col2:
                    st.markdown("*Queue Managers*")
                    if qms:
                        st.dataframe(pd.DataFrame(qms), use_container_width=True, hide_index=True)

            # Pass 2: Anomaly table
            elif p.pass_number == 2:
                anom = [f for f in p.findings if "anomaly_type" in f]
                if anom:
                    st.dataframe(pd.DataFrame(anom), use_container_width=True, hide_index=True)

            # Pass 3: Metrics
            elif p.pass_number == 3:
                metrics = {f["metric"]: f["value"] for f in p.findings if "metric" in f}
                cols = st.columns(4)
                for i, (k, v) in enumerate(metrics.items()):
                    cols[i % 4].metric(k, v)

            # Pass 4: Target QMs + channels
            elif p.pass_number == 4:
                target_qms  = [f for f in p.findings if f.get("object_type") == "TARGET_QM"]
                chan_pairs   = [f for f in p.findings if f.get("object_type") == "CHANNEL_PAIR"]
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown(f"*{len(target_qms)} Target QMs*")
                    if target_qms:
                        for qm in target_qms[:10]:
                            st.code(qm["id"], language=None)
                with col2:
                    st.markdown(f"*{len(chan_pairs)} Channel Pairs*")
                    if chan_pairs:
                        st.dataframe(pd.DataFrame(chan_pairs), use_container_width=True, hide_index=True)

            # Pass 5: Validation results
            elif p.pass_number == 5:
                checks = pd.DataFrame(p.findings)
                if not checks.empty:
                    st.dataframe(checks, use_container_width=True, hide_index=True)

            # Pass 6: Explanation text
            elif p.pass_number == 6:
                for f in p.findings:
                    if "full_rationale" in f:
                        st.markdown(f["full_rationale"])

st.divider()

# ── Recommendations ───────────────────────────────────────────────────────
st.subheader("Agent Recommendations")
for i, rec in enumerate(agent.recommendations, 1):
    st.markdown(f"**{i}.** {rec}")

st.divider()

# ── Decision log table ────────────────────────────────────────────────────
if arts and arts.decision_log:
    st.subheader(f"Decision Log ({len(arts.decision_log)} decisions)")
    search = st.text_input("Search decisions", placeholder="Type app name, constraint, etc.")
    dl = arts.decision_log
    if search:
        dl = [d for d in dl if search.lower() in json.dumps(d).lower()]

    dl_rows = [{
        "ID":         d["decision_id"],
        "Type":       d["type"],
        "Constraint": d.get("constraint",""),
        "Confidence": f"{d.get('confidence',0):.0%}",
        "Rationale":  d.get("rationale","")[:100] + "...",
    } for d in dl]
    st.dataframe(pd.DataFrame(dl_rows), use_container_width=True, hide_index=True)

    with st.expander("Full Decision Log (JSON)"):
        st.json(arts.decision_log[:10])

    st.download_button(
        "⬇️ Download Full Decision Log",
        json.dumps(arts.decision_log, indent=2).encode(),
        "decision_log.json", "application/json",
        use_container_width=True,
    )

# ── Export agent report ───────────────────────────────────────────────────
st.divider()
st.subheader("Export Agent Report")
col1, col2 = st.columns(2)
with col1:
    st.download_button(
        "⬇️ Agent Report (JSON)",
        json.dumps(agent.to_dict(), indent=2).encode(),
        "agent_report.json", "application/json",
        use_container_width=True,
    )
with col2:
    # Generate PDF report if available
    if all(k in st.session_state for k in ["ds","tg","report","ocs","arts","ocs_t"]):
        if st.button("📄 Generate PDF Report", use_container_width=True):
            with st.spinner("Generating PDF..."):
                try:
                    from src.generator.pdf_report import generate_pdf_report
                    pdf_path = generate_pdf_report(
                        st.session_state["ds"],
                        st.session_state["tg"],
                        st.session_state["report"],
                        st.session_state["ocs"],
                        st.session_state["ocs_t"],
                        st.session_state["arts"],
                        agent,
                    )
                    with open(pdf_path, "rb") as f:
                        st.download_button(
                            "⬇️ Download PDF Report",
                            f.read(), "hackathon_report.pdf", "application/pdf",
                            use_container_width=True,
                        )
                except Exception as e:
                    st.error(f"PDF generation: {e}")
