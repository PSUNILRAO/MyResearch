"""Page 2 — Constraint Engine Results"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import streamlit as st
import pandas as pd

st.set_page_config(page_title="Constraint Check", page_icon="⚖️", layout="wide")
st.markdown("<style>.stApp{background:#05080f;} h1,h2,h3{color:#e2e8f0!important;}</style>",
            unsafe_allow_html=True)

st.title("⚖️ Constraint Engine")

report = st.session_state.get("report")
ds     = st.session_state.get("ds")
tg     = st.session_state.get("tg")

if report is None:
    if ds is None:
        st.warning("Run pipeline from Home first or upload a CSV on the As-Is page.")
        st.stop()
    from src.constraints.engine import run_constraints
    with st.spinner("Running constraints..."):
        report = run_constraints(ds, tg)
        st.session_state["report"] = report

# ── Core Constraint Status ────────────────────────────────────────────────
st.subheader("Core Constraints (Non-Negotiable)")
core_rules = ["C1_ONE_QM_PER_APP", "C2_PRODUCER_REMOTE_QUEUE",
              "C3_CONSUMER_LOCAL_QUEUE", "C4_CHANNEL_NAMING"]
core_descs = {
    "C1_ONE_QM_PER_APP":        "Exactly 1 QM per AppID",
    "C2_PRODUCER_REMOTE_QUEUE": "Producers write to Remote Q → XMIT Q",
    "C3_CONSUMER_LOCAL_QUEUE":  "Consumers read from Local Q only",
    "C4_CHANNEL_NAMING":        "Deterministic channel naming: QM.A.QM.B",
}
violated_rules = {v.rule_id for v in report.violations}

cols = st.columns(4)
for col, rule in zip(cols, core_rules):
    violated = rule in violated_rules
    count    = sum(1 for v in report.violations if v.rule_id == rule)
    col.markdown(f"""
    <div style="background:{'rgba(239,68,68,0.12)' if violated else 'rgba(0,230,118,0.08)'};
                border:1px solid {'#ef4444' if violated else '#00e676'};
                border-radius:8px; padding:14px; text-align:center;">
      <div style="font-size:22px">{'❌' if violated else '✅'}</div>
      <div style="color:{'#ef4444' if violated else '#00e676'};font-weight:700;
                  font-size:12px;margin:4px 0;">{rule}</div>
      <div style="color:#7ea8c9;font-size:11px;">{core_descs.get(rule,'')}</div>
      {'<div style="color:#ff5252;font-size:11px;margin-top:4px;">' + str(count) + ' violations</div>' if violated else ''}
    </div>
    """, unsafe_allow_html=True)

st.divider()

# ── All violations ────────────────────────────────────────────────────────
st.subheader(f"All Violations ({len(report.violations)} total)")

sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
sorted_viols = sorted(report.violations, key=lambda v: sev_order.get(v.severity, 9))

sev_colors = {"CRITICAL": "#ef4444", "HIGH": "#ffb300",
              "MEDIUM": "#8b5cf6", "LOW": "#64748b"}

for v in sorted_viols:
    color = sev_colors.get(v.severity, "#64748b")
    with st.expander(f"[{v.severity}] {v.rule_id} — {v.description[:80]}"):
        col1, col2 = st.columns([2, 1])
        with col1:
            st.markdown(f"**Evidence:** {v.evidence}")
            st.markdown(f"**Affected:** `{', '.join(str(o) for o in v.affected_objects)}`")
            st.markdown(f"**Fix:** {v.fix_recommendation}")
        with col2:
            st.metric("OCS Contribution", f"+{v.score_contribution}")

# ── Violations table ──────────────────────────────────────────────────────
st.subheader("Violations Table")
viol_rows = [{
    "Rule ID":    v.rule_id,
    "Severity":   v.severity,
    "Description": v.description[:80],
    "OCS Score":  v.score_contribution,
    "Fix":        v.fix_recommendation[:60],
} for v in sorted_viols]
st.dataframe(pd.DataFrame(viol_rows), use_container_width=True, hide_index=True)

# ── Passed rules count ────────────────────────────────────────────────────
st.success(f"✅ {len(report.passed_rules)} rule checks passed cleanly.")
