"""Page 4 — Target State, CSV, MQSC, Agent Report"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import streamlit as st
import pandas as pd
import json

st.set_page_config(page_title="Target State", page_icon="🏗️", layout="wide")
st.markdown("<style>.stApp{background:#05080f;} h1,h2,h3{color:#e2e8f0!important;}</style>",
            unsafe_allow_html=True)

st.title("🏗️ Target State & Generated Artifacts")

arts  = st.session_state.get("arts")
agent = st.session_state.get("agent")
ocs   = st.session_state.get("ocs")
ocs_t = st.session_state.get("ocs_t")

if arts is None:
    st.warning("Run pipeline from Home first.")
    st.stop()

reduction = round((1 - ocs_t.total / max(ocs.total,1))*100,1) if ocs and ocs_t else 0

# ── Summary ───────────────────────────────────────────────────────────────
c1,c2,c3,c4 = st.columns(4)
c1.metric("Target QMs",     len(arts.target_qms))
c2.metric("Channel Pairs",  len(arts.channel_pairs))
c3.metric("Queue Rows",     len(arts.target_df))
c4.metric("OCS Reduction",  f"{reduction}%")

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["📋 Target QMs", "🔗 Channel Pairs", "📄 Target CSV", "⚙️ MQSC", "🤖 Agent Report"]
)

# ── Tab 1: Target QMs ─────────────────────────────────────────────────────
with tab1:
    st.subheader("Target Queue Managers (1 per AppID)")
    qm_rows = []
    for cp in arts.channel_pairs:
        for qm, app, role in [
            (cp["from_qm"], cp["from_app"], "Producer"),
            (cp["to_qm"],   cp["to_app"],   "Consumer"),
        ]:
            qm_rows.append({"QM": qm, "App": app, "Role": role,
                             "Channels": f"{cp['sender_channel']} / {cp['receiver_channel']}"})
    df_qm = pd.DataFrame(qm_rows).drop_duplicates(subset=["QM"])
    st.dataframe(df_qm, use_container_width=True, hide_index=True)

    st.subheader("As-Is → Target QM Consolidation Plan")
    tg = st.session_state.get("tg")
    if tg:
        plan_rows = []
        for app in sorted(tg.app_to_qms.keys()):
            old_qms = sorted(tg.app_to_qms[app])
            plan_rows.append({
                "App ID":       app,
                "Old QMs":      ", ".join(old_qms),
                "# Old QMs":    len(old_qms),
                "New QM":       f"QM.{app}",
                "Action":       "CONSOLIDATE" if len(old_qms) > 1 else "RENAME",
                "Decommission": ", ".join(q for q in old_qms if q != f"QM.{app}"),
            })
        st.dataframe(pd.DataFrame(plan_rows), use_container_width=True, hide_index=True)

# ── Tab 2: Channel Pairs ──────────────────────────────────────────────────
with tab2:
    st.subheader(f"Channel Pairs ({len(arts.channel_pairs)} total)")
    for i, cp in enumerate(sorted(arts.channel_pairs, key=lambda x: x["sender_channel"]), 1):
        with st.expander(f"#{i} {cp['from_app']} → {cp['to_app']}"):
            c1, c2 = st.columns(2)
            with c1:
                st.markdown(f"**Sender Channel:**  `{cp['sender_channel']}`")
                st.markdown(f"**Receiver Channel:** `{cp['receiver_channel']}`")
                st.markdown(f"**XMIT Queue:**       `{cp['xmit_queue']}`")
            with c2:
                st.markdown(f"**From QM:** `{cp['from_qm']}`")
                st.markdown(f"**To QM:**   `{cp['to_qm']}`")
                st.markdown(f"**Queues ({len(cp['queues'])}):**")
                for q in cp["queues"]:
                    st.code(q, language=None)

# ── Tab 3: CSV ────────────────────────────────────────────────────────────
with tab3:
    st.subheader("Target Topology CSV (same schema as input)")
    st.dataframe(arts.target_df, use_container_width=True, hide_index=True)
    csv_bytes = arts.target_df.to_csv(index=False).encode()
    st.download_button(
        "⬇️ Download target_topology.csv",
        csv_bytes, "target_topology.csv", "text/csv",
        use_container_width=True,
    )

# ── Tab 4: MQSC ───────────────────────────────────────────────────────────
with tab4:
    st.subheader("MQSC Automation Scripts")
    mqsc_text = "\n".join(arts.mqsc_commands)
    st.code(mqsc_text, language="bash")
    st.download_button(
        "⬇️ Download target_state.mqsc",
        mqsc_text.encode(), "target_state.mqsc", "text/plain",
        use_container_width=True,
    )
    st.subheader("Terraform IaC (IBM MQ Provider)")
    st.code(arts.terraform_hcl[:3000] + "\n# ... (truncated, download full)", language="hcl")
    st.download_button(
        "⬇️ Download main.tf",
        arts.terraform_hcl.encode(), "main.tf", "text/plain",
        use_container_width=True,
    )

# ── Tab 5: Agent ──────────────────────────────────────────────────────────
with tab5:
    if agent is None:
        st.warning("Agent not run. Go to Home and run pipeline.")
    else:
        st.subheader("6-Pass Agent Results")
        st.metric("Overall Confidence", f"{agent.overall_confidence:.1%}")
        if agent.human_review_required:
            st.warning("⚠️ Human review recommended (confidence < 85% or constraint violation in target)")
        else:
            st.success("✅ No human review required — all passes confident")

        st.markdown("**Executive Summary**")
        st.info(agent.executive_summary)

        st.markdown("**Recommendations**")
        for i, r in enumerate(agent.recommendations, 1):
            st.markdown(f"**{i}.** {r}")

        st.markdown("**Pass-by-Pass Results**")
        for p in agent.passes:
            icon = "✅" if p.status == "PASS" else ("❌" if p.status == "FAIL" else "⏭️")
            with st.expander(f"{icon} Pass {p.pass_number}: {p.pass_name} [{p.status}] conf={p.confidence:.0%}"):
                st.write(p.summary)
                if p.used_llm:
                    st.caption("🤖 This pass used LLM reasoning")

        st.download_button(
            "⬇️ Download agent_report.json",
            json.dumps(agent.to_dict(), indent=2).encode(),
            "agent_report.json", "application/json",
            use_container_width=True,
        )

        # Decision log
        with st.expander(f"📋 Decision Log ({len(arts.decision_log)} decisions)"):
            st.dataframe(
                pd.DataFrame([
                    {"ID": d["decision_id"], "Type": d["type"],
                     "Constraint": d["constraint"],
                     "Confidence": d.get("confidence",""),
                     "Rationale": d.get("rationale","")[:120]}
                    for d in arts.decision_log
                ]),
                use_container_width=True, hide_index=True,
            )
