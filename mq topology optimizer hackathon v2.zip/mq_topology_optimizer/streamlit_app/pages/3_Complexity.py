"""Page 3 — OCS Complexity Score"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(page_title="Complexity Score", page_icon="📊", layout="wide")
st.markdown("<style>.stApp{background:#05080f;} h1,h2,h3{color:#e2e8f0!important;}</style>",
            unsafe_allow_html=True)

st.title("📊 Operational Complexity Score (OCS)")

ocs   = st.session_state.get("ocs")
ocs_t = st.session_state.get("ocs_t")
arts  = st.session_state.get("arts")
ds    = st.session_state.get("ds")
tg    = st.session_state.get("tg")
report = st.session_state.get("report")

if ocs is None:
    if ds is None:
        st.warning("Run pipeline from Home first.")
        st.stop()
    from src.constraints.engine import run_constraints
    from src.observability.ocs_scorer import compute_ocs, OCSResult
    from src.generator.target_state import generate_target_state
    report = run_constraints(ds, tg)
    ocs    = compute_ocs(ds, tg, report, "as-is")
    arts   = generate_target_state(ds, tg, report)
    ocs_t  = OCSResult(
        c_base=len(arts.target_qms)+len(arts.channel_pairs)*2,
        c_violations=0, c_redundancy=0, c_coupling=0, label="target"
    )
    st.session_state.update({"report": report, "ocs": ocs, "arts": arts, "ocs_t": ocs_t})

reduction = round((1 - ocs_t.total / max(ocs.total, 1)) * 100, 1)

# ── Hero metrics ──────────────────────────────────────────────────────────
c1, c2, c3, c4 = st.columns(4)
c1.metric("As-Is OCS",    ocs.total,   help="Total Operational Complexity Score")
c2.metric("Target OCS",   ocs_t.total, delta=f"-{ocs.total - ocs_t.total}")
c3.metric("Reduction",    f"{reduction}%")
c4.metric("Violations",   f"{ocs.c_violations} → 0", delta=f"-{ocs.c_violations}", delta_color="inverse")

st.divider()

# ── Formula callout ───────────────────────────────────────────────────────
st.markdown("""
```
OCS = C_base + C_violations + C_redundancy + C_coupling

  C_base       = QM_count(×1) + Channel_pairs(×1) + Remote_queues(×1)
  C_violations = AppQM_violations(×10) + MultiHop_routes(×8) + Alias_queues(×3)
  C_redundancy = Duplicate_queues(×5) + Unused_objects(×3)
  C_coupling   = MQ_clusters(×5) + SharedQM_apps(×8)
```
""")

# ── Stacked bar chart ─────────────────────────────────────────────────────
fig = go.Figure()
categories = ["C_base", "C_violations", "C_redundancy", "C_coupling"]
asis_vals   = [ocs.c_base, ocs.c_violations, ocs.c_redundancy, ocs.c_coupling]
target_vals = [ocs_t.c_base, 0, 0, 0]
colors      = ["#00e5ff", "#ef4444", "#ffb300", "#8b5cf6"]

for cat, av, tv, col in zip(categories, asis_vals, target_vals, colors):
    fig.add_trace(go.Bar(
        name=cat, x=["As-Is", "Target"],
        y=[av, tv], marker_color=col, text=[av, tv],
        textposition="auto",
    ))

fig.update_layout(
    barmode="stack", title="OCS Dimensional Breakdown: As-Is vs Target",
    paper_bgcolor="#05080f", plot_bgcolor="#0c1422",
    font=dict(color="#e2e8f0", family="IBM Plex Mono"),
    legend=dict(bgcolor="#0c1422", bordercolor="#1a2e4a"),
    height=380,
)
st.plotly_chart(fig, use_container_width=True)

# ── Breakdown table ───────────────────────────────────────────────────────
st.subheader("Dimensional Breakdown")
col1, col2 = st.columns(2)
with col1:
    st.markdown("**As-Is**")
    bd = ocs.breakdown
    rows = [
        ("Queue Managers",       bd.get("qm_count",0),       "×1 = ", bd.get("qm_count",0)),
        ("Channel Pairs",        bd.get("channel_pairs",0),   "×1 = ", bd.get("channel_pairs",0)),
        ("Remote Queues",        bd.get("remote_queues",0),   "×1 = ", bd.get("remote_queues",0)),
        ("App-QM Violations",    bd.get("app_qm_violations",0),"×10 = ", bd.get("app_qm_violations",0)*10),
        ("Multi-Hop Flows",      bd.get("multi_hop_flows",0), "×8 = ", bd.get("multi_hop_flows",0)*8),
        ("Alias Queues",         bd.get("alias_queues",0),    "×3 = ", bd.get("alias_queues",0)*3),
        ("Duplicate Queues",     bd.get("duplicate_queues",0),"×5 = ", bd.get("duplicate_queues",0)*5),
        ("MQ Clusters",          bd.get("clusters",0),        "×5 = ", bd.get("clusters",0)*5),
        ("Shared-QM Apps",       bd.get("shared_qm_apps",0),  "×8 = ", bd.get("shared_qm_apps",0)*8),
    ]
    import pandas as pd
    df_bd = pd.DataFrame(rows, columns=["Metric","Count","Weight","Score"])
    st.dataframe(df_bd, use_container_width=True, hide_index=True)
    st.metric("Total As-Is OCS", ocs.total)

with col2:
    st.markdown("**Target State**")
    t_rows = [
        ("Queue Managers (1/app)", len(arts.target_qms), "×1 = ", len(arts.target_qms)),
        ("Channel Pairs",          len(arts.channel_pairs),"×1 = ", len(arts.channel_pairs)),
        ("Remote Queues",          len(arts.channel_pairs),"×1 = ", len(arts.channel_pairs)),
        ("Violations",             0, "×10 = ", 0),
        ("Multi-Hop Flows",        0, "×8 = ",  0),
        ("Alias Queues",           0, "×3 = ",  0),
        ("Duplicate Queues",       0, "×5 = ",  0),
        ("MQ Clusters",            0, "×5 = ",  0),
        ("Shared-QM Apps",         0, "×8 = ",  0),
    ]
    df_t = pd.DataFrame(t_rows, columns=["Metric","Count","Weight","Score"])
    st.dataframe(df_t, use_container_width=True, hide_index=True)
    st.metric("Total Target OCS", ocs_t.total, delta=f"-{ocs.total-ocs_t.total}")
