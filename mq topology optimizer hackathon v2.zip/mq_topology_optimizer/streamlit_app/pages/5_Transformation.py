"""Page 5 — Transformation Plan"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import streamlit as st
import pandas as pd

st.set_page_config(page_title="Transformation Plan", page_icon="🗺️", layout="wide")
st.markdown("<style>.stApp{background:#05080f;} h1,h2,h3{color:#e2e8f0!important;}</style>",
            unsafe_allow_html=True)
st.title("🗺️ Transformation Plan")

ds     = st.session_state.get("ds")
tg     = st.session_state.get("tg")
report = st.session_state.get("report")
arts   = st.session_state.get("arts")

if not all([ds, tg, report, arts]):
    st.warning("Run pipeline from Home first.")
    st.stop()

from src.generator.transformation_plan import generate_transformation_plan

if "transform_plan" not in st.session_state:
    with st.spinner("Generating transformation plan..."):
        plan = generate_transformation_plan(ds, tg, report, arts)
        st.session_state["transform_plan"] = plan
else:
    plan = st.session_state["transform_plan"]

# ── Header metrics ────────────────────────────────────────────────────────
c1,c2,c3,c4 = st.columns(4)
c1.metric("Total Steps",        plan.total_steps)
c2.metric("Timeline",           plan.estimated_duration)
c3.metric("QMs to Provision",   len(plan.provision_list))
c4.metric("QMs to Decommission",len(plan.decommission_list))

st.divider()

# ── Phase tabs ────────────────────────────────────────────────────────────
PHASE_NAMES = {
    1: ("🔍 Audit & Freeze",        "1-2 weeks"),
    2: ("🏗️ Provision Target QMs",  "1 week"),
    3: ("🔄 Migrate Flows",          "2-3 weeks"),
    4: ("🗑️ Decommission Legacy",    "1 week"),
    5: ("✅ Validate & Automate",    "1 week"),
}

tab_labels = [f"{PHASE_NAMES[i][0]}" for i in range(1, 6)]
tabs = st.tabs(tab_labels)

for phase_num, tab in zip(range(1, 6), tabs):
    with tab:
        steps = plan.steps_for_phase(phase_num)
        pname, pdur = PHASE_NAMES[phase_num]
        st.markdown(f"**Duration estimate:** {pdur}  |  **Steps:** {len(steps)}")
        st.divider()

        for step in steps:
            risk_color = {"HIGH":"🔴","MEDIUM":"🟡","LOW":"🟢"}.get(step.risk,"⚪")
            with st.expander(
                f"{risk_color} **{step.step_id}** — {step.action}  "
                f"({step.duration_estimate})"
            ):
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.markdown(f"**Description:**")
                    st.write(step.description)
                    st.markdown(f"**Rollback:**")
                    st.info(step.rollback)
                with col2:
                    st.metric("Risk Level", step.risk)
                    st.markdown("**Affected Objects:**")
                    for obj in step.objects_affected[:6]:
                        st.code(str(obj)[:50], language=None)
                st.markdown("**MQSC / Command Hint:**")
                st.code(step.mqsc_hint, language="bash")

st.divider()

# ── Download markdown plan ─────────────────────────────────────────────────
st.subheader("📥 Download Transformation Plan")
md_text = plan.to_markdown()
st.download_button(
    "⬇️ Download Transformation Plan (Markdown)",
    md_text.encode(), "transformation_plan.md", "text/markdown",
    use_container_width=True,
)

col1, col2 = st.columns(2)
with col1:
    st.subheader("✅ QMs to Provision")
    for qm in sorted(plan.provision_list):
        st.code(qm, language=None)
with col2:
    st.subheader("🗑️ QMs to Decommission")
    for qm in sorted(plan.decommission_list):
        st.code(qm, language=None)

# ── Risk matrix ───────────────────────────────────────────────────────────
st.divider()
st.subheader("⚠️ Risk Summary by Phase")
risk_rows = []
for phase_num in range(1, 6):
    steps = plan.steps_for_phase(phase_num)
    highs  = sum(1 for s in steps if s.risk == "HIGH")
    meds   = sum(1 for s in steps if s.risk == "MEDIUM")
    lows   = sum(1 for s in steps if s.risk == "LOW")
    risk_rows.append({
        "Phase": f"Phase {phase_num}: {PHASE_NAMES[phase_num][0]}",
        "Steps": len(steps),
        "HIGH Risk": highs,
        "MEDIUM Risk": meds,
        "LOW Risk": lows,
        "Duration": PHASE_NAMES[phase_num][1],
    })
st.dataframe(pd.DataFrame(risk_rows), use_container_width=True, hide_index=True)
