"""Page 1 — As-Is Analysis"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import streamlit as st
import pandas as pd

st.set_page_config(page_title="As-Is Analysis", page_icon="🔍", layout="wide")
st.markdown("""<style>
.stApp{background:#05080f;} h1,h2,h3{color:#e2e8f0!important;}
</style>""", unsafe_allow_html=True)

st.title("🔍 As-Is Topology Analysis")

# ── Load from session or let user upload ──────────────────────────────────
ds  = st.session_state.get("ds")
tg  = st.session_state.get("tg")

if ds is None:
    uploaded = st.file_uploader("Upload topology CSV", type=["csv"])
    if uploaded:
        import tempfile, os
        from src.ingestion.loader import load_topology
        from src.graph.topology_graph import build_graph
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
            tmp.write(uploaded.getbuffer())
            tmp_path = tmp.name
        with st.spinner("Loading..."):
            ds = load_topology(tmp_path)
            tg = build_graph(ds)
            st.session_state["ds"] = ds
            st.session_state["tg"] = tg
        os.unlink(tmp_path)
        st.rerun()
    else:
        st.info("Upload a CSV or run the pipeline from Home first.")
        st.stop()

# ── KPIs ──────────────────────────────────────────────────────────────────
c1,c2,c3,c4,c5 = st.columns(5)
c1.metric("Queue Managers",  len(ds.queue_managers))
c2.metric("Applications",    len(ds.app_ids))
c3.metric("Unique Queues",   len(ds.queues))
c4.metric("Comm Flows",      len(tg.comm_flows))
c5.metric("Multi-hop Flows", len(tg.multi_hop_flows),
          delta=f"{len(tg.multi_hop_flows)} to fix" if tg.multi_hop_flows else None,
          delta_color="inverse")

st.divider()

# ── App → QM mapping (the key violation table) ────────────────────────────
st.subheader("📊 App → Queue Manager Mapping (Violation View)")
rows = []
for app, qms in sorted(tg.app_to_qms.items()):
    violation = len(qms) > 1
    rows.append({
        "App ID":       app,
        "# QMs":        len(qms),
        "Queue Managers": ", ".join(sorted(qms)),
        "Status":       "❌ VIOLATION — C1" if violation else "✅ OK",
        "Action":       f"Consolidate → QM.{app}" if violation else "—",
    })
df_apps = pd.DataFrame(rows)
st.dataframe(
    df_apps.style.apply(
        lambda row: ["background:rgba(239,68,68,0.12)" if "VIOLATION" in str(row["Status"]) else "" for _ in row],
        axis=1,
    ),
    use_container_width=True, hide_index=True,
)

# ── QM → Apps mapping ────────────────────────────────────────────────────
st.subheader("🗂️ Queue Manager → Apps (Multi-App QMs highlighted)")
qm_rows = []
for qm, apps in sorted(tg.qm_to_apps.items()):
    qm_rows.append({
        "Queue Manager": qm,
        "# Apps":        len(apps),
        "Apps":          ", ".join(sorted(apps)),
        "Blast Radius":  "HIGH" if len(apps) > 2 else ("MEDIUM" if len(apps) > 1 else "LOW"),
    })
st.dataframe(pd.DataFrame(qm_rows), use_container_width=True, hide_index=True)

# ── Communication flows ───────────────────────────────────────────────────
st.subheader("📡 Communication Flows")
flow_rows = []
for f in sorted(tg.comm_flows, key=lambda x: (-x["hops"], x["from_app"])):
    flow_rows.append({
        "From App": f["from_app"],
        "To App":   f["to_app"],
        "Queue":    f["queue"],
        "From QM":  f["from_qm"],
        "To QM":    f["to_qm"],
        "Hops":     f["hops"],
        "Q Type":   f.get("q_type",""),
        "Status":   "⚠️ Multi-hop" if f["hops"] > 1 else "✅ Direct",
    })
st.dataframe(pd.DataFrame(flow_rows), use_container_width=True, hide_index=True)

# ── Anti-patterns summary ─────────────────────────────────────────────────
st.subheader("⚠️ Detected Anti-patterns")
col1, col2, col3 = st.columns(3)
with col1:
    st.markdown(f"**Alias Queues**: `{len(tg.alias_queues)}`")
    for q in tg.alias_queues[:10]:
        st.code(q, language=None)
with col2:
    st.markdown(f"**Hybrid Queue Types**: `{len(tg.hybrid_queues)}`")
    for q in tg.hybrid_queues[:10]:
        st.code(q, language=None)
with col3:
    st.markdown(f"**MQ Clusters**: `{len(tg.clusters)}`")
    for c in sorted(tg.clusters):
        st.code(c, language=None)

# ── Raw data ──────────────────────────────────────────────────────────────
with st.expander("📋 Raw Input Data"):
    st.dataframe(ds.raw_df, use_container_width=True)
