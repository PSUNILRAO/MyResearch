"""
Streamlit Dashboard — Home / Entry Point
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import streamlit as st

st.set_page_config(
    page_title="MQ Topology Optimizer",
    page_icon="🔗",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&display=swap');
  .stApp { background-color: #05080f; }
  .block-container { padding-top: 1.5rem; }
  h1, h2, h3 { font-family: 'IBM Plex Mono', monospace !important; color: #e2e8f0 !important; }
  .metric-card {
    background: #0c1422; border: 1px solid #1a2e4a; border-radius: 8px;
    padding: 16px; text-align: center;
  }
  .cyan  { color: #00e5ff !important; }
  .amber { color: #ffb300 !important; }
  .green { color: #00e676 !important; }
  .red   { color: #ff5252 !important; }
  .tag {
    display: inline-block; background: rgba(0,229,255,0.1);
    border: 1px solid rgba(0,229,255,0.3); border-radius: 4px;
    padding: 2px 8px; font-size: 11px; color: #00e5ff;
    margin: 2px; font-family: monospace;
  }
</style>
""", unsafe_allow_html=True)

# ── Header ────────────────────────────────────────────────────────────────
st.markdown("""
<div style="background:linear-gradient(135deg,#050d1a,#080f1e);
            border:1px solid rgba(0,229,255,0.3); border-radius:10px;
            padding:28px 32px; margin-bottom:24px;">
  <div style="font-family:monospace;font-size:11px;color:#00e676;
              letter-spacing:3px;margin-bottom:6px;">
    ● LIVE  ·  IBM MQ HACKATHON  ·  INTELLIGENT TOPOLOGY SIMPLIFICATION
  </div>
  <h1 style="font-size:2rem;font-family:'IBM Plex Mono',monospace;
             color:#e2e8f0;margin:0;letter-spacing:-1px;">
    MQ Topology <span style="color:#00e5ff;">Optimizer</span>
  </h1>
  <p style="color:#7ea8c9;font-size:13px;margin:8px 0 12px;">
    AI-augmented · Constraint-enforced · Automation-ready · 6-Layer Architecture
  </p>
  <span class="tag">Event-Driven</span>
  <span class="tag">Graph-Native</span>
  <span class="tag">OCS Scoring</span>
  <span class="tag">LLM Reasoning</span>
  <span class="tag">MQSC Generation</span>
  <span class="tag">Terraform IaC</span>
</div>
""", unsafe_allow_html=True)

# ── Navigation cards ─────────────────────────────────────────────────────
st.markdown("### 📋 Navigation")

col1, col2, col3, col4 = st.columns(4)
pages = [
    ("1️⃣", "As-Is Analysis",    "pages/1_AsIs_Analysis.py",    "Upload CSV & analyze as-is topology"),
    ("2️⃣", "Constraint Check",  "pages/2_Constraints.py",      "Verify all 4 core constraints"),
    ("3️⃣", "Complexity Score",  "pages/3_Complexity.py",       "OCS as-is vs target comparison"),
    ("4️⃣", "Target State",      "pages/4_Target_State.py",     "Generated topology, CSV, MQSC"),
]
for col, (icon, title, _, desc) in zip([col1, col2, col3, col4], pages):
    with col:
        st.markdown(f"""
        <div class="metric-card" style="border-color:#00e5ff44;">
          <div style="font-size:28px">{icon}</div>
          <div style="color:#00e5ff;font-weight:700;font-size:13px;margin:6px 0;">{title}</div>
          <div style="color:#7ea8c9;font-size:11px;">{desc}</div>
        </div>
        """, unsafe_allow_html=True)

st.markdown("---")

# ── Quick Run ─────────────────────────────────────────────────────────────
st.markdown("### ⚡ Quick Run")

with st.expander("Run Full Pipeline from This Page", expanded=True):
    uploaded = st.file_uploader(
        "Upload MQ topology CSV", type=["csv"],
        help="Same schema as MQ.Raw.Data.cleaned_v002"
    )
    col_a, col_b, col_c = st.columns(3)
    with col_a:
        use_ai = st.checkbox("Enable AI Agent (needs API key)", value=False)
    with col_b:
        make_viz = st.checkbox("Generate Visualizations", value=True)
    with col_c:
        verbose = st.checkbox("Verbose Logging", value=False)

    if st.button("🚀 Run Pipeline", type="primary", use_container_width=True):
        if not uploaded:
            st.error("Please upload a topology CSV first.")
        else:
            import tempfile, os
            from src.ingestion.loader import load_topology
            from src.graph.topology_graph import build_graph
            from src.constraints.engine import run_constraints
            from src.observability.ocs_scorer import compute_ocs
            from src.generator.target_state import generate_target_state
            from src.generator.report_writer import save_all
            from src.agent.analysis_agent import run_agent

            with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
                tmp.write(uploaded.getbuffer())
                tmp_path = tmp.name

            with st.spinner("Running 6-layer pipeline..."):
                try:
                    ds     = load_topology(tmp_path)
                    tg     = build_graph(ds)
                    report = run_constraints(ds, tg)
                    ocs    = compute_ocs(ds, tg, report, "as-is")
                    arts   = generate_target_state(ds, tg, report)
                    agent  = run_agent(ds, tg, report, ocs, arts, use_llm=use_ai)

                    from src.observability.ocs_scorer import OCSResult
                    ocs_t  = OCSResult(
                        c_base=len(arts.target_qms)+len(arts.channel_pairs)*2,
                        c_violations=0, c_redundancy=0, c_coupling=0, label="target"
                    )
                    saved  = save_all(arts, ocs, ocs_t, report, agent)

                    st.session_state["ds"]     = ds
                    st.session_state["tg"]     = tg
                    st.session_state["report"] = report
                    st.session_state["ocs"]    = ocs
                    st.session_state["arts"]   = arts
                    st.session_state["agent"]  = agent
                    st.session_state["ocs_t"]  = ocs_t

                    st.success("✅ Pipeline complete!")
                    reduction = round((1 - ocs_t.total / max(ocs.total,1))*100, 1)
                    c1, c2, c3, c4 = st.columns(4)
                    c1.metric("As-Is OCS",    ocs.total,    delta=None)
                    c2.metric("Target OCS",   ocs_t.total,  delta=f"-{ocs.total - ocs_t.total}")
                    c3.metric("Reduction",    f"{reduction}%")
                    c4.metric("Violations",   len(report.violations), delta=f"→ 0")
                    st.info("Navigate to the pages in the sidebar for detailed views.")
                except Exception as e:
                    st.error(f"Pipeline error: {e}")
                    import traceback; st.code(traceback.format_exc())
                finally:
                    os.unlink(tmp_path)

st.markdown("---")
st.markdown("""
<div style="text-align:center;color:#3d5a7a;font-size:11px;font-family:monospace;">
  IBM MQ Hackathon · Intelligent Topology Simplification & Automation · v1.0
</div>
""", unsafe_allow_html=True)
