#!/usr/bin/env python3
"""
validate_target.py — Standalone target state validator
Checks that a generated target_topology.csv satisfies all 4 core constraints.

Usage:
  python scripts/validate_target.py --target outputs/target_topology.csv
  python scripts/validate_target.py --target outputs/target_topology.csv --strict
"""
import sys, re, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from src.utils.logger import get_logger

log = get_logger("validate_target")

PASS_ICON = "\033[92m✓\033[0m"
FAIL_ICON = "\033[91m✗\033[0m"
WARN_ICON = "\033[93m⚠\033[0m"


def validate(target_csv: str, strict: bool = False) -> dict:
    path = Path(target_csv)
    if not path.exists():
        print(f"{FAIL_ICON} File not found: {path}")
        sys.exit(1)

    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df.columns = df.columns.str.strip()
    df = df.map(lambda x: x.strip() if isinstance(x, str) else x)

    results = {}
    all_pass = True

    print(f"\n{'═'*60}")
    print(f"  TARGET STATE VALIDATOR")
    print(f"  File: {path.name}  |  Rows: {len(df)}")
    print(f"{'═'*60}")

    # ── C1: 1 QM per App ─────────────────────────────────────────────────
    print("\n[C1] One QM per AppID")
    if "app_id" in df.columns and "queue_manager_name" in df.columns:
        app_qm_map = df.groupby("app_id")["queue_manager_name"].nunique()
        violations = app_qm_map[app_qm_map > 1]
        if violations.empty:
            print(f"  {PASS_ICON} All {len(app_qm_map)} apps have exactly 1 QM")
            results["C1"] = "PASS"
        else:
            for app, count in violations.items():
                qms = df[df["app_id"] == app]["queue_manager_name"].unique()
                print(f"  {FAIL_ICON} App '{app}' on {count} QMs: {list(qms)}")
            results["C1"] = "FAIL"
            all_pass = False
    else:
        print(f"  {WARN_ICON} Missing app_id or queue_manager_name columns")
        results["C1"] = "SKIP"

    # ── C2: Producers have Remote queue type ─────────────────────────────
    print("\n[C2] Producers write to Remote queues")
    if "PrimaryAppRole" in df.columns and "q_type" in df.columns:
        prod = df[df["PrimaryAppRole"].str.upper() == "PRODUCER"]
        non_remote = prod[prod["q_type"] != "Remote"]
        if non_remote.empty:
            print(f"  {PASS_ICON} All {len(prod)} producer rows have q_type=Remote")
            results["C2"] = "PASS"
        else:
            for _, row in non_remote.head(5).iterrows():
                print(f"  {FAIL_ICON} Producer '{row.get('app_id','')}' queue "
                      f"'{row.get('Discrete Queue Name','')}' has type='{row['q_type']}'")
            results["C2"] = "FAIL"
            all_pass = False
    else:
        print(f"  {WARN_ICON} Missing required columns")
        results["C2"] = "SKIP"

    # ── C3: Consumers have Local queue type ───────────────────────────────
    print("\n[C3] Consumers read from Local queues")
    if "PrimaryAppRole" in df.columns and "q_type" in df.columns:
        cons = df[df["PrimaryAppRole"].str.upper() == "CONSUMER"]
        non_local = cons[cons["q_type"] != "Local"]
        if non_local.empty:
            print(f"  {PASS_ICON} All {len(cons)} consumer rows have q_type=Local")
            results["C3"] = "PASS"
        else:
            for _, row in non_local.head(5).iterrows():
                print(f"  {FAIL_ICON} Consumer '{row.get('app_id','')}' queue "
                      f"'{row.get('Discrete Queue Name','')}' has type='{row['q_type']}'")
            results["C3"] = "FAIL"
            all_pass = False
    else:
        print(f"  {WARN_ICON} Missing required columns")
        results["C3"] = "SKIP"

    # ── C4: Deterministic channel naming ─────────────────────────────────
    print("\n[C4] Deterministic channel naming (QM.A.QM.B pattern)")
    if "channel_sender" in df.columns:
        pattern = re.compile(r"^QM\.[A-Z0-9]+\.QM\.[A-Z0-9]+$")
        channels = df["channel_sender"].dropna().unique()
        channels = [c for c in channels if c.strip()]
        bad = [c for c in channels if not pattern.match(c)]
        if not bad:
            print(f"  {PASS_ICON} All {len(channels)} channel names follow deterministic pattern")
            results["C4"] = "PASS"
        else:
            for c in bad[:5]:
                print(f"  {FAIL_ICON} Non-deterministic channel name: '{c}'")
            results["C4"] = "FAIL"
            all_pass = False
    else:
        print(f"  {WARN_ICON} No channel_sender column — skipping")
        results["C4"] = "SKIP"

    # ── Extended: No alias queues ─────────────────────────────────────────
    print("\n[EXT] No Alias queue types")
    if "q_type" in df.columns:
        alias_rows = df[df["q_type"].str.contains("Alias", na=False)]
        if alias_rows.empty:
            print(f"  {PASS_ICON} No alias queues found")
            results["EXT_NO_ALIAS"] = "PASS"
        else:
            print(f"  {WARN_ICON} {len(alias_rows)} alias queue rows found")
            results["EXT_NO_ALIAS"] = "WARN"

    # ── QM naming convention ──────────────────────────────────────────────
    print("\n[EXT] QM naming convention (QM.<AppID>)")
    if "queue_manager_name" in df.columns:
        qm_pattern = re.compile(r"^QM\.[A-Z0-9]+$")
        qms = df["queue_manager_name"].unique()
        bad_qms = [q for q in qms if not qm_pattern.match(q)]
        if not bad_qms:
            print(f"  {PASS_ICON} All {len(qms)} QM names follow QM.<AppID> convention")
            results["EXT_QM_NAMING"] = "PASS"
        else:
            for q in bad_qms[:5]:
                print(f"  {WARN_ICON} Non-standard QM name: '{q}'")
            results["EXT_QM_NAMING"] = "WARN"

    # ── Summary ───────────────────────────────────────────────────────────
    passed = sum(1 for v in results.values() if v == "PASS")
    failed = sum(1 for v in results.values() if v == "FAIL")
    warned = sum(1 for v in results.values() if v == "WARN")

    print(f"\n{'═'*60}")
    icon = PASS_ICON if all_pass else FAIL_ICON
    status = "ALL CONSTRAINTS SATISFIED" if all_pass else "CONSTRAINT VIOLATIONS FOUND"
    print(f"  {icon} {status}")
    print(f"  Passed: {passed}  |  Failed: {failed}  |  Warnings: {warned}")
    print(f"{'═'*60}\n")

    if strict and not all_pass:
        sys.exit(1)

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Validate a target-state topology CSV against all 4 core constraints"
    )
    parser.add_argument("--target", "-t", required=True,
                        help="Path to target_topology.csv")
    parser.add_argument("--strict", action="store_true",
                        help="Exit code 1 if any constraint fails")
    args = parser.parse_args()
    validate(args.target, strict=args.strict)


if __name__ == "__main__":
    main()
