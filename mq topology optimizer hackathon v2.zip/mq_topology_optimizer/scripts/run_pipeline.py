#!/usr/bin/env python3
"""
MQ Topology Optimizer — Complete Pipeline CLI  v2.0
Runs all 6 layers + generates every hackathon deliverable.

Usage:
  python scripts/run_pipeline.py --input data/sample/mq_topology.csv
  python scripts/run_pipeline.py --input data/sample/mq_topology.csv --ai-agent
  python scripts/run_pipeline.py --input data/sample/mq_topology.csv --full
  python scripts/run_pipeline.py --help
"""
import sys, json, argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.ingestion.loader import load_topology
from src.graph.topology_graph import build_graph
from src.constraints.engine import run_constraints
from src.observability.ocs_scorer import compute_ocs, OCSResult
from src.observability.metrics_dashboard import build_metrics
from src.generator.target_state import generate_target_state
from src.generator.report_writer import save_all
from src.generator.transformation_plan import generate_transformation_plan
from src.generator.pdf_report import generate_pdf_report
from src.graph.visualizer import visualize_asis, visualize_target
from src.agent.analysis_agent import run_agent
from src.utils.config import OUTPUT_DIR, ai_enabled
from src.utils.logger import get_logger

log = get_logger("pipeline")

BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║   IBM MQ  ·  Intelligent Topology Simplification & Automation   ║
║   Hackathon Submission  ·  End-to-End Pipeline  v2.0            ║
╚══════════════════════════════════════════════════════════════════╝
"""

DELIVERABLES = """
Deliverables generated:
  1.  target_topology.csv       ← Target state (same schema as input)
  2.  target_state.mqsc         ← MQSC automation scripts (idempotent)
  3.  main.tf                   ← Terraform IBM MQ resources
  4.  complexity_report.json    ← OCS as-is vs target comparison
  5.  decision_log.json         ← Full AI decision rationale
  6.  agent_report.json         ← 6-pass agent results
  7.  violations.json           ← Constraint violations catalog
  8.  transformation_plan.md    ← 5-phase migration plan (Markdown)
  9.  topology_diff.json        ← As-is vs target structured diff
  10. hackathon_report.pdf      ← Complete submission report
  11. topology_asis.html        ← Interactive as-is visualization
  12. topology_target.html      ← Interactive target visualization
  13. metrics_summary.json      ← Dashboard metrics export
"""


def _build_target_ocs(arts) -> OCSResult:
    return OCSResult(
        c_base=len(arts.target_qms) + len(arts.channel_pairs) * 2,
        c_violations=0, c_redundancy=0, c_coupling=0, label="target"
    )


def run_pipeline(
    input_path: str,
    output_dir: str | None = None,
    use_ai_agent: bool = False,
    visualize: bool = True,
    generate_pdf: bool = True,
    verbose: bool = False,
) -> dict:
    print(BANNER)

    out_dir = Path(output_dir) if output_dir else OUTPUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)

    # ────────────────────────────────────────────────────────────────────
    # LAYER 1 — Ingest
    # ────────────────────────────────────────────────────────────────────
    print("═"*60)
    print("► LAYER 1 — CSV Ingestion & Validation")
    print("═"*60)
    ds = load_topology(input_path)
    if not ds.is_valid:
        print(f"  ✗ Validation errors: {ds.validation_errors}")
        sys.exit(1)
    print(f"  ✓ {len(ds.raw_df)} rows | {len(ds.queue_managers)} QMs | "
          f"{len(ds.app_ids)} apps | {len(ds.queues)} unique queues")

    # ────────────────────────────────────────────────────────────────────
    # LAYER 2 — Graph
    # ────────────────────────────────────────────────────────────────────
    print("\n► LAYER 2 — Topology Graph Construction")
    tg = build_graph(ds)
    print(f"  ✓ {tg.G.number_of_nodes()} nodes | {tg.G.number_of_edges()} edges | "
          f"{len(tg.comm_flows)} flows | {len(tg.multi_hop_flows)} multi-hop | "
          f"{len(tg.alias_queues)} aliases | {len(tg.clusters)} clusters")

    # ────────────────────────────────────────────────────────────────────
    # LAYER 3 — Constraints
    # ────────────────────────────────────────────────────────────────────
    print("\n► LAYER 3 — Constraint Engine (4 Core + Extended Rules)")
    report = run_constraints(ds, tg)
    crits  = len(report.critical_violations)
    icon   = "✗" if report.has_hard_blocks else "✓"
    print(f"  {icon} {len(report.violations)} violations ({crits} CRITICAL | "
          f"{len([v for v in report.violations if v.severity=='HIGH'])} HIGH)")
    if verbose:
        for v in report.violations:
            print(f"      [{v.severity}] {v.rule_id}: {v.description[:70]}")

    # ────────────────────────────────────────────────────────────────────
    # LAYER 6 — OCS (as-is)
    # ────────────────────────────────────────────────────────────────────
    print("\n► LAYER 6 — Operational Complexity Score (As-Is)")
    ocs_asis = compute_ocs(ds, tg, report, label="as-is")
    print(f"  ✓ {ocs_asis.summary()}")

    # ────────────────────────────────────────────────────────────────────
    # LAYER 5 — Target State
    # ────────────────────────────────────────────────────────────────────
    print("\n► LAYER 5 — Target State Generator")
    arts       = generate_target_state(ds, tg, report)
    ocs_target = _build_target_ocs(arts)
    reduction  = round((1 - ocs_target.total / max(ocs_asis.total, 1)) * 100, 1)
    print(f"  ✓ {len(arts.target_qms)} QMs | {len(arts.channel_pairs)} channel pairs | "
          f"{len(arts.target_df)} rows | {len(arts.mqsc_commands)} MQSC lines")
    print(f"  ✓ OCS: {ocs_asis.total} → {ocs_target.total}  ({reduction}% reduction)")

    # ────────────────────────────────────────────────────────────────────
    # LAYER 4 — AI Agent
    # ────────────────────────────────────────────────────────────────────
    llm_status = "LLM-enabled" if (use_ai_agent and ai_enabled()) else "deterministic"
    print(f"\n► LAYER 4 — AI Analysis Agent ({llm_status}, 6 passes)")
    agent = run_agent(ds, tg, report, ocs_asis, arts, use_llm=use_ai_agent)
    print(f"  ✓ Confidence={agent.overall_confidence:.0%} | "
          f"Human review={'required' if agent.human_review_required else 'not required'}")

    # ────────────────────────────────────────────────────────────────────
    # Transformation Plan
    # ────────────────────────────────────────────────────────────────────
    print("\n► Generating 5-Phase Transformation Plan...")
    plan = generate_transformation_plan(ds, tg, report, arts)
    plan_path = out_dir / "transformation_plan.md"
    plan_path.write_text(plan.to_markdown(), encoding="utf-8")
    print(f"  ✓ {plan.total_steps} steps | {plan.estimated_duration} | "
          f"{len(plan.provision_list)} QMs to provision | "
          f"{len(plan.decommission_list)} QMs to decommission")
    print(f"  ✓ Saved: {plan_path}")

    # ────────────────────────────────────────────────────────────────────
    # Topology Diff
    # ────────────────────────────────────────────────────────────────────
    print("\n► Computing Topology Diff (as-is vs target)...")
    asis_qms   = set(ds.queue_managers)
    target_qms = set(arts.target_qms)
    diff = {
        "qms_added":   sorted(target_qms - asis_qms),
        "qms_removed": sorted(asis_qms - target_qms),
        "qms_kept":    sorted(asis_qms & target_qms),
        "ocs_asis":    ocs_asis.total,
        "ocs_target":  ocs_target.total,
        "reduction":   reduction,
        "violations_before": len(report.violations),
        "violations_after":  0,
    }
    diff_path = out_dir / "topology_diff.json"
    diff_path.write_text(json.dumps(diff, indent=2), encoding="utf-8")
    print(f"  ✓ QMs: {len(asis_qms)}→{len(target_qms)} | "
          f"+{len(diff['qms_added'])} added / "
          f"-{len(diff['qms_removed'])} removed")

    # ────────────────────────────────────────────────────────────────────
    # Metrics
    # ────────────────────────────────────────────────────────────────────
    metrics = build_metrics(ds, tg, report, ocs_asis, arts, ocs_target)
    metrics_path = out_dir / "metrics_summary.json"
    metrics_path.write_text(json.dumps(metrics.to_dict(), indent=2), encoding="utf-8")

    # ────────────────────────────────────────────────────────────────────
    # Save Core Artifacts
    # ────────────────────────────────────────────────────────────────────
    print("\n► Saving core artifacts...")
    saved = save_all(arts, ocs_asis, ocs_target, report, agent, out_dir)
    for name, path in saved.items():
        print(f"  ✓ {name}: {Path(path).name}")
    print(f"  ✓ topology_diff: {diff_path.name}")
    print(f"  ✓ metrics_summary: {metrics_path.name}")

    # ────────────────────────────────────────────────────────────────────
    # Visualizations
    # ────────────────────────────────────────────────────────────────────
    if visualize:
        print("\n► Generating topology visualizations...")
        v1 = visualize_asis(tg, out_dir)
        v2 = visualize_target(arts, out_dir)
        if v1: print(f"  ✓ As-is:  {Path(v1).name}")
        if v2: print(f"  ✓ Target: {Path(v2).name}")

    # ────────────────────────────────────────────────────────────────────
    # PDF Report
    # ────────────────────────────────────────────────────────────────────
    if generate_pdf:
        print("\n► Generating hackathon submission report (PDF)...")
        pdf_path = generate_pdf_report(
            ds, tg, report, ocs_asis, ocs_target, arts, agent, out_dir
        )
        if pdf_path:
            print(f"  ✓ Report: {Path(pdf_path).name}")

    # ────────────────────────────────────────────────────────────────────
    # Final Summary
    # ────────────────────────────────────────────────────────────────────
    print("\n" + "═"*60)
    print("  ✅  PIPELINE COMPLETE — ALL DELIVERABLES READY")
    print("═"*60)
    print(f"  As-Is  OCS     : {ocs_asis.total}")
    print(f"  Target OCS     : {ocs_target.total}")
    print(f"  OCS Reduction  : {reduction}%")
    print(f"  Violations     : {len(report.violations)} → 0")
    print(f"  Target QMs     : {len(arts.target_qms)} (was {len(ds.queue_managers)})")
    print(f"  Channel Pairs  : {len(arts.channel_pairs)}")
    print(f"  Plan Steps     : {plan.total_steps} steps / {plan.estimated_duration}")
    print(f"  Output dir     : {out_dir.resolve()}")
    print("─"*60)
    print(DELIVERABLES)
    print("═"*60)

    return {
        "ocs_asis":    ocs_asis.total,
        "ocs_target":  ocs_target.total,
        "reduction":   reduction,
        "violations":  len(report.violations),
        "target_qms":  len(arts.target_qms),
        "channels":    len(arts.channel_pairs),
        "plan_steps":  plan.total_steps,
        "ai_used":     use_ai_agent and ai_enabled(),
        "output_dir":  str(out_dir.resolve()),
        "saved_files": saved,
    }


def main():
    parser = argparse.ArgumentParser(
        description="IBM MQ Intelligent Topology Simplification — Complete Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/run_pipeline.py --input data/sample/mq_topology.csv
  python scripts/run_pipeline.py --input data/sample/mq_topology.csv --ai-agent --verbose
  python scripts/run_pipeline.py --input data/sample/mq_topology.csv --full
        """,
    )
    parser.add_argument("--input",      "-i", required=True,
                        help="Path to input MQ topology CSV file")
    parser.add_argument("--output-dir", "-o", default=None,
                        help="Output directory (default: outputs/)")
    parser.add_argument("--ai-agent",   action="store_true",
                        help="Enable LLM reasoning (needs API key in .env)")
    parser.add_argument("--full",       action="store_true",
                        help="Run everything including AI agent")
    parser.add_argument("--no-viz",     action="store_true",
                        help="Skip topology visualizations")
    parser.add_argument("--no-pdf",     action="store_true",
                        help="Skip PDF report generation")
    parser.add_argument("--verbose",    "-v", action="store_true",
                        help="Print all violations during constraint check")
    args = parser.parse_args()

    use_ai = args.ai_agent or args.full

    result = run_pipeline(
        input_path=args.input,
        output_dir=args.output_dir,
        use_ai_agent=use_ai,
        visualize=not args.no_viz,
        generate_pdf=not args.no_pdf,
        verbose=args.verbose,
    )
    return 0 if result else 1


if __name__ == "__main__":
    sys.exit(main())
