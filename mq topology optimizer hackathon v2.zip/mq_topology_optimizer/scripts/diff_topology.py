#!/usr/bin/env python3
"""
diff_topology.py — Compare as-is vs target topology and produce a structured diff.

Usage:
  python scripts/diff_topology.py \
    --asis data/sample/mq_topology.csv \
    --target outputs/target_topology.csv
"""
import sys, json, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pandas as pd
from src.utils.logger import get_logger
from src.utils.config import OUTPUT_DIR

log = get_logger("diff_topology")


def diff_topologies(asis_path: str, target_path: str, output_dir: str | None = None) -> dict:
    out = Path(output_dir or OUTPUT_DIR)
    out.mkdir(parents=True, exist_ok=True)

    df_asis   = pd.read_csv(asis_path,   dtype=str, keep_default_na=False)
    df_target = pd.read_csv(target_path, dtype=str, keep_default_na=False)
    df_asis.columns   = df_asis.columns.str.strip()
    df_target.columns = df_target.columns.str.strip()

    diff = {
        "summary": {},
        "queue_managers": {"added": [], "removed": [], "kept": []},
        "queues":         {"added": [], "removed": [], "type_changed": []},
        "apps":           {"consolidated": [], "unchanged": []},
        "flows":          {"simplified": [], "new_direct": []},
    }

    # ── QM diff ───────────────────────────────────────────────────────────
    asis_qms   = set(df_asis["queue_manager_name"].unique())   if "queue_manager_name" in df_asis.columns   else set()
    target_qms = set(df_target["queue_manager_name"].unique()) if "queue_manager_name" in df_target.columns else set()

    diff["queue_managers"]["added"]   = sorted(target_qms - asis_qms)
    diff["queue_managers"]["removed"] = sorted(asis_qms - target_qms)
    diff["queue_managers"]["kept"]    = sorted(asis_qms & target_qms)

    # ── Queue diff ─────────────────────────────────────────────────────────
    asis_qs   = set(df_asis["Discrete Queue Name"].unique())   if "Discrete Queue Name" in df_asis.columns   else set()
    target_qs = set(df_target["Discrete Queue Name"].unique()) if "Discrete Queue Name" in df_target.columns else set()

    diff["queues"]["added"]   = sorted(target_qs - asis_qs)
    diff["queues"]["removed"] = sorted(asis_qs - target_qs)

    # Type changes
    common_qs = asis_qs & target_qs
    if "q_type" in df_asis.columns and "q_type" in df_target.columns:
        for q in sorted(common_qs):
            asis_type   = df_asis[df_asis["Discrete Queue Name"] == q]["q_type"].iloc[0] if len(df_asis[df_asis["Discrete Queue Name"] == q]) else ""
            target_type = df_target[df_target["Discrete Queue Name"] == q]["q_type"].iloc[0] if len(df_target[df_target["Discrete Queue Name"] == q]) else ""
            if asis_type != target_type:
                diff["queues"]["type_changed"].append({
                    "queue": q, "from": asis_type, "to": target_type
                })

    # ── App consolidation ──────────────────────────────────────────────────
    if "app_id" in df_asis.columns and "queue_manager_name" in df_asis.columns:
        asis_app_qm = df_asis.groupby("app_id")["queue_manager_name"].apply(set).to_dict()
        for app, qms in sorted(asis_app_qm.items()):
            if len(qms) > 1:
                target_qm = f"QM.{app}"
                diff["apps"]["consolidated"].append({
                    "app": app,
                    "from_qms": sorted(qms),
                    "to_qm": target_qm,
                    "qm_count_reduction": len(qms) - 1,
                })
            else:
                diff["apps"]["unchanged"].append({"app": app, "qm": list(qms)[0]})

    # ── Summary stats ──────────────────────────────────────────────────────
    diff["summary"] = {
        "qms_added":      len(diff["queue_managers"]["added"]),
        "qms_removed":    len(diff["queue_managers"]["removed"]),
        "qms_kept":       len(diff["queue_managers"]["kept"]),
        "queues_added":   len(diff["queues"]["added"]),
        "queues_removed": len(diff["queues"]["removed"]),
        "type_changes":   len(diff["queues"]["type_changed"]),
        "apps_consolidated": len(diff["apps"]["consolidated"]),
        "asis_qm_count":  len(asis_qms),
        "target_qm_count": len(target_qms),
    }

    # ── Print diff ─────────────────────────────────────────────────────────
    print("\n" + "═"*60)
    print("  TOPOLOGY DIFF: As-Is → Target")
    print("═"*60)
    s = diff["summary"]
    print(f"\n  Queue Managers: {s['asis_qm_count']} → {s['target_qm_count']}")
    print(f"    + Added:   {s['qms_added']}  (new target QMs)")
    print(f"    - Removed: {s['qms_removed']}  (legacy QMs decommissioned)")
    print(f"    = Kept:    {s['qms_kept']}")
    print(f"\n  Queues:")
    print(f"    + Added:        {s['queues_added']}")
    print(f"    - Removed:      {s['queues_removed']}")
    print(f"    ~ Type changed: {s['type_changes']}")
    print(f"\n  Apps consolidated: {s['apps_consolidated']}")
    for a in diff["apps"]["consolidated"][:5]:
        print(f"    {a['app']}: {a['from_qms']} → {a['to_qm']}")

    if diff["queue_managers"]["removed"]:
        print(f"\n  QMs to decommission ({len(diff['queue_managers']['removed'])}):")
        for qm in diff["queue_managers"]["removed"][:8]:
            print(f"    - {qm}")

    # ── Save diff JSON ─────────────────────────────────────────────────────
    diff_path = out / "topology_diff.json"
    diff_path.write_text(json.dumps(diff, indent=2), encoding="utf-8")
    print(f"\n  Diff saved: {diff_path}")
    print("═"*60 + "\n")
    return diff


def main():
    parser = argparse.ArgumentParser(
        description="Compare as-is vs target MQ topology and produce structured diff"
    )
    parser.add_argument("--asis",   "-a", required=True, help="As-is topology CSV")
    parser.add_argument("--target", "-t", required=True, help="Target topology CSV")
    parser.add_argument("--output-dir", "-o", default=None)
    args = parser.parse_args()
    diff_topologies(args.asis, args.target, args.output_dir)


if __name__ == "__main__":
    main()
