#!/usr/bin/env python3
"""
Exploratory Data Analysis — MQ Topology Dataset
Run: python notebooks/eda_analysis.py
Produces console report + saves charts to outputs/eda/
"""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.ingestion.loader import load_topology
from src.graph.topology_graph import build_graph, compute_fan_out
from src.constraints.engine import run_constraints
from src.observability.ocs_scorer import compute_ocs
from src.generator.target_state import generate_target_state
from src.utils.config import OUTPUT_DIR

INPUT = Path(__file__).parent.parent / "data" / "sample" / "mq_topology.csv"
EDA_DIR = OUTPUT_DIR / "eda"
EDA_DIR.mkdir(parents=True, exist_ok=True)

def section(title: str):
    print(f"\n{'━'*60}")
    print(f"  {title}")
    print('━'*60)

def main():
    print("\n" + "═"*60)
    print("  MQ TOPOLOGY — EXPLORATORY DATA ANALYSIS")
    print("═"*60)

    # Load
    ds     = load_topology(INPUT)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    ocs    = compute_ocs(ds, tg, report)
    arts   = generate_target_state(ds, tg, report)

    # ── Dataset shape ─────────────────────────────────────────────────────
    section("1. DATASET OVERVIEW")
    print(f"  Total rows:        {len(ds.raw_df)}")
    print(f"  Queue Managers:    {len(ds.queue_managers)}")
    print(f"  Applications:      {len(ds.app_ids)}")
    print(f"  Unique Queues:     {len(ds.queues)}")
    print(f"  Producer rows:     {len(ds.producer_rows)}")
    print(f"  Consumer rows:     {len(ds.consumer_rows)}")
    print(f"  Columns:           {len(ds.raw_df.columns)}")

    # ── Column distribution ────────────────────────────────────────────────
    section("2. QUEUE TYPE DISTRIBUTION")
    if "q_type" in ds.raw_df.columns:
        qt_counts = ds.raw_df["q_type"].value_counts()
        for qt, cnt in qt_counts.items():
            bar = "█" * min(int(cnt / max(qt_counts.max(), 1) * 30), 30)
            print(f"  {qt:<30} {bar} {cnt}")

    section("3. NEIGHBORHOOD DISTRIBUTION")
    if "Neighborhood" in ds.raw_df.columns:
        nb_counts = ds.raw_df["Neighborhood"].value_counts()
        for nb, cnt in nb_counts.head(10).items():
            print(f"  {str(nb):<35} {cnt:>4} rows")

    section("4. LINE-OF-BUSINESS DISTRIBUTION")
    if "line_of_business" in ds.raw_df.columns:
        lob_counts = ds.raw_df["line_of_business"].value_counts()
        for lob, cnt in lob_counts.items():
            print(f"  {lob:<20} {cnt:>4} rows")

    # ── App-QM analysis ───────────────────────────────────────────────────
    section("5. APP → QM CARDINALITY (Violation Analysis)")
    print(f"  {'App ID':<15} {'# QMs':<8} {'QMs'}")
    for app, qms in sorted(tg.app_to_qms.items(), key=lambda x: -len(x[1])):
        flag = " ← VIOLATION" if len(qms) > 1 else ""
        print(f"  {app:<15} {len(qms):<8} {sorted(qms)}{flag}")

    section("6. QM → APPS (Blast Radius Analysis)")
    print(f"  {'QM':<15} {'# Apps':<8} {'Apps'}")
    for qm, apps in sorted(tg.qm_to_apps.items(), key=lambda x: -len(x[1])):
        risk = " [HIGH BLAST RADIUS]" if len(apps) >= 3 else (" [MEDIUM]" if len(apps) > 1 else "")
        print(f"  {qm:<15} {len(apps):<8} {sorted(apps)}{risk}")

    section("7. COMMUNICATION FLOWS (Hop Analysis)")
    multi = [f for f in tg.comm_flows if f["hops"] > 1]
    direct = [f for f in tg.comm_flows if f["hops"] == 1]
    print(f"  Total flows:      {len(tg.comm_flows)}")
    print(f"  Direct (1-hop):   {len(direct)}")
    print(f"  Multi-hop (2+):   {len(multi)}")
    if multi:
        print("\n  Multi-hop flows:")
        for f in multi:
            print(f"    {f['from_app']} → [{f.get('intermediate_qm','?')}] → {f['to_app']} ({f['hops']} hops)")

    section("8. FAN-OUT RANKING")
    fan = compute_fan_out(tg)
    for app, count in sorted(fan.items(), key=lambda x: -x[1]):
        bar = "█" * min(count * 4, 40)
        print(f"  {app:<15} {bar} {count}")

    section("9. ANTI-PATTERN CATALOG")
    print(f"  Alias queues ({len(tg.alias_queues)}):")
    for q in tg.alias_queues:
        print(f"    - {q}")
    print(f"\n  Hybrid queue types ({len(tg.hybrid_queues)}):")
    for q in tg.hybrid_queues[:5]:
        print(f"    - {q} ({tg.queue_types.get(q,'?')})")
    print(f"\n  MQ Clusters ({len(tg.clusters)}): {sorted(tg.clusters)}")

    section("10. OPERATIONAL COMPLEXITY SCORE")
    print(f"  Formula: OCS = C_base + C_violations + C_redundancy + C_coupling")
    print(f"\n  AS-IS:")
    print(f"    C_base        = {ocs.c_base:>5}")
    print(f"    C_violations  = {ocs.c_violations:>5}")
    print(f"    C_redundancy  = {ocs.c_redundancy:>5}")
    print(f"    C_coupling    = {ocs.c_coupling:>5}")
    print(f"    ─────────────────────")
    print(f"    TOTAL OCS     = {ocs.total:>5}")

    target_ocs = len(arts.target_qms) + len(arts.channel_pairs) * 2
    reduction  = round((1 - target_ocs / max(ocs.total,1)) * 100, 1)
    print(f"\n  TARGET:")
    print(f"    TOTAL OCS     = {target_ocs:>5}  ({reduction}% reduction)")

    section("11. VIOLATION SUMMARY")
    sev_counts = {}
    for v in report.violations:
        sev_counts[v.severity] = sev_counts.get(v.severity, 0) + 1
    for sev in ["CRITICAL","HIGH","MEDIUM","LOW"]:
        cnt = sev_counts.get(sev, 0)
        print(f"  {sev:<10} {cnt:>3} violations")
    print(f"\n  Total violation score: {report.total_violation_score}")
    print(f"  Hard blocks (CRITICAL): {report.has_hard_blocks}")

    section("12. TARGET STATE SUMMARY")
    print(f"  Target QMs:     {len(arts.target_qms)}")
    print(f"  Channel pairs:  {len(arts.channel_pairs)}")
    print(f"  Queue rows:     {len(arts.target_df)}")
    print(f"  MQSC lines:     {len(arts.mqsc_commands)}")
    print(f"  Decisions made: {len(arts.decision_log)}")

    # ── Save EDA summary JSON ──────────────────────────────────────────────
    eda_summary = {
        "dataset": {
            "rows": len(ds.raw_df), "qms": len(ds.queue_managers),
            "apps": len(ds.app_ids), "queues": len(ds.queues),
        },
        "violations": {
            v.rule_id: v.score_contribution for v in report.violations
        },
        "ocs": {
            "as_is": ocs.total, "target": target_ocs,
            "reduction_pct": reduction,
            "breakdown": ocs.breakdown,
        },
        "anti_patterns": {
            "alias_queues": len(tg.alias_queues),
            "hybrid_queues": len(tg.hybrid_queues),
            "clusters": len(tg.clusters),
            "multi_hop_flows": len(tg.multi_hop_flows),
        },
        "target": {
            "qms": len(arts.target_qms),
            "channel_pairs": len(arts.channel_pairs),
        },
    }
    eda_path = EDA_DIR / "eda_summary.json"
    eda_path.write_text(json.dumps(eda_summary, indent=2))
    print(f"\n  EDA summary saved: {eda_path}")

    # ── Optional matplotlib charts ────────────────────────────────────────
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        # Chart 1: OCS comparison
        fig, axes = plt.subplots(1, 2, figsize=(12, 5), facecolor="#0a0e17")
        for ax in axes:
            ax.set_facecolor("#0c1422")
            for spine in ax.spines.values():
                spine.set_color("#1a2e4a")

        # OCS breakdown bar
        dims = ["C_base","C_violations","C_redundancy","C_coupling"]
        asis_vals   = [ocs.c_base, ocs.c_violations, ocs.c_redundancy, ocs.c_coupling]
        target_vals = [len(arts.target_qms)+len(arts.channel_pairs)*2, 0, 0, 0]
        x = range(len(dims))
        axes[0].bar([i-0.2 for i in x], asis_vals,   0.35, label="As-Is",  color="#ff5252", alpha=0.85)
        axes[0].bar([i+0.2 for i in x], target_vals, 0.35, label="Target", color="#00e676", alpha=0.85)
        axes[0].set_xticks(list(x)); axes[0].set_xticklabels(dims, color="white", fontsize=8)
        axes[0].set_title("OCS Dimensional Comparison", color="white"); axes[0].legend()
        axes[0].tick_params(colors="white"); axes[0].yaxis.label.set_color("white")

        # App fan-out
        apps_sorted = sorted(fan.items(), key=lambda x: -x[1])[:8]
        app_names, counts = zip(*apps_sorted) if apps_sorted else ([], [])
        axes[1].barh(list(app_names), list(counts), color="#00e5ff", alpha=0.8)
        axes[1].set_title("App Fan-Out Ranking", color="white")
        axes[1].tick_params(colors="white")

        plt.tight_layout()
        chart_path = EDA_DIR / "ocs_analysis.png"
        plt.savefig(str(chart_path), dpi=120, bbox_inches="tight", facecolor="#0a0e17")
        plt.close()
        print(f"  Chart saved: {chart_path}")
    except ImportError:
        print("  (matplotlib not available — skipping charts)")

    print("\n" + "═"*60)
    print("  EDA COMPLETE")
    print("═"*60 + "\n")


if __name__ == "__main__":
    main()
