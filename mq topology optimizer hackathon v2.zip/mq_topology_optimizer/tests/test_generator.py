"""Tests for target state generator."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import tempfile
import os
import re

from src.ingestion.loader import load_topology
from src.graph.topology_graph import build_graph
from src.constraints.engine import run_constraints
from src.generator.target_state import generate_target_state

SAMPLE = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
MYQUEUE,ProdA,ConsB,ProdA,Test,Producer,Remote,Banking,Internal,Confidential,OLD_QM,ALPHA,LOB,,Yes,Synchronous,,,OLD_QM2,MYQUEUE,Normal,XMIT,Banking,Remote
MYQUEUE,ProdA,ConsB,ConsB,Test,Consumer,Local,Banking,Internal,Confidential,OLD_QM2,BETA,LOB,,Yes,Synchronous,Enabled,Enabled,,,Normal,,Banking,Local
"""

@pytest.fixture
def pipeline():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(SAMPLE)
        fname = f.name
    ds = load_topology(fname)
    os.unlink(fname)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    arts   = generate_target_state(ds, tg, report)
    return ds, tg, report, arts


def test_one_qm_per_app(pipeline):
    _, _, _, arts = pipeline
    # Each target QM name is QM.<AppID>
    for qm in arts.target_qms:
        assert qm.startswith("QM.")


def test_no_alias_in_target(pipeline):
    _, _, _, arts = pipeline
    if not arts.target_df.empty:
        assert "Alias" not in arts.target_df["q_type"].values


def test_deterministic_channel_naming(pipeline):
    _, _, _, arts = pipeline
    pattern = re.compile(r"^QM\.[A-Z0-9]+\.QM\.[A-Z0-9]+$")
    for cp in arts.channel_pairs:
        assert pattern.match(cp["sender_channel"]), \
            f"Non-deterministic name: {cp['sender_channel']}"


def test_producers_have_remote_q(pipeline):
    _, _, _, arts = pipeline
    if not arts.target_df.empty:
        prod = arts.target_df[arts.target_df["PrimaryAppRole"] == "Producer"]
        assert all(prod["q_type"] == "Remote"), "All producer rows must be Remote type"


def test_consumers_have_local_q(pipeline):
    _, _, _, arts = pipeline
    if not arts.target_df.empty:
        cons = arts.target_df[arts.target_df["PrimaryAppRole"] == "Consumer"]
        assert all(cons["q_type"] == "Local"), "All consumer rows must be Local type"


def test_mqsc_not_empty(pipeline):
    _, _, _, arts = pipeline
    assert len(arts.mqsc_commands) > 0
    mqsc_text = "\n".join(arts.mqsc_commands)
    assert "DEFINE QLOCAL" in mqsc_text
    assert "DEFINE QREMOTE" in mqsc_text
    assert "DEFINE CHANNEL" in mqsc_text


def test_terraform_generated(pipeline):
    _, _, _, arts = pipeline
    assert "ibm_mq_queue_manager" in arts.terraform_hcl
    assert "ibm_mq_channel" in arts.terraform_hcl


def test_decision_log_not_empty(pipeline):
    _, _, _, arts = pipeline
    assert len(arts.decision_log) > 0
    for d in arts.decision_log:
        assert "decision_id" in d
        assert "rationale" in d
        assert "confidence" in d
