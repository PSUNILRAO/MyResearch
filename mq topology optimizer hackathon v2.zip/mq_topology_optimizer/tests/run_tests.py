#!/usr/bin/env python3
"""
Standalone test runner — works without pytest installed.
Run: python3 tests/run_tests.py
"""
import sys, os, tempfile, re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

PASS = "\033[92m✓\033[0m"
FAIL = "\033[91m✗\033[0m"
results = []

def test(name, fn):
    try:
        fn()
        results.append((True, name))
        print(f"  {PASS} {name}")
    except Exception as e:
        results.append((False, name))
        print(f"  {FAIL} {name}: {e}")

# ── Helpers ───────────────────────────────────────────────────────────────
MINIMAL_CSV = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
Q.A.B,ProdA,ConsB,ProdA,T,Producer,Remote,Banking,Internal,Confidential,OLD_QM,ALPHA,LOB,,Yes,Sync,,,OLD_QM2,Q.A.B,Normal,XMIT,Banking,Remote
Q.A.B,ProdA,ConsB,ConsB,T,Consumer,Local,Banking,Internal,Confidential,OLD_QM2,BETA,LOB,,Yes,Sync,Enabled,Enabled,,,Normal,,Banking,Local
Q.A.B2,ProdA,ConsB2,ProdA,T,Producer,Remote,Banking,Internal,Confidential,OLD_QM,ALPHA,LOB,,Yes,Sync,,,OLD_QM2,Q.A.B2,Normal,XMIT,Banking,Remote
Q.A.B2,ProdA,ConsB2,ConsB2,T,Consumer,Local,Banking,Internal,Confidential,OLD_QM2,BETA,LOB,,Yes,Sync,Enabled,Enabled,,,Normal,,Banking,Local
ALIAS.Q,ProdA,ConsB,ProdA,T,Producer,Alias,Banking,Internal,Confidential,OLD_QM,ALPHA,LOB,,Yes,Sync,,,,,Normal,,Banking,Alias
MULTI.QM.Q,ProdA,ConsB,ProdA,T,Producer,Local,Banking,Internal,Confidential,OLD_QM,ALPHA,LOB,,Yes,Sync,,,,,Normal,,Banking,Local
MULTI.QM.Q,ProdA,ConsB,ProdA,T,Producer,Local,Banking,Internal,Confidential,OLD_QM3,ALPHA,LOB,,Yes,Sync,,,,,Normal,,Banking,Local
"""

def make_csv(content=MINIMAL_CSV):
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False)
    f.write(content); f.close()
    return f.name

def pipeline(content=MINIMAL_CSV):
    from src.ingestion.loader import load_topology
    from src.graph.topology_graph import build_graph
    from src.constraints.engine import run_constraints
    from src.observability.ocs_scorer import compute_ocs
    from src.generator.target_state import generate_target_state
    p = make_csv(content)
    ds = load_topology(p); os.unlink(p)
    tg = build_graph(ds)
    rp = run_constraints(ds, tg)
    oc = compute_ocs(ds, tg, rp)
    ar = generate_target_state(ds, tg, rp)
    return ds, tg, rp, oc, ar

# ── Layer 1: Ingestion ────────────────────────────────────────────────────
print("\n=== Layer 1: Ingestion ===")
from src.ingestion.loader import load_topology

def t_load_valid():
    p = make_csv(); ds = load_topology(p); os.unlink(p)
    assert ds.is_valid, ds.validation_errors
    assert len(ds.queue_managers) >= 2

def t_load_missing_file():
    try: load_topology("/no/such/file.csv"); assert False
    except FileNotFoundError: pass

def t_producer_consumer_split():
    p = make_csv(); ds = load_topology(p); os.unlink(p)
    assert len(ds.producer_rows) > 0
    assert len(ds.consumer_rows) > 0

def t_app_ids_populated():
    p = make_csv(); ds = load_topology(p); os.unlink(p)
    assert "ALPHA" in ds.app_ids
    assert "BETA" in ds.app_ids

for name, fn in [
    ("load valid CSV", t_load_valid),
    ("FileNotFoundError on missing file", t_load_missing_file),
    ("producer/consumer rows split correctly", t_producer_consumer_split),
    ("app_ids populated", t_app_ids_populated),
]: test(name, fn)

# ── Layer 2: Graph ────────────────────────────────────────────────────────
print("\n=== Layer 2: Graph Engine ===")
from src.graph.topology_graph import build_graph, find_cycles, compute_fan_out

def t_graph_has_nodes():
    ds, tg, *_ = pipeline()
    assert tg.G.number_of_nodes() > 0

def t_comm_flows_detected():
    ds, tg, *_ = pipeline()
    assert len(tg.comm_flows) > 0

def t_multi_qm_app_detected():
    ds, tg, *_ = pipeline()
    # ALPHA is on OLD_QM and OLD_QM3
    assert len(tg.app_to_qms.get("ALPHA", set())) >= 2

def t_alias_queues_cataloged():
    ds, tg, *_ = pipeline()
    assert any("ALIAS" in q for q in tg.alias_queues)

def t_fan_out_computed():
    ds, tg, *_ = pipeline()
    fan = compute_fan_out(tg)
    assert "ALPHA" in fan

for name, fn in [
    ("graph has nodes", t_graph_has_nodes),
    ("comm flows detected", t_comm_flows_detected),
    ("multi-QM app detected", t_multi_qm_app_detected),
    ("alias queues cataloged", t_alias_queues_cataloged),
    ("fan-out computed", t_fan_out_computed),
]: test(name, fn)

# ── Layer 3: Constraints ──────────────────────────────────────────────────
print("\n=== Layer 3: Constraint Engine ===")
from src.constraints.engine import run_constraints

def t_c1_violation_detected():
    ds, tg, rp, *_ = pipeline()
    rule_ids = {v.rule_id for v in rp.violations}
    assert "C1_ONE_QM_PER_APP" in rule_ids

def t_alias_violation_detected():
    ds, tg, rp, *_ = pipeline()
    rule_ids = {v.rule_id for v in rp.violations}
    assert "EXT_NO_ALIAS_QUEUES" in rule_ids

def t_hard_blocks_on_critical():
    ds, tg, rp, *_ = pipeline()
    assert rp.has_hard_blocks

def t_violation_score_positive():
    ds, tg, rp, *_ = pipeline()
    assert rp.total_violation_score > 0

def t_critical_violations_list():
    ds, tg, rp, *_ = pipeline()
    crits = rp.critical_violations
    assert all(v.severity == "CRITICAL" for v in crits)

for name, fn in [
    ("C1 violation detected", t_c1_violation_detected),
    ("alias queue violation detected", t_alias_violation_detected),
    ("hard_blocks=True with CRITICAL violations", t_hard_blocks_on_critical),
    ("violation score is positive", t_violation_score_positive),
    ("critical_violations list correct", t_critical_violations_list),
]: test(name, fn)

# ── Layer 6: OCS ──────────────────────────────────────────────────────────
print("\n=== Layer 6: OCS Scorer ===")

def t_ocs_total_positive():
    *_, oc, _ = pipeline()
    assert oc.total > 0

def t_ocs_components_nonneg():
    *_, oc, _ = pipeline()
    assert oc.c_base >= 0 and oc.c_violations >= 0

def t_ocs_total_equals_sum():
    *_, oc, _ = pipeline()
    assert oc.total == oc.c_base + oc.c_violations + oc.c_redundancy + oc.c_coupling

def t_ocs_breakdown_keys():
    *_, oc, _ = pipeline()
    for k in ["qm_count","channel_pairs","alias_queues"]:
        assert k in oc.breakdown, f"missing key: {k}"

for name, fn in [
    ("OCS total is positive", t_ocs_total_positive),
    ("OCS components non-negative", t_ocs_components_nonneg),
    ("OCS total == sum of components", t_ocs_total_equals_sum),
    ("OCS breakdown has required keys", t_ocs_breakdown_keys),
]: test(name, fn)

# ── Layer 5: Generator ────────────────────────────────────────────────────
print("\n=== Layer 5: Target State Generator ===")

def t_one_qm_per_app():
    *_, arts = pipeline()
    for qm in arts.target_qms:
        assert qm.startswith("QM."), f"bad name: {qm}"

def t_no_alias_in_target():
    *_, arts = pipeline()
    if not arts.target_df.empty:
        assert "Alias" not in arts.target_df["q_type"].values

def t_deterministic_channel_naming():
    *_, arts = pipeline()
    pat = re.compile(r"^QM\.[A-Z0-9]+\.QM\.[A-Z0-9]+$")
    for cp in arts.channel_pairs:
        assert pat.match(cp["sender_channel"]), f"bad: {cp['sender_channel']}"

def t_producers_remote():
    *_, arts = pipeline()
    if not arts.target_df.empty:
        prod = arts.target_df[arts.target_df["PrimaryAppRole"] == "Producer"]
        assert all(prod["q_type"] == "Remote")

def t_consumers_local():
    *_, arts = pipeline()
    if not arts.target_df.empty:
        cons = arts.target_df[arts.target_df["PrimaryAppRole"] == "Consumer"]
        assert all(cons["q_type"] == "Local")

def t_mqsc_has_key_commands():
    *_, arts = pipeline()
    text = "\n".join(arts.mqsc_commands)
    for cmd in ["DEFINE QLOCAL","DEFINE QREMOTE","DEFINE CHANNEL"]:
        assert cmd in text, f"missing: {cmd}"

def t_terraform_has_resources():
    *_, arts = pipeline()
    assert "ibm_mq_queue_manager" in arts.terraform_hcl
    assert "ibm_mq_channel" in arts.terraform_hcl

def t_decision_log_has_rationale():
    *_, arts = pipeline()
    assert len(arts.decision_log) > 0
    for d in arts.decision_log:
        assert "rationale" in d and len(d["rationale"]) > 10

def t_ocs_reduction_positive():
    *_, oc, arts = pipeline()
    target_ocs = len(arts.target_qms) + len(arts.channel_pairs) * 2
    assert target_ocs < oc.total, f"No reduction: {target_ocs} >= {oc.total}"

for name, fn in [
    ("1 QM per app (QM.<AppID> naming)", t_one_qm_per_app),
    ("no alias queues in target", t_no_alias_in_target),
    ("deterministic channel naming", t_deterministic_channel_naming),
    ("producers have Remote queue type", t_producers_remote),
    ("consumers have Local queue type", t_consumers_local),
    ("MQSC has DEFINE QLOCAL/QREMOTE/CHANNEL", t_mqsc_has_key_commands),
    ("Terraform has ibm_mq resources", t_terraform_has_resources),
    ("decision log has rationale strings", t_decision_log_has_rationale),
    ("OCS reduction is positive", t_ocs_reduction_positive),
]: test(name, fn)

# ── Agent ──────────────────────────────────────────────────────────────────
print("\n=== Layer 4: Agent ===")
from src.agent.analysis_agent import run_agent

def t_agent_6_passes():
    ds, tg, rp, oc, arts = pipeline()
    ar = run_agent(ds, tg, rp, oc, arts, use_llm=False)
    assert len(ar.passes) == 6

def t_agent_confidence_range():
    ds, tg, rp, oc, arts = pipeline()
    ar = run_agent(ds, tg, rp, oc, arts, use_llm=False)
    assert 0.0 <= ar.overall_confidence <= 1.0

def t_agent_has_recommendations():
    ds, tg, rp, oc, arts = pipeline()
    ar = run_agent(ds, tg, rp, oc, arts, use_llm=False)
    assert len(ar.recommendations) > 0

def t_agent_pass5_validates_c4():
    ds, tg, rp, oc, arts = pipeline()
    ar = run_agent(ds, tg, rp, oc, arts, use_llm=False)
    p5 = ar.passes[4]
    assert p5.pass_number == 5
    c4_checks = [f for f in p5.findings if f.get("check","").startswith("C4")]
    assert len(c4_checks) > 0

for name, fn in [
    ("agent produces exactly 6 passes", t_agent_6_passes),
    ("overall confidence in [0,1]", t_agent_confidence_range),
    ("agent has recommendations", t_agent_has_recommendations),
    ("Pass 5 validates C4 channel naming", t_agent_pass5_validates_c4),
]: test(name, fn)

# ── Summary ────────────────────────────────────────────────────────────────
total  = len(results)
passed = sum(1 for ok,_ in results if ok)
failed = total - passed
print(f"\n{'═'*55}")
print(f"  RESULTS: {passed}/{total} passed  |  {failed} failed")
print(f"{'═'*55}")
if failed:
    print("\nFailed tests:")
    for ok, name in results:
        if not ok: print(f"  ✗ {name}")
    sys.exit(1)
else:
    print("  All tests passed ✓")
    sys.exit(0)
