"""Tests for OCS scorer."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tempfile, os
from src.ingestion.loader import load_topology
from src.graph.topology_graph import build_graph
from src.constraints.engine import run_constraints
from src.observability.ocs_scorer import compute_ocs

SAMPLE = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
Q.A,PA,CA,PA,Test,Producer,Remote,Banking,Internal,Confidential,QM1,APPA,LOB,,Yes,Sync,,,QM1,Q.A,Normal,,B,Remote
Q.A,PA,CA,CA,Test,Consumer,Local,Banking,Internal,Confidential,QM1,APPA,LOB,,Yes,Sync,Enabled,Enabled,,,Normal,,B,Local
"""

def _run(content):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(content); fname = f.name
    ds = load_topology(fname); os.unlink(fname)
    tg = build_graph(ds)
    report = run_constraints(ds, tg)
    return compute_ocs(ds, tg, report)

def test_ocs_total_positive():
    ocs = _run(SAMPLE)
    assert ocs.total > 0

def test_ocs_components_non_negative():
    ocs = _run(SAMPLE)
    assert ocs.c_base >= 0
    assert ocs.c_violations >= 0
    assert ocs.c_redundancy >= 0
    assert ocs.c_coupling >= 0

def test_ocs_total_equals_sum():
    ocs = _run(SAMPLE)
    assert ocs.total == ocs.c_base + ocs.c_violations + ocs.c_redundancy + ocs.c_coupling

def test_ocs_breakdown_has_keys():
    ocs = _run(SAMPLE)
    for key in ["qm_count","channel_pairs","remote_queues","alias_queues"]:
        assert key in ocs.breakdown
