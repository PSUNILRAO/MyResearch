"""Tests for topology graph engine."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import tempfile
import os

from src.ingestion.loader import load_topology
from src.graph.topology_graph import build_graph, find_cycles, compute_fan_out

MULTI_APP_CSV = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
FLOW.A.B,ProdA,ConsB,ProdA,Test,Producer,Remote,Banking,Internal,Confidential,QM_SHARED,APP_A,LOB,,Yes,Synchronous,,,QM_SHARED,FLOW.A.B,Normal,,Banking,Remote
FLOW.A.B,ProdA,ConsB,ConsB,Test,Consumer,Local,Banking,Internal,Confidential,QM_SHARED,APP_B,LOB,,Yes,Synchronous,Enabled,Enabled,,,Normal,,Banking,Local
FLOW.B.C,ProdB,ConsC,ProdB,Test,Producer,Remote,Banking,Internal,Confidential,QM_SHARED,APP_B,LOB,,Yes,Synchronous,,,QM3,FLOW.B.C,Normal,,Banking,Remote
FLOW.B.C,ProdB,ConsC,ConsC,Test,Consumer,Local,Banking,Internal,Confidential,QM3,APP_C,LOB,,Yes,Synchronous,Enabled,Enabled,,,Normal,,Banking,Local
"""


@pytest.fixture
def multi_app_ds():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(MULTI_APP_CSV)
        fname = f.name
    ds = load_topology(fname)
    os.unlink(fname)
    return ds


def test_build_graph(multi_app_ds):
    tg = build_graph(multi_app_ds)
    assert tg.G.number_of_nodes() > 0
    assert len(tg.comm_flows) >= 2


def test_multi_app_qm_detected(multi_app_ds):
    tg = build_graph(multi_app_ds)
    # QM_SHARED hosts both APP_A and APP_B
    assert len(tg.qm_to_apps["QM_SHARED"]) >= 2


def test_app_to_qm_mapping(multi_app_ds):
    tg = build_graph(multi_app_ds)
    assert "QM_SHARED" in tg.app_to_qms["APP_A"]
    assert "QM_SHARED" in tg.app_to_qms["APP_B"]


def test_fan_out(multi_app_ds):
    tg = build_graph(multi_app_ds)
    fan = compute_fan_out(tg)
    assert "APP_B" in fan  # APP_B produces to APP_C


def test_no_false_cycles(multi_app_ds):
    tg = build_graph(multi_app_ds)
    cycles = find_cycles(tg)
    # Linear A→B→C should have no cycle
    cycle_apps = {frozenset(c) for c in cycles}
    assert frozenset(["APP_A","APP_B","APP_C"]) not in cycle_apps
