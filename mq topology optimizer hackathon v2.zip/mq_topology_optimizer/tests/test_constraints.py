"""Tests for constraint engine."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import tempfile
import os

from src.ingestion.loader import load_topology
from src.graph.topology_graph import build_graph
from src.constraints.engine import run_constraints

VIOLATION_CSV = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
Q.X.Y,ProdX,ConsY,ProdX,Test,Producer,Local,Banking,Internal,Confidential,QM_ONE,APP_X,LOB,,Yes,Synchronous,,,,,Normal,,Banking,Local
Q.X.Y,ProdX,ConsY,ProdX,Test,Producer,Local,Banking,Internal,Confidential,QM_TWO,APP_X,LOB,,Yes,Synchronous,,,,,Normal,,Banking,Local
Q.X.Y,ProdX,ConsY,ConsY,Test,Consumer,Local,Banking,Internal,Confidential,QM_ONE,APP_Y,LOB,,Yes,Synchronous,Enabled,Enabled,,,Normal,,Banking,Local
Q.X.ALIAS,ProdX,ConsY,ProdX,Test,Producer,Alias,Banking,Internal,Confidential,QM_ONE,APP_X,LOB,,Yes,Synchronous,,,,,Normal,,Banking,Alias
"""

CLEAN_CSV = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
CLEAN.Q,ProdA,ConsB,ProdA,Test,Producer,Remote,Banking,Internal,Confidential,QM.APPA,APP_A,LOB,,Yes,Synchronous,,,QM.APPB,CLEAN.Q,Normal,XMIT.QM.APPB,Banking,Remote
CLEAN.Q,ProdA,ConsB,ConsB,Test,Consumer,Local,Banking,Internal,Confidential,QM.APPB,APP_B,LOB,,Yes,Synchronous,Enabled,Enabled,,,Normal,,Banking,Local
"""


def _load(content):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(content)
        fname = f.name
    ds = load_topology(fname)
    os.unlink(fname)
    return ds


def test_c1_violation_detected():
    ds     = _load(VIOLATION_CSV)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    rule_ids = {v.rule_id for v in report.violations}
    assert "C1_ONE_QM_PER_APP" in rule_ids


def test_alias_violation_detected():
    ds     = _load(VIOLATION_CSV)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    rule_ids = {v.rule_id for v in report.violations}
    assert "EXT_NO_ALIAS_QUEUES" in rule_ids


def test_hard_blocks_on_critical():
    ds     = _load(VIOLATION_CSV)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    assert report.has_hard_blocks  # C1 is CRITICAL


def test_clean_topology_no_c1():
    ds     = _load(CLEAN_CSV)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    c1_viols = [v for v in report.violations if v.rule_id == "C1_ONE_QM_PER_APP"]
    assert len(c1_viols) == 0


def test_violation_score_positive():
    ds     = _load(VIOLATION_CSV)
    tg     = build_graph(ds)
    report = run_constraints(ds, tg)
    assert report.total_violation_score > 0
