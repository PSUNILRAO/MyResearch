"""Tests for CSV ingestion layer."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import pandas as pd
import tempfile
import os

from src.ingestion.loader import load_topology, REQUIRED_COLUMNS


SAMPLE_CSV_CONTENT = """Discrete Queue Name,ProducerName,ConsumerName,Primary App_Full_Name,PrimaryAppDisp,PrimaryAppRole,Primary Application Id q_type,Primary Neighborhood,Primary Hosting Type,Primary Data classification,queue_manager_name,app_id,line_of_business,cluster_name,def_persistence,def_put_response,inhibit_get,inhibit_put,remote_q_mgr_name,remote_q_name,usage,xmit_q_name,Neighborhood,q_type
TEST.Q.ONE,ProducerA,ConsumerB,ProducerApp,Test,Producer,Remote,Banking,Internal,Confidential,QM1,APP1,LOB1,,Yes,Synchronous,,,QM2,TEST.Q.ONE,Normal,XMIT.QM2,Banking,Remote
TEST.Q.ONE,ProducerA,ConsumerB,ConsumerApp,Test,Consumer,Local,Banking,Internal,Confidential,QM2,APP2,LOB1,,Yes,Synchronous,Enabled,Enabled,,,Normal,,Banking,Local
"""


@pytest.fixture
def sample_csv():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(SAMPLE_CSV_CONTENT)
        yield f.name
    os.unlink(f.name)


def test_load_valid_csv(sample_csv):
    ds = load_topology(sample_csv)
    assert ds.is_valid
    assert len(ds.raw_df) == 2
    assert "APP1" in ds.app_ids
    assert "APP2" in ds.app_ids
    assert "QM1" in ds.queue_managers
    assert "QM2" in ds.queue_managers


def test_load_nonexistent_file():
    with pytest.raises(FileNotFoundError):
        load_topology("/nonexistent/path/file.csv")


def test_missing_required_columns(tmp_path):
    bad_csv = tmp_path / "bad.csv"
    bad_csv.write_text("Col1,Col2\na,b\n")
    ds = load_topology(str(bad_csv))
    assert not ds.is_valid
    assert len(ds.validation_errors) > 0


def test_producer_consumer_split(sample_csv):
    ds = load_topology(sample_csv)
    assert len(ds.producer_rows) == 1
    assert len(ds.consumer_rows) == 1
    assert ds.producer_rows.iloc[0]["app_id"] == "APP1"
    assert ds.consumer_rows.iloc[0]["app_id"] == "APP2"


def test_unique_queues(sample_csv):
    ds = load_topology(sample_csv)
    assert "TEST.Q.ONE" in ds.queues
