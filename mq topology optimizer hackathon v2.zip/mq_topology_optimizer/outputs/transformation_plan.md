# MQ Topology Transformation Plan

**Total Steps:** 22  
**Estimated Duration:** 6-7 weeks  
**New QMs to Provision:** 12  
**Legacy QMs to Decommission:** 8  

---
## Phase 1: Audit & Freeze (Week 1-2)

### P1-S01 — Export full MQ object inventory
**Risk:** LOW  
**Duration:** 1-2 days  
**Objects:** `DC6Z098V, WL6EMZZ, WL6ER2D, WL6ESPM, WL6EWLSJ`

Run DISPLAY commands across all 8 queue managers to export complete object catalog: queue managers, queues, channels, authority records. Store as baseline snapshot.

```mqsc
DISPLAY QMGR ALL
DISPLAY Q(*) ALL
DISPLAY CHANNEL(*) ALL
DISPLAY AUTHINFO(*) ALL
```

**Rollback:** No changes made — read-only operation

### P1-S02 — Document all active application connections
**Risk:** LOW  
**Duration:** 1 day  
**Objects:** `8A, 8AFK, 8ASE, 8FVC, 8SOR`

Map every AppID to its current QM(s). Identify 1 apps violating the 1-QM constraint. Verify 3 alias queues have no exclusive consumers.

```mqsc
DISPLAY CONN(*) ALL
DISPLAY QSTATUS(*) TYPE(HANDLE)
```

**Rollback:** N/A — documentation only

### P1-S03 — Freeze topology — no new MQ objects permitted
**Risk:** LOW  
**Duration:** 0.5 days (process)  
**Objects:** `ALL ENVIRONMENTS`

Issue change freeze covering all MQ environments. All new topology requests queued to target-state design. Communicate freeze timeline to application teams.

```mqsc
* Change freeze — no MQSC changes without approval
```

**Rollback:** Lift freeze if timeline slips

### P1-S04 — Drain and verify dead-letter queues
**Risk:** MEDIUM  
**Duration:** 1-2 days  
**Objects:** `SYSTEM.DEAD.LETTER.QUEUE on all QMs`

Ensure all DLQ depths are zero before migration begins. Unresolvable DLQ messages indicate existing routing problems that must be resolved before migration.

```mqsc
DISPLAY QLOCAL(SYSTEM.DEAD.LETTER.QUEUE) CURDEPTH
```

**Rollback:** Fix DLQ root cause before proceeding

---
## Phase 2: Provision Target QMs (Week 2-3)

### P2-S05 — Provision 12 new Queue Managers
**Risk:** LOW  
**Duration:** 2-3 days  
**Objects:** `QM.8A, QM.8AFK, QM.8ASE, QM.8FVC, QM.8SOR`

Create all target QMs following naming convention QM.<AppID>. Apply secure-by-default config: CHLAUTH(ENABLED), CONNAUTH(REQUIRED), TLS cipher suites enforced. Target QMs: QM.8A, QM.8AFK, QM.8ASE, QM.8FVC, QM.8SOR, QM.9SDC, QM.LW, QM.NADC...

```mqsc
DEFINE QMGR('QM.8A') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE
DEFINE QMGR('QM.8AFK') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE
DEFINE QMGR('QM.8ASE') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE
DEFINE QMGR('QM.8FVC') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE
DEFINE QMGR('QM.8SOR') CHLAUTH(ENABLED) CONNAUTH(REQUIRED) REPLACE
* ... (see target_state.mqsc for full list)
```

**Rollback:** DELETE QMGR for each provisioned QM

### P2-S06 — Create 9 XMIT queue pairs
**Risk:** LOW  
**Duration:** 1 day  
**Objects:** `XMIT.QM.OK, XMIT.QM.PPCSM, XMIT.QM.8FVC, XMIT.QM.8SOR, XMIT.QM.9SDC`

Define one XMIT queue per outbound destination on each producer QM. XMIT queues isolate per-destination traffic and enable independent channel control.

```mqsc
DEFINE QLOCAL('XMIT.QM.8FVC') USAGE(XMITQ) DEFPSIST(YES) REPLACE
DEFINE QLOCAL('XMIT.QM.8SOR') USAGE(XMITQ) DEFPSIST(YES) REPLACE
DEFINE QLOCAL('XMIT.QM.9SDC') USAGE(XMITQ) DEFPSIST(YES) REPLACE
DEFINE QLOCAL('XMIT.QM.LW') USAGE(XMITQ) DEFPSIST(YES) REPLACE
DEFINE QLOCAL('XMIT.QM.NADC') USAGE(XMITQ) DEFPSIST(YES) REPLACE
```

**Rollback:** DELETE QLOCAL for each XMIT queue

### P2-S07 — Define all Sender/Receiver channel pairs
**Risk:** MEDIUM  
**Duration:** 2 days  
**Objects:** `QM.8A.QM.OK, QM.8AFK.QM.PPCSM, QM.8ASE.QM.8FVC, QM.8ASE.QM.8SOR, QM.8ASE.QM.9SDC`

Create 9 sender + 9 receiver channels using deterministic naming QM.SRC.QM.DST / QM.DST.QM.SRC. All channels configured with TLS.

```mqsc
DEFINE CHANNEL('QM.8A.QM.OK') CHLTYPE(SDR) CONNAME('target-host(1414)') XMITQ('XMIT.QM.OK') SSLCIPH(TLS_RSA_WITH_AES_256_CBC_SHA256) REPLACE
```

**Rollback:** STOP CHANNEL then DELETE CHANNEL

---
## Phase 3: Migrate Flows (per app pair) (Week 3-5)

### P3-S08 — Migrate flow: 8A → OK
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `8A.OK.VFHVIGL.HDF.RQST, 8A.OK.VFHVIGL.HDF.RQST.XA21, QM.8A, QM.OK`

Define Remote queue on QM.8A → QM.OK. Define Local queue(s) on QM.OK. Queues: 8A.OK.VFHVIGL.HDF.RQST, 8A.OK.VFHVIGL.HDF.RQST.XA21. Update CCDT for app 8A. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8A:
DEFINE QREMOTE('8A.OK.VFHVIGL.HDF.RQST') RNAME('8A.OK.VFHVIGL.HDF.RQST') RQMNAME('QM.OK') XMITQ('XMIT.QM.OK') REPLACE
* On QM.OK:
DEFINE QLOCAL('8A.OK.VFHVIGL.HDF.RQST') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8A.QM.OK')
```

**Rollback:** Stop QM.8A.QM.OK. Repoint app 8A CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S09 — Migrate flow: 8AFK → PPCSM
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `8AFK.PPCSM.ARCNE.ACK, 8AFK.PPCSM.ZEEWALA.ACK, 8AFK.PPCSM.ZEEWALA.DAT, QM.8AFK, QM.PPCSM`

Define Remote queue on QM.8AFK → QM.PPCSM. Define Local queue(s) on QM.PPCSM. Queues: 8AFK.PPCSM.ARCNE.ACK, 8AFK.PPCSM.ZEEWALA.ACK, 8AFK.PPCSM.ZEEWALA.DAT. Update CCDT for app 8AFK. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8AFK:
DEFINE QREMOTE('8AFK.PPCSM.ARCNE.ACK') RNAME('8AFK.PPCSM.ARCNE.ACK') RQMNAME('QM.PPCSM') XMITQ('XMIT.QM.PPCSM') REPLACE
* On QM.PPCSM:
DEFINE QLOCAL('8AFK.PPCSM.ARCNE.ACK') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8AFK.QM.PPCSM')
```

**Rollback:** Stop QM.8AFK.QM.PPCSM. Repoint app 8AFK CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S10 — Migrate flow: 8ASE → 8FVC
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.8FVC.YESEELA, QM.8ASE, QM.8FVC`

Define Remote queue on QM.8ASE → QM.8FVC. Define Local queue(s) on QM.8FVC. Queues: BASE.8FVC.YESEELA. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.8FVC.YESEELA') RNAME('BASE.8FVC.YESEELA') RQMNAME('QM.8FVC') XMITQ('XMIT.QM.8FVC') REPLACE
* On QM.8FVC:
DEFINE QLOCAL('BASE.8FVC.YESEELA') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.8FVC')
```

**Rollback:** Stop QM.8ASE.QM.8FVC. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S11 — Migrate flow: 8ASE → 8SOR
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.8SOR.HQWK.VUV, QM.8ASE, QM.8SOR`

Define Remote queue on QM.8ASE → QM.8SOR. Define Local queue(s) on QM.8SOR. Queues: BASE.8SOR.HQWK.VUV. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.8SOR.HQWK.VUV') RNAME('BASE.8SOR.HQWK.VUV') RQMNAME('QM.8SOR') XMITQ('XMIT.QM.8SOR') REPLACE
* On QM.8SOR:
DEFINE QLOCAL('BASE.8SOR.HQWK.VUV') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.8SOR')
```

**Rollback:** Stop QM.8ASE.QM.8SOR. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S12 — Migrate flow: 8ASE → 9SDC
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.9SDC.ZRO.TT.PNDYUGK.DAT, QM.8ASE, QM.9SDC`

Define Remote queue on QM.8ASE → QM.9SDC. Define Local queue(s) on QM.9SDC. Queues: BASE.9SDC.ZRO.TT.PNDYUGK.DAT. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.9SDC.ZRO.TT.PNDYUGK.DAT') RNAME('BASE.9SDC.ZRO.TT.PNDYUGK.DAT') RQMNAME('QM.9SDC') XMITQ('XMIT.QM.9SDC') REPLACE
* On QM.9SDC:
DEFINE QLOCAL('BASE.9SDC.ZRO.TT.PNDYUGK.DAT') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.9SDC')
```

**Rollback:** Stop QM.8ASE.QM.9SDC. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S13 — Migrate flow: 8ASE → LW
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.LW.HCJ.PNVBAWHM.ZQC01, BASE.LW.WRQN.TJR1.HCJ.PNVBAWHM.ZQN01, QM.8ASE, QM.LW`

Define Remote queue on QM.8ASE → QM.LW. Define Local queue(s) on QM.LW. Queues: BASE.LW.HCJ.PNVBAWHM.ZQC01, BASE.LW.WRQN.TJR1.HCJ.PNVBAWHM.ZQN01. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.LW.HCJ.PNVBAWHM.ZQC01') RNAME('BASE.LW.HCJ.PNVBAWHM.ZQC01') RQMNAME('QM.LW') XMITQ('XMIT.QM.LW') REPLACE
* On QM.LW:
DEFINE QLOCAL('BASE.LW.HCJ.PNVBAWHM.ZQC01') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.LW')
```

**Rollback:** Stop QM.8ASE.QM.LW. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S14 — Migrate flow: 8ASE → NADC
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.NADC.MP.PMD.DAT, BASE.NADC.MP.PMD.DAT.IO, BASE.NADC.MP.TT.DAT, QM.8ASE, QM.NADC`

Define Remote queue on QM.8ASE → QM.NADC. Define Local queue(s) on QM.NADC. Queues: BASE.NADC.MP.PMD.DAT, BASE.NADC.MP.PMD.DAT.IO, BASE.NADC.MP.TT.DAT. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.NADC.MP.PMD.DAT') RNAME('BASE.NADC.MP.PMD.DAT') RQMNAME('QM.NADC') XMITQ('XMIT.QM.NADC') REPLACE
* On QM.NADC:
DEFINE QLOCAL('BASE.NADC.MP.PMD.DAT') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.NADC')
```

**Rollback:** Stop QM.8ASE.QM.NADC. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S15 — Migrate flow: 8ASE → NAOC
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.NAOC.UEYZOLA.YES, QM.8ASE, QM.NAOC`

Define Remote queue on QM.8ASE → QM.NAOC. Define Local queue(s) on QM.NAOC. Queues: BASE.NAOC.UEYZOLA.YES. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.NAOC.UEYZOLA.YES') RNAME('BASE.NAOC.UEYZOLA.YES') RQMNAME('QM.NAOC') XMITQ('XMIT.QM.NAOC') REPLACE
* On QM.NAOC:
DEFINE QLOCAL('BASE.NAOC.UEYZOLA.YES') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.NAOC')
```

**Rollback:** Stop QM.8ASE.QM.NAOC. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

### P3-S16 — Migrate flow: 8ASE → TGYI
**Risk:** HIGH  
**Duration:** 1-2 days per flow  
**Objects:** `BASE.TGYI.PSQ20996.YESEELA, QM.8ASE, QM.TGYI`

Define Remote queue on QM.8ASE → QM.TGYI. Define Local queue(s) on QM.TGYI. Queues: BASE.TGYI.PSQ20996.YESEELA. Update CCDT for app 8ASE. Run parallel (old + new QM) until message parity confirmed. Cutover: drain old queue to depth 0 then switch.

```mqsc
* On QM.8ASE:
DEFINE QREMOTE('BASE.TGYI.PSQ20996.YESEELA') RNAME('BASE.TGYI.PSQ20996.YESEELA') RQMNAME('QM.TGYI') XMITQ('XMIT.QM.TGYI') REPLACE
* On QM.TGYI:
DEFINE QLOCAL('BASE.TGYI.PSQ20996.YESEELA') DEFPSIST(YES) REPLACE
START CHANNEL('QM.8ASE.QM.TGYI')
```

**Rollback:** Stop QM.8ASE.QM.TGYI. Repoint app 8ASE CCDT back to legacy QM. Drain new queue → old queue via temporary bridge.

---
## Phase 4: Decommission Legacy Objects (Week 5-6)

### P4-S17 — Delete 3 Alias queue definitions
**Risk:** MEDIUM  
**Duration:** 0.5 days  
**Objects:** `8A.OK.VFHVIGL.HDF.RQST.XA21, BASE.9SDC.ZRO.TT.PNDYUGK.DAT, BASE.TGYI.PSQ20996.YESEELA`

Remove all Alias queue definitions. Verify zero consumers on each before deletion. Alias queues: 8A.OK.VFHVIGL.HDF.RQST.XA21, BASE.9SDC.ZRO.TT.PNDYUGK.DAT, BASE.TGYI.PSQ20996.YESEELA

```mqsc
DISPLAY QSTATUS('8A.OK.VFHVIGL.HDF.RQST.XA21') TYPE(HANDLE) + DELETE QALIAS('8A.OK.VFHVIGL.HDF.RQST.XA21')
DISPLAY QSTATUS('BASE.9SDC.ZRO.TT.PNDYUGK.DAT') TYPE(HANDLE) + DELETE QALIAS('BASE.9SDC.ZRO.TT.PNDYUGK.DAT')
DISPLAY QSTATUS('BASE.TGYI.PSQ20996.YESEELA') TYPE(HANDLE) + DELETE QALIAS('BASE.TGYI.PSQ20996.YESEELA')
```

**Rollback:** Recreate DEFINE QALIAS if consumers still reference it

### P4-S18 — Decommission 8 legacy Queue Managers
**Risk:** HIGH  
**Duration:** 1 day  
**Objects:** `DC6Z098V, WL6EMZZ, WL6ER2D, WL6ESPM, WL6EWLSJ`

Stop and decommission original QMs after confirming all apps have been migrated to target QMs and all queues are at depth 0. QMs to decommission: DC6Z098V, WL6EMZZ, WL6ER2D, WL6ESPM, WL6EWLSJ, WL6EX2C

```mqsc
* Verify zero depth on all queues:
DISPLAY QLOCAL(*) CURDEPTH
* Then end QM:
ENDMQM -i <QMGR_NAME>
```

**Rollback:** Restart legacy QM: strmqm <QMGR_NAME>

---
## Phase 5: Validate & Automate (Week 6-7)

### P5-S19 — Run OCS validation on live target topology
**Risk:** LOW  
**Duration:** 0.5 days  
**Objects:** `QM.8A, QM.8AFK, QM.8ASE, QM.8FVC, QM.8SOR`

Re-run complexity scoring against live environment. Verify OCS has dropped from as-is value. Confirm 0 constraint violations in target environment.

```mqsc
python scripts/validate_target.py --env production
```

**Rollback:** N/A — validation only

### P5-S20 — Activate channel health monitoring
**Risk:** LOW  
**Duration:** 1 day  
**Objects:** `QM.8A.QM.OK, QM.8AFK.QM.PPCSM, QM.8ASE.QM.8FVC, QM.8ASE.QM.8SOR, QM.8ASE.QM.9SDC`

Enable monitoring on all new sender channels. Configure alerts: channel INACTIVE > 5min, XMIT queue depth > 500, DLQ depth > 0.

```mqsc
DISPLAY CHSTATUS(*) ALL
* Configure alerts in IBM MQ Console or Instana
```

**Rollback:** N/A

### P5-S21 — Commit target topology to GitOps repository
**Risk:** LOW  
**Duration:** 0.5 days  
**Objects:** `Git repository, CI/CD pipeline`

Push target_state.mqsc and main.tf to Git repository. Tag release with version and OCS score. Enable drift detection: schedule daily comparison of live config vs IaC state.

```mqsc
git add outputs/target_state.mqsc outputs/main.tf
git commit -m 'feat: apply target topology (OCS reduced)'
git tag v1.0-target-state
```

**Rollback:** git revert

### P5-S22 — Conduct post-migration application smoke tests
**Risk:** LOW  
**Duration:** 2-3 days  
**Objects:** `8A, 8AFK, 8ASE, 8FVC, 8SOR`

For each migrated flow, verify end-to-end message delivery: producer sends test message → verify consumer receives it on new QM. Check message persistence, TRTC compliance, and data classification.

```mqsc
* Put test message:
amqsput <QNAME> <QMGR>
* Get from consumer QM:
amqsget <QNAME> <QMGR>
```

**Rollback:** Escalate to Phase 3 rollback if message loss detected
