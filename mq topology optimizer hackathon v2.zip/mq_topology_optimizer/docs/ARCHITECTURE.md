# Architecture Decision Records

## Overview

This document captures the key architectural decisions for the Intelligent MQ Topology Platform.

---

## ADR-001: 6-Layer Pipeline Architecture

**Status:** Accepted

**Context:** The problem requires analysis, constraint enforcement, AI reasoning, and artifact generation. A monolithic script would be difficult to test, extend, or run partially.

**Decision:** Implement as 6 discrete, independently testable layers:
1. Ingestion → 2. Graph → 3. Constraints → 4. Agent → 5. Generator → 6. Observability

**Consequences:**
- Each layer has clear inputs/outputs (dataclasses)
- Layers can be run independently or as full pipeline
- Easy to swap LLM backend (Anthropic → OpenAI → local)

---

## ADR-002: NetworkX for Graph Engine

**Status:** Accepted

**Context:** Topology analysis requires cycle detection, path finding, fan-out computation — inherently graph operations.

**Decision:** Use NetworkX DiGraph as the primary topology model. Every QM, App, and their relationships are nodes/edges.

**Consequences:**
- Cycle detection: `nx.simple_cycles()` — 1 line vs 50 lines of recursive SQL
- Fan-out: `nx.out_degree()` — trivial
- Future: swap to Neo4j by changing `build_graph()` implementation only

---

## ADR-003: Deterministic-First AI Agent

**Status:** Accepted

**Context:** LLM APIs may be unavailable, rate-limited, or too slow for a hackathon demo.

**Decision:** All 6 agent passes have deterministic Python implementations. LLM is an *enhancement* layer on Pass 6 (explanation), not a dependency.

**Consequences:**
- Pipeline runs fully offline without any API key
- LLM adds explanation quality, not correctness
- Confidence scores are always computable

---

## ADR-004: OCS as First-Class Metric

**Status:** Accepted

**Context:** The hackathon requires "quantitative complexity metric." We need it to be auditable, reproducible, and comparable.

**Decision:** Define OCS formula explicitly with integer weights per component. Store weights in `config/constraints.yaml` so they are tunable without code changes.

**Formula:**
```
OCS = C_base + C_violations + C_redundancy + C_coupling
```

---

## ADR-005: Idempotent MQSC Output

**Status:** Accepted

**Context:** Operations teams need to safely re-run scripts without duplicate object errors.

**Decision:** All MQSC `DEFINE` commands include `REPLACE` keyword. Safe to apply multiple times.

**Consequences:** (+) Automation-safe. (-) `REPLACE` on a running channel drops it briefly.

---

## ADR-006: Target QM Naming Convention

**Status:** Accepted

**Context:** The problem statement requires deterministic naming.

**Decision:**
- Queue Manager: `QM.<AppID>`
- XMIT Queue: `XMIT.QM.<DestApp>`
- Sender Channel: `QM.<SrcApp>.QM.<DstApp>`
- Receiver Channel: `QM.<DstApp>.QM.<SrcApp>`

This convention is enforced by C4 constraint check and validated in Pass 5 of the agent.
