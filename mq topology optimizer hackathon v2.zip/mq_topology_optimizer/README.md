# 🚀 Intelligent MQ Topology Simplification & Automation

> **IBM MQ Hackathon Submission** — AI-augmented enterprise MQ topology analysis, constraint enforcement, and automated target-state generation.

---

## 🏆 What This Solves

Enterprise IBM MQ environments accumulate **topology debt**: applications spread across multiple queue managers, redundant channels, 3-hop routing chains, and non-deterministic cluster routing. This system:

1. **Analyzes** the as-is MQ topology from CSV datasets
2. **Scores** complexity using the Operational Complexity Score (OCS)
3. **Enforces** all four non-negotiable core constraints automatically
4. **Redesigns** the topology to a clean, 1-QM-per-app target state
5. **Generates** target CSV + MQSC scripts + Terraform configs — automation-ready
6. **Explains** every decision with full rationale via AI agent

---

## 📁 Project Structure

```
mq_topology_optimizer/
├── data/
│   └── sample/                    # Sample MQ topology CSV datasets
├── src/
│   ├── ingestion/                 # CSV parsing & data loading
│   ├── graph/                     # NetworkX topology graph engine
│   ├── constraints/               # OPA-style constraint enforcement
│   ├── agent/                     # LLM-powered 6-pass analysis agent
│   ├── generator/                 # Target-state CSV + MQSC generator
│   ├── observability/             # OCS scoring & metrics
│   └── utils/                     # Shared utilities
├── streamlit_app/                 # Interactive dashboard UI
│   └── pages/                     # Multi-page Streamlit app
├── tests/                         # Pytest test suite
├── outputs/                       # Generated artifacts
├── docs/                          # Architecture documentation
├── config/                        # YAML configuration files
├── scripts/                       # CLI entry points
├── notebooks/                     # Jupyter analysis notebooks
├── requirements.txt
├── setup.py
├── .env.example
└── README.md
```

---

## ⚡ Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/your-org/mq_topology_optimizer.git
cd mq_topology_optimizer
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env — add your ANTHROPIC_API_KEY (optional, needed for AI agent)
```

### 3. Run Full Pipeline (CLI)

```bash
# Analyze a topology CSV
python scripts/run_pipeline.py --input data/sample/mq_topology.csv

# Full pipeline with AI agent
python scripts/run_pipeline.py --input data/sample/mq_topology.csv --ai-agent

# Generate target state only
python scripts/run_pipeline.py --input data/sample/mq_topology.csv --output-dir outputs/
```

### 4. Launch Interactive Dashboard

```bash
streamlit run streamlit_app/Home.py
```

---

## 🏗️ Architecture: 6-Layer Pipeline

```
Layer 1: CSV Ingestion & Validation
         ↓
Layer 2: Topology Graph Construction (NetworkX)
         ↓
Layer 3: Constraint Engine (4 core rules + extensions)
         ↓
Layer 4: AI Analysis Agent (6-pass reasoning)
         ↓
Layer 5: Target State Generator (CSV + MQSC + Terraform)
         ↓
Layer 6: OCS Scoring & Observability
```

### Four Non-Negotiable Constraints

| # | Constraint | Enforcement |
|---|-----------|-------------|
| C1 | Exactly 1 QM per AppID | Hard block — violations fail pipeline |
| C2 | Producers write to Remote Q → XMIT Q → channel | Schema validation |
| C3 | Consumers read from Local Q only | Graph traversal check |
| C4 | Deterministic channel naming `QM.A.QM.B` | Regex pattern enforcement |

### Complexity Score (OCS)

```
OCS = C_base + C_violations + C_redundancy + C_coupling

Where:
  C_base       = QM_count + Channel_count + RemoteQueue_count
  C_violations = (AppQM_violations × 10) + (MultiHop_routes × 8) + (Alias_queues × 3)
  C_redundancy = (Duplicate_queues × 5) + (Unused_objects × 3)
  C_coupling   = (Cluster_count × 5) + (SharedQM_apps × 8)
```

---

## 📊 Expected Outputs

All outputs written to `outputs/` directory:

| File | Description |
|------|-------------|
| `target_topology.csv` | Target state in same schema as input |
| `target_state.mqsc` | MQSC commands to apply target state |
| `main.tf` | Terraform IBM MQ resources |
| `complexity_report.json` | As-is vs to-be OCS comparison |
| `decision_log.json` | Full AI agent decision rationale |
| `topology_graph.html` | Interactive topology visualization |
| `hackathon_report.pdf` | Complete submission report |

---

## 🤖 AI Agent (Optional)

Set `ANTHROPIC_API_KEY` in `.env` to enable the Claude-powered 6-pass agent:

1. **Pass 1 — Discovery**: Parse and inventory all MQ objects
2. **Pass 2 — Anomaly Detection**: Find violations, cycles, redundancy
3. **Pass 3 — Complexity Scoring**: Compute OCS with dimensional breakdown
4. **Pass 4 — Target Generation**: Design compliant target topology
5. **Pass 5 — Constraint Validation**: Verify target satisfies all rules
6. **Pass 6 — Explanation**: Generate human-readable decision rationale

Without API key, all passes run using deterministic Python logic (no LLM needed).

---

## 🧪 Tests

```bash
pytest tests/ -v --cov=src
```

---

## 📋 Deliverables Checklist

- [x] Target-state topology dataset (CSV, identical schema to input)
- [x] As-is vs target complexity analysis with OCS algorithm
- [x] Topology visualizations (as-is + target, interactive HTML)
- [x] Design and decision documentation (JSON + PDF report)
- [x] MQSC automation scripts
- [x] Streamlit interactive dashboard
- [x] Full test suite

---

## 🔑 Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | Optional | Enables Claude AI agent passes |
| `OPENAI_API_KEY` | Optional | Alternative LLM backend |
| `LOG_LEVEL` | Optional | DEBUG/INFO/WARNING (default: INFO) |
| `OUTPUT_DIR` | Optional | Output directory (default: outputs/) |
