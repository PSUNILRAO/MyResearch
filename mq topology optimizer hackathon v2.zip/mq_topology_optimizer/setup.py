from setuptools import setup, find_packages

setup(
    name="mq_topology_optimizer",
    version="1.0.0",
    description="Intelligent MQ Topology Simplification & Automation — IBM MQ Hackathon",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "mq-analyze=scripts.run_pipeline:main",
        ],
    },
)
